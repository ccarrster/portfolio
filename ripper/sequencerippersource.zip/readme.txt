C�:'s URL Sequence Ripper

Files
sample.txt		A sample of the command line used to run the application
readme.txt		This file
sequenceRipper.jar	The compiled application
javadoc\index.html	Javadoc: information about the source code
sequenceripper\*.java	The source files

Purpose: To make a sequence ripper so I can rip sites off of the internet quickly. Do what you want with the source.

So updates and info will be at:
http://www.geocities.com/jpgmantools

Help/info whatever:
poomang@hotmail.com