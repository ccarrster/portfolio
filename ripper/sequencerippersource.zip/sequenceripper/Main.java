package sequenceripper;

import java.net.*;
import java.io.*;

public class Main {
	public static void main(String[] args){
            if(args.length == 8){
                //Do stuff
                URLSites test = new URLSites();
                URLSite slutStorm = new URLSite(args[0], args[1], args[2]);
                slutStorm.addSequence(args[3], Integer.parseInt(args[4]), Integer.parseInt(args[5]), Integer.parseInt(args[6]), args[7]);
                test.addSite(slutStorm);
		test.next();
            } else {
                System.out.println("Format:\nURL\nUsername\nPassword\npath and file prefix\nStarting number\nEnding number\nNumber of zeros\nExtension");
            }
		//URLSites test = new URLSites();
		//URLSite slutStorm = new URLSite("http://www.geocities.com", "dn032403", "3ip76k2");


		//slutStorm.addSequence("", , , 0, ".jpg");

		//slutStorm.addSequence("/kk44k47/sus/sus", 1, 107, 3, ".jpg");

		
	}
}
