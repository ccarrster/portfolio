/*
 * URLConnectionReader.java
 *
 * Created on February 20, 2005, 4:49 PM
 */

package sequenceripper;

import java.net.*;
import java.io.*;

public class URLConnectionReader {
    public static void main(String[] args) throws Exception {
		initialize();
    }

	public static void initialize(){


		String urlString;
		String[] urlArray = new String[] {
			"http://www.wildchyld.com/Member/Playroom/2001/green/blackdress/images/p000"
		};
		for(int j = 0; j < urlArray.length; j++){
			for(int i = 3714; i <= 3735; i++){
				//needs a little work
				String padZero = "";
				/*String padZero = "0";
				if (i < 10 && i > 0)
				{
					padZero = "00";
				}*/
				//damned direct link protection!
				urlString = urlArray[j] + padZero + i + ".jpg";
				downloadUrl(urlString);
			}
		}
	}


    public static void downloadUrl(String urlStr){
		try{
			String userPassword = "mazdasg2:turbo911";
			URL url = new URL(urlStr);
			String encoding = new sun.misc.BASE64Encoder().encode (userPassword.getBytes());
			URLConnection yc = url.openConnection();
			yc.setRequestProperty ("Authorization", "Basic " + encoding);
			BufferedInputStream in = new BufferedInputStream(yc.getInputStream());
			String fileString = url.getFile();
			fileString = fileString.substring(1, fileString.length());
			String[] directories = fileString.split("/");
			String directoryList = "";
			for (int i = 0; i < directories.length - 1; i++){
				System.out.println(directories[i]);
				directoryList = directoryList + directories[i];
				boolean success = (new File(directoryList)).mkdir();
						if (!success) {
						System.out.println("Directory Creation Error");
				}
				directoryList = directoryList + "\\";
			}

			File theFile = new File(fileString);
			FileOutputStream outStr = new FileOutputStream(theFile) ;

			byte[] buf = new byte[32 * 1024];
			int nRead = 0;
			while( (nRead=in.read(buf)) != -1 ) {
				outStr.write(buf, 0, nRead);
			}
			outStr.flush();
        	outStr.close();
		} catch(Exception ex){
			ex.printStackTrace();
		}

	}
}
