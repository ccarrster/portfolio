/*
 * PassDown.java
 *
 * Created on February 20, 2005, 4:48 PM
 */

package sequenceripper;

import java.net.*;
import java.io.*;

public class URLPassDown {

    public void downloadUrl(PassURL passURL){
		try{
			String userPassword = passURL.usernamePassword;
			URL url = new URL(passURL.urlString);
			String encoding = new sun.misc.BASE64Encoder().encode (userPassword.getBytes());
			URLConnection yc = url.openConnection();
			yc.setRequestProperty ("Authorization", "Basic " + encoding);
			BufferedInputStream in = new BufferedInputStream(yc.getInputStream());
			String fileString = url.getHost() + url.getFile();
			String[] directories = fileString.split("/");
			String directoryList = "";
			for (int i = 0; i < directories.length - 1; i++){
				System.out.println(directories[i]);
				directoryList = directoryList + directories[i];
				boolean success = (new File(directoryList)).mkdir();
						if (!success) {
						System.out.println("Directory Creation Error");
				}
				directoryList = directoryList + "\\";
			}

			File theFile = new File(fileString);
			FileOutputStream outStr = new FileOutputStream(theFile) ;

			byte[] buf = new byte[32 * 1024];
			int nRead = 0;
			while( (nRead=in.read(buf)) != -1 ) {
				outStr.write(buf, 0, nRead);
			}
			outStr.flush();
        	outStr.close();
		} catch(Exception ex){
			ex.printStackTrace();
			return;
		}

	}
}
