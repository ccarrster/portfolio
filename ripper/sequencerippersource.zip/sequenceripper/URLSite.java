/*
 * URLSite.java
 *
 * Created on February 20, 2005, 4:47 PM
 */

package sequenceripper;
import java.net.*;
import java.io.*;
import java.util.*;

public class URLSite {
	private String site;
	private String username;
	private String password;
	private ArrayList sequences;
	private int current;

	public URLSite(String site, String username, String password){
		this.site = site;
		this.username = username;
		this.password = password;
		sequences = new ArrayList();
		current = 0;
	}

	public void addSequence(String front, int start, int end, int digits, String back){
		sequences.add(new URLSequence(front, start, end, digits, back));
	}

	public PassURL next(){
		String endString = ((URLSequence)sequences.get(current)).next();
		if (endString.equals("")){
			if (++current >= sequences.size()){
				return new PassURL("", "");
			}
			endString = ((URLSequence)sequences.get(current)).next();
		}
		return new PassURL((username + ":" + password), (site + endString));
	}
}
