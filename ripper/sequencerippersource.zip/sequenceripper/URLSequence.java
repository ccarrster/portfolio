/*
 * URLSequence.java
 *
 * Created on February 20, 2005, 4:47 PM
 */

package sequenceripper;

import java.net.*;
import java.io.*;

public class URLSequence {
	private String front;
	private int start;
	private int end;
	private int digits;
	private String back;
	private int current;

	public URLSequence(String front, int start, int end, int digits, String back){
		this.front = front;
		this.start = start;
		this.end = end;
		this.digits = digits;
		this.back = back;
		current = start;
	}

	public String next(){
		if (current <= end){
			return front + zeroPad(digits, current++) + back;
		} else {
			return "";
		}
	}

	private String zeroPad (int digits, int number){
		if (digits == 0){
			return Integer.toString(number);
		}
		String zeros = "";
		int X = 1;
		for (int n = 0; n < digits; X = X * 10, n++){
			if ((number < X * 10 ) && (number >= X)){
				for (int l = 0; l < digits - n -1; l++){
					zeros = zeros + "0";
				}
			}
		}
		return zeros + number;
	}
}
