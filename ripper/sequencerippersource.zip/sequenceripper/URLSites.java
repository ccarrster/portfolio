/*
 * URLSites.java
 *
 * Created on February 20, 2005, 4:47 PM
 */

package sequenceripper;

import java.net.*;
import java.io.*;
import java.util.*;

public class URLSites {
	private ArrayList sites;
	private int current;
	private URLPassDown pd = new URLPassDown();

	public URLSites(){
		sites = new ArrayList();
		current = 0;
	}

	public void addSite(URLSite site){
		sites.add(site);
	}

	public void next(){
		for(;;){
			PassURL passURL = ((URLSite)sites.get(current)).next();
			if (passURL.urlString.equals("")){
				if (++current >= sites.size()){
					return;
				}
				passURL = ((URLSite)sites.get(current)).next();
			}
			pd.downloadUrl(passURL);
			continue;
		}
	}
}
