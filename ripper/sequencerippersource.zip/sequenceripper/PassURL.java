/*
 * PassURL.java
 *
 * Created on February 20, 2005, 4:48 PM
 */

package sequenceripper;

public class PassURL {
	String usernamePassword;
	String urlString;

	public PassURL(String usernamePassword, String urlString){
		this.usernamePassword = usernamePassword;
		this.urlString = urlString;
	}
}
