package com.chriscarr.rees.launcher;

import java.util.ArrayList;

import javax.swing.JScrollPane;

import com.chriscarr.rees.data.Services;
import com.chriscarr.rees.view.EntryPanel;
import com.chriscarr.rees.view.ReesFrame;
import com.chriscarr.rees.view.ReesMainPanel;
import com.chriscarr.rees.view.ReportingPanel;
import com.chriscarr.rees.view.TitledPanel;

public class Launcher {

	public static void main(String[] args) {
		ArrayList<TitledPanel> tabs = new ArrayList<TitledPanel>();
		Services services = new Services();
		tabs.add(new EntryPanel(services));
		tabs.add(new ReportingPanel("Reporting", services));
		ReesFrame rf = new ReesFrame();
		rf.getContentPane().add(new JScrollPane(new ReesMainPanel(tabs)));
		rf.setVisible(true);
	}

}
