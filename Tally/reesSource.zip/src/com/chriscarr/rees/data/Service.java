package com.chriscarr.rees.data;

public class Service {
	public Service(int serviceId, String serviceName, boolean editable, boolean reportable) {
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.editable = editable;
		this.reportable = reportable;
	}
	String serviceName;
	public String getServiceName() {
		return serviceName;
	}
	
	public int getServiceId() {
		return serviceId;
	}
	public boolean isEditable(){
		return editable;
	}
	public boolean isReportable(){
		return reportable;
	}
	
	int serviceId;
	boolean editable;
	boolean reportable;
}
