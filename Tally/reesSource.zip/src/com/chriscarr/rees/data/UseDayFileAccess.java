package com.chriscarr.rees.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class UseDayFileAccess {
	
	private static String phone = "phone";
	private static String walkin = "walkin";
	public static String directory = "REES stats";
	
	public static void saveUseDay(ServiceUseDay useDay){
		int id = useDay.getServiceId();
		Date day = useDay.getDay();
		int phoneUse = useDay.getPhoneUse();
		int walkinUse = useDay.getWalkinUse();
		File file = getFile(day);
		File dir = getDir(day);
		dir.mkdirs();
		Properties prop = new Properties();
		prop = loadProperties(file);
		prop.setProperty(id + "." + phone, Integer.toString(phoneUse));
		prop.setProperty(id + "." + walkin, Integer.toString(walkinUse));
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(file);
			prop.store(fos, "Header");
			fos.flush();
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static ServiceUseDay loadUseDay(Date day, int serviceId){
		ServiceUseDay useDay = new ServiceUseDay();
		useDay.setDay(day);
		useDay.setServiceId(serviceId);
		Properties prop = new Properties();
		File file = getFile(day);
		File dir = getDir(day);
		dir.mkdirs();
		prop = loadProperties(file);
		String phoneProp = prop.getProperty(serviceId + "." + phone);
		String walkinProp = prop.getProperty(serviceId + "." + walkin);
		if(phoneProp != null){
			useDay.setPhoneUse(Integer.parseInt(phoneProp));
		}
		if(walkinProp != null){
			useDay.setWalkinUse(Integer.parseInt(walkinProp));
		}
		return useDay;
	}
	
	public static List<ServiceUseDay> loadAllUseDay(Date day, ArrayList<Service> services){
		ArrayList<ServiceUseDay> serviceUseDays = new ArrayList<ServiceUseDay>();
		serviceUseDays.add(loadUseDay(day, 0));
		for(int i = 0; i < services.size(); i++){
			serviceUseDays.add(loadUseDay(day, services.get(i).getServiceId()));
		}
		return serviceUseDays;
	}
	
	private static File getFile(Date day){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(day);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		String sep = System.getProperty("file.separator");
		File file = new File("c:" + sep + directory + sep + year + sep + month + sep + dayOfMonth);
		return file;
	}
	
	private static File getDir(Date day){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(day);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		String sep = System.getProperty("file.separator");
		File dir = new File("c:" + sep + directory + sep + year + sep + month);
		return dir;
	}
	
	private static Properties loadProperties(File file){
		Properties prop = new Properties();
		FileInputStream fis;
		try {
			if(file.exists()){
				fis = new FileInputStream(file);
				prop.load(fis);
				fis.close();
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return prop;
	}
}
