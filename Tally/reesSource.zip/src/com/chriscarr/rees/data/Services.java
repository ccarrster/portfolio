package com.chriscarr.rees.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

public class Services {
	ArrayList<Service> services;
	
	public Services(){
		services = new ArrayList<Service>();
		try {
			loadServices(services);
		} catch (IOException e) {		
			e.printStackTrace();
		}
	}
	
	public ArrayList<Service> getServices(){
		return services;
	}
	
	String EDITABLE = "editable";
	String REPORTABLE = "reportable";
	
	private Service parsePropertyService(int serviceId, String serviceString){
		String[] strings = serviceString.split(";");
		if(strings.length == 3){
			String name = strings[0];
			String editable = strings[1];
			String reportable = strings[2];
			return new Service(serviceId, name, editable.equals(EDITABLE), reportable.equals(REPORTABLE));
		} else {
			return null;
		}
	}
	
	public void renameDirectory(){
		String sep = System.getProperty("file.separator");
		File oldDir = new File("c:" + sep + "REES"); 
		if(oldDir.exists()){
			oldDir.renameTo(new File("c:" + sep + UseDayFileAccess.directory));
		}
	}
	
	public void loadServices(ArrayList<Service> services) throws IOException{
		//Renames old directory
		renameDirectory();
		String sep = System.getProperty("file.separator");
		File propetiesFile = new File("c:" + sep + UseDayFileAccess.directory + sep + "services.properties");
		Properties properties;
		if(!propetiesFile.exists()){
			properties = createDefaultProperties(propetiesFile);
		} else {
			InputStream is = new FileInputStream(propetiesFile);
			properties = new Properties();
			properties.load(is);
			is.close();
		}
		int currentPropertyNum = 1;
		String serviceString = properties.getProperty(Integer.toString(currentPropertyNum));
		while(serviceString != null){
			services.add(parsePropertyService(currentPropertyNum, serviceString));
			currentPropertyNum++;
			serviceString = properties.getProperty(Integer.toString(currentPropertyNum));
		}
	}
	
	private Properties createDefaultProperties(File file) throws IOException{
		Properties properties = new Properties();
		int i = 1;
		properties.put(Integer.toString(i++), "Workshop conference sign-up;editable;reportable");
		properties.put(Integer.toString(i++), "Info/referrals to other programs;editable;reportable");
		properties.put(Integer.toString(i++), "Peer support/training info;editable;reportable");
		properties.put(Integer.toString(i++), "Peer support/request for contact;editable;reportable");
		properties.put(Integer.toString(i++), "Resource guide;editable;reportable");
		properties.put(Integer.toString(i++), "Library/newspapers bulletin boards;editable;reportable");
		properties.put(Integer.toString(i++), "Concord;editable;reportable");
		properties.put(Integer.toString(i++), "Support;editable;reportable");
		properties.put(Integer.toString(i++), "Info/referrals to other services;editable;reportable");
		properties.put(Integer.toString(i++), "Computer resume tutorial;editable;reportable");
		properties.put(Integer.toString(i++), "Workshop fax/phone;editable;reportable");
		properties.put(Integer.toString(i++), "CCLP sign-up;editable;reportable");
		properties.put(Integer.toString(i++), "CCLP appointment Check-in;editable;reportable");
		properties.put(Integer.toString(i++), "Computer use;editable;reportable");
		properties.put(Integer.toString(i++), "Mentoring;editable;reportable");
		properties.put(Integer.toString(i++), "Other;editable;reportable");
		FileOutputStream fos = new FileOutputStream(file);
		String commentString = "Numbers must be in order with no gaps from 1-n, renaming is fine, editable and reportable are needed for the last two values, any other value in their place will make the service uneditable or unreportable. Settings are separated with a semi-colon";
		properties.store(fos, commentString);
		fos.flush();
		fos.close();
		return properties;
	}
}
