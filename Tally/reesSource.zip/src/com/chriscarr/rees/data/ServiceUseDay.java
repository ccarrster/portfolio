package com.chriscarr.rees.data;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ServiceUseDay {
	Date day = new Date();
	int serviceId;
	int phoneUse;
	int walkinUse;
	
	public static List<ServiceUseDay> addLists(List<ServiceUseDay> addTo, List<ServiceUseDay> toAdd){
		for(Iterator<ServiceUseDay> addToIter = addTo.iterator(); addToIter.hasNext();){
			ServiceUseDay addToUseDay = addToIter.next();
			for(Iterator<ServiceUseDay> toAddIter = toAdd.iterator(); toAddIter.hasNext();){
				ServiceUseDay toAddUseDay = toAddIter.next();
				if(toAddUseDay.getServiceId() == addToUseDay.getServiceId()){
					addToUseDay.setWalkinUse(addToUseDay.getWalkinUse() + toAddUseDay.getWalkinUse());
					addToUseDay.setPhoneUse(addToUseDay.getPhoneUse() + toAddUseDay.getPhoneUse());
				}
			}
		}
		return addTo;
	}
	
	public Date getDay() {
		return day;
	}
	public void setDay(Date day) {
		this.day = day;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public void setPhoneUse(int phoneUse) {
		this.phoneUse = phoneUse;
	}
	public void setWalkinUse(int walkinUse) {
		this.walkinUse = walkinUse;
	}

	public int getWalkinUse() {
		return walkinUse;
	}
	public int getPhoneUse() {
		return phoneUse;
	}
	public int getTotal(){
		return phoneUse + walkinUse;
	}
	
	public int incrementPhoneUse(){
		return ++phoneUse;
	}
	
	public int incrementWalkinUse(){
		return ++walkinUse;
	}
	
	public int decrementPhoneUse(){
		return --phoneUse;
	}
	
	public int decrementWalkinUse(){
		return --walkinUse;
	}
}
