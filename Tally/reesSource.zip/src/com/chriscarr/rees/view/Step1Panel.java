package com.chriscarr.rees.view;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class Step1Panel extends JPanel {
	String stepString = "Step 1";
	EntryPanel ep;
	ClientPanel clientPanel;
	public Step1Panel(EntryPanel ep){
		clientPanel = new ClientPanel(ep);
		this.ep = ep;
		this.setBorder(new TitledBorder(stepString));
		this.add(clientPanel);
	}
	
	public void setEnabled(boolean enabled){
		clientPanel.setEnabled(enabled);
		if(enabled){
			this.setBackground(Color.WHITE);
		} else {
			this.setBackground(Color.LIGHT_GRAY);
		}
	}

	public void removeClient() {
		clientPanel.removeClient();
	}

	public void setOverrideMode(boolean selected) {
		clientPanel.setOverrideMode(selected);
	}

	public void save() {
		clientPanel.save();
	}

	public void load() {
		clientPanel.load();
	}

	public void switchDay() {
		clientPanel.switchDay();
	}

	public void overrideSuccess() {
		clientPanel.overrideSuccess();
	}
}
