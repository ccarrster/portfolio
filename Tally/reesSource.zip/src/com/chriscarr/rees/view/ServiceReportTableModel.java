package com.chriscarr.rees.view;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import com.chriscarr.rees.data.Service;
import com.chriscarr.rees.data.ServiceUseDay;
import com.chriscarr.rees.data.Services;

@SuppressWarnings("serial")
public class ServiceReportTableModel extends AbstractTableModel {

	List<List<ServiceUseDay>> useDays;
	Services services;
	int reportFormat;
	SimpleDateFormat day = new SimpleDateFormat("MMM - d");
	SimpleDateFormat week = new SimpleDateFormat("E");
	SimpleDateFormat month = new SimpleDateFormat("'Wk:'W");
	SimpleDateFormat quarter = new SimpleDateFormat("MMMM");
	
	public void setUseDays(List<List<ServiceUseDay>> useDays){
		this.useDays = useDays;
	}
	
	public void setServices(Services services){
		this.services = services;
	}
	
	public void setReportFormat(int reportFormat){
		this.reportFormat = reportFormat;
	}
	
	@Override
	public int getColumnCount() {
		//Title is the + 1 and each list item is a time period
		//* 2 is for 2 results per item
		try{
			return useDays.size() * 2 + 1;
		}catch(Exception e){
			return 1;
		}
	}

	@Override
	public int getRowCount() {
		//Each list of serviceUseDay is one complete time period summary
		//Plus one for the date header
		try{
			return useDays.get(0).size() + 1;
		}catch(Exception e){
			return 0;
		}
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		try{
			if(columnIndex == 0){
				if(rowIndex == 0){
					return "";
				}
				if(rowIndex == 1){
					return "Clients";
				} else {
					//Get the name of the service
					ServiceUseDay sud = useDays.get(0).get(rowIndex - 2);
					Service service = services.getServices().get(sud.getServiceId());
					return service.getServiceName();
				}
			} else {
				//Get the data
				if(rowIndex == 0){
					ServiceUseDay sud = useDays.get(((int)(columnIndex - 1) / 2)).get(rowIndex);
					String walkinString;
					if((((int)(columnIndex - 1) % 2)) == 0){
						walkinString = "W";
					} else {
						walkinString = "P";
					}
					if(reportFormat == ReportLoader2.DAYREPORT){
						return walkinString + ":" + day.format(sud.getDay());
					} else if(reportFormat == ReportLoader2.WEEKREPORT){
						return walkinString + ":" + week.format(sud.getDay());
					} else if(reportFormat == ReportLoader2.MONTHREPORT){
						return walkinString + ":" + month.format(sud.getDay());
					} else if(reportFormat == ReportLoader2.QUARTERREPORT){
						return walkinString + ":" + quarter.format(sud.getDay());
					}
					return day.format(sud.getDay());
				}
				ServiceUseDay sud = useDays.get(((int)((columnIndex - 1) / 2))).get(rowIndex - 1);
				if(((columnIndex - 1) % 2) == 0){
					return new Integer(sud.getWalkinUse());
				} else {
					return new Integer(sud.getPhoneUse());
				}
			}
		} catch (Exception e){
			e.printStackTrace();
			return null;
		}
	}
}
