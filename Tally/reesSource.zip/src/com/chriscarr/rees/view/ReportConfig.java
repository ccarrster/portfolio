package com.chriscarr.rees.view;

public class ReportConfig {
	int granularity;
	int numUnits;
	
	public ReportConfig(int granularity, int numUnits) {
		this.granularity = granularity;
		this.numUnits = numUnits;
	}

	public int getGranularity() {
		return granularity;
	}

	public int getNumUnits() {
		return numUnits;
	}
	
}
