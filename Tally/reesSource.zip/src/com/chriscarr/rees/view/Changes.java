package com.chriscarr.rees.view;

public class Changes {
	String service;
	String type;
	int oldValue;
	int newValue;

	public Changes(String service, String type, int oldValue, int newValue) {
		this.newValue = newValue;
		this.oldValue = oldValue;
		this.service = service;
		this.type = type;
	}
	public String toString(){
		return service + " " + type + " old value: " + oldValue + " new value: " + newValue;
	}
	public boolean equals(Object object){
		Changes changes = (Changes)object;
		return (changes.service.equals(service) && changes.type.equals(type));
	}
}
