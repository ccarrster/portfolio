package com.chriscarr.rees.view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

import com.chriscarr.rees.data.ServiceUseDay;
import com.chriscarr.rees.data.Services;
import com.toedter.calendar.JCalendar;

@SuppressWarnings("serial")
public class ReportingPanel extends TitledPanel implements ActionListener{

	JComboBox reportTypeCombo;
	JCalendar reportDate;
	JTable reportTable;
	ServiceReportTableModel tableModel;
	Services services;
	ReportLoader2 reportLoader;
	JButton makeReport;
	JButton printReport;
	String day = "Day";
	String week = "Week";
	String month = "Month";
	String quarter = "Quarter";
	
	JPanel optionsPanel;
	JPanel tablePanel;
	TitledBorder titleBorder;
	
	final Clipboard clipboard = this.getToolkit().getSystemClipboard();

	
	public ReportingPanel(String title, Services services) {
		super(title);
		reportLoader = new ReportLoader2(services);
		this.setLayout(new BorderLayout());
		
		optionsPanel = new JPanel();
		tablePanel = new JPanel();
		
		titleBorder = BorderFactory.createTitledBorder("");
		titleBorder.setTitleJustification(TitledBorder.CENTER);
		tablePanel.setBorder(titleBorder);
		
		reportTypeCombo = new JComboBox(new String[]{day, week, month, quarter});
		optionsPanel.add(reportTypeCombo);
		
		reportDate = new JCalendar(new Date());
		optionsPanel.add(reportDate);
		
		makeReport = new JButton("Make Report");
		makeReport.addActionListener(this);
		optionsPanel.add(makeReport);
		
		printReport = new JButton("Print Report");
		printReport.addActionListener(this);
		optionsPanel.add(printReport);
		
		tableModel = new ServiceReportTableModel();
		tableModel.setServices(services);
		
		reportTable = new JTable();
		reportTable.setModel(tableModel);
		tablePanel.add(reportTable);
		
		reportTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
		    
		    // method to override - returns cell renderer component
		    public Component getTableCellRendererComponent(JTable table, Object value, 
		                    boolean isSelected, boolean hasFocus, int row, int column) {

		        // let the default renderer prepare the component for us
		        Component comp = super.getTableCellRendererComponent(table, value, 
		                                            isSelected, hasFocus, row, column);

		        // now get the current font used for this cell
		        Font font = comp.getFont();

		        // check if this cell is in the second row
		        if (row == 1) {
		            comp.setFont(font.deriveFont(Font.BOLD));
		        }
		        else {    // cell is not in the second row
		            // set the default background and font
		            comp.setFont(font.deriveFont(Font.PLAIN));
		        }
		        return comp;
		    }
		});
		
		this.add(optionsPanel, BorderLayout.NORTH);
		this.add(tablePanel, BorderLayout.CENTER);
	}

	private void showPrintDialog(){
		try {
			reportTable.print();
		} catch (PrinterException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent evt) {
		Object source = evt.getSource();
		if(source == makeReport){
			try {
				makeReport();
			} catch (InvalidReportTypeException e) {
				e.printStackTrace();
			}
		} else if(source == printReport){
			showPrintDialog();				
		}
	}
	
	private void makeReport() throws InvalidReportTypeException{
		String reportType = (String)reportTypeCombo.getSelectedItem();
		Date startDate = reportDate.getDate();
		int reportTypeInt = -1;
		if(reportType.equals(day)){
			reportTypeInt = ReportLoader2.DAYREPORT;;
		} else if(reportType.equals(week)){
			reportTypeInt = ReportLoader2.WEEKREPORT;;
		} else if(reportType.equals(month)){
			reportTypeInt = ReportLoader2.MONTHREPORT;;
		} else if(reportType.equals(quarter)){
			reportTypeInt = ReportLoader2.QUARTERREPORT;;
		} else {
			throw new InvalidReportTypeException();
		}
		List<List<ServiceUseDay>> reportData = reportLoader.loadReport(startDate, reportTypeInt);
		tableModel.setReportFormat(reportTypeInt);
		tableModel.setUseDays(reportData);
		tableModel.fireTableStructureChanged();
		int numColumn = tableModel.getColumnCount();
		for(int i = 0; i < numColumn; i++){
			TableColumn col = reportTable.getColumnModel().getColumn(i);
			int width;
			if(i == 0){
				width = 200;
			} else {
				if(reportType.equals(week)){
					width = 50;
				} else if(reportType.equals(month)){
					width = 50;
				} else {
					width = 70;
				}
			}
		    col.setPreferredWidth(width);
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy MMMM, d EEEE");
		titleBorder.setTitle("Report Starting: " + dateFormat.format(reportLoader.getFirstDay(startDate, reportTypeInt)));
		exportToClipBoard();
		this.repaint();
	}
	
	private void exportToClipBoard(){
		int rows = tableModel.getRowCount();
		int columns = tableModel.getColumnCount();
		StringBuffer sb = new StringBuffer();
		for(int row = 0; row < rows; row++){
			for(int column = 0; column < columns; column++){
				sb.append((tableModel.getValueAt(row, column)).toString());
				sb.append(",");
			}
			sb.append("\n");
		}
		String text = sb.toString();
        StringSelection data = new StringSelection(text);
        clipboard.setContents(data, data);
	}
}
