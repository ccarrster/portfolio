package com.chriscarr.rees.view;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class TitledPanel extends JPanel {
	String title;

	public TitledPanel(String title){
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
