package com.chriscarr.rees.view;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JOptionPane;

import com.chriscarr.rees.data.Services;

@SuppressWarnings("serial")
public class EntryPanel extends TitledPanel implements DayChangeListener {
	Step1Panel s1p;
	Step2Panel s2p;
	Step3Panel s3p;
	
	public static int ADDPHASE = 0;
	public static int ENTRYPHASE = 1;
	public static int PHONE = 0;
	public static int WALKIN = 1;
	
	int phase;
	int clientType;
	DayChange dayChange;
	boolean switchDay = false;
	boolean override = false;
	ArrayList<Changes> changes = new ArrayList<Changes>();
	
	public EntryPanel(Services services){
		super("Entry");
		
		s1p = new Step1Panel(this);
		s2p = new Step2Panel(this, services);
		s3p = new Step3Panel(this);
		
		this.setLayout(new BorderLayout());
		this.add(s1p, BorderLayout.NORTH);
		this.add(s2p, BorderLayout.CENTER);
		this.add(s3p, BorderLayout.SOUTH);
		load();
		this.setPhase(ADDPHASE);
		dayChange = new DayChange();
		dayChange.addDayChangeListener(this);
	}
	
	public void setPhase(int phase){
		this.phase = phase;
		if(phase == ADDPHASE){
			s1p.setEnabled(true);
			s2p.setEnabled(false);
			s3p.setEnabled(false);
			if(switchDay){
				switchDay = false;
				switchDay();
			}
		} else if (phase == ENTRYPHASE){
			s1p.setEnabled(false);
			s2p.setEnabled(true);
			s3p.setEnabled(true);
		}
	}
	
	public void setClientType(int clientType){
		this.clientType = clientType;
		this.setPhase(ENTRYPHASE);
	}
	
	public int getClientType(){
		return clientType;
	}
	
	public int getPhase(){
		return phase;
	}

	public void removeClient() {
		s1p.removeClient();
		s2p.cancel();
	}

	//Enables override mode which makes text fields editable
	//Or disabled override mode which makes text fields uneditable and tries to save the changes
	public void setOverrideMode(boolean selected) {
		override = selected;
		if(selected){
			s1p.setEnabled(false);
			s2p.setEnabled(false);
			s3p.setEnabled(false);
			s1p.setOverrideMode(selected);
			s2p.setOverrideMode(selected);
			s3p.setOverrideMode(selected);
		} else {
			setPhase(ADDPHASE);
			s1p.setOverrideMode(selected);
			s2p.setOverrideMode(selected);
			s3p.setOverrideMode(selected);
			if(changes.size() > 0){
				Object[] options = {"Save Changes",
				                    "Revert All Changes"};
				int n = JOptionPane.showOptionDialog(this,
						changesToString(),
				    "Confirm Changes",
				    JOptionPane.YES_NO_OPTION,
				    JOptionPane.QUESTION_MESSAGE,
				    null,
				    options,
				    options[1]);
	
				if(n == JOptionPane.YES_OPTION){
					s1p.overrideSuccess();
					s2p.overrideSuccess();
					save();
					if(switchDay){
						switchDay = false;
						switchDay();
					}
				} else {
					load();
					if(switchDay){
						switchDay = false;
						switchDay();
					}
				}
			}
		}
		changes.clear();
	}

	public boolean isOverride() {
		return override;
	}

	public void save() {
		s1p.save();
		s2p.save();
	}
	
	private void load(){
		s1p.load();
		s2p.load();
	}

	public void dayChanged() {
		if(phase == ADDPHASE || override == false){
			switchDay();
		} else {
			switchDay = true;
		}
	}
	
	private void switchDay(){
		s1p.switchDay();
		s2p.switchDay();
	}

	public void cancelOverride() {
		s1p.load();
		s2p.load();
		setPhase(ADDPHASE);
		s1p.setOverrideMode(false);
		s2p.setOverrideMode(false);
		s3p.setOverrideMode(false);
	}

	public void readyToSave(String service, String type, int oldValue,
			int newValue) {
		Changes currentChange = new Changes(service, type, oldValue, newValue);
		changes.remove(currentChange);
		changes.add(currentChange);
	}

	public void removeNodifications(String service, String type) {
		changes.remove(new Changes(service, type, -1, -1));
	}
	
	public String changesToString(){
		StringBuffer sb = new StringBuffer();
		for(Iterator<Changes> iter = changes.iterator(); iter.hasNext();){
			sb.append(iter.next().toString());
			sb.append("\n");
		}
		return sb.toString();
	}

}
