package com.chriscarr.rees.view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;

public class DayChange extends TimerTask{
	
	long day = 86400000;
	ArrayList<DayChangeListener> dayChangeListeners;
	
	public DayChange(){
		dayChangeListeners = new ArrayList<DayChangeListener>();
		Timer timer = new Timer();
		Date startDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), 23, 59);		
		timer.scheduleAtFixedRate(this, calendar.getTime(), day);
	}

	public void run() {
		for(int i = 0; i < dayChangeListeners.size(); i++){
			dayChangeListeners.get(i).dayChanged();
		}
	}
	
	public void addDayChangeListener(DayChangeListener listener){
		dayChangeListeners.add(listener);
	}
	
	public void removeDayChangeListener(DayChangeListener listener){
		dayChangeListeners.remove(listener);
	}
}
