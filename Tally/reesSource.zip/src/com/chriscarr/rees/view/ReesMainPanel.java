package com.chriscarr.rees.view;

import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

@SuppressWarnings("serial")
public class ReesMainPanel extends JPanel {
	JTabbedPane tabbedPane;
	public ReesMainPanel(List<TitledPanel> panels){
		tabbedPane = new JTabbedPane();
		this.add(tabbedPane);
		for(int i = 0; i < panels.size(); i++){
			tabbedPane.add(panels.get(i), panels.get(i).getTitle());
		}
	}
}
