package com.chriscarr.rees.view;

public interface DayChangeListener {
	public void dayChanged();
}
