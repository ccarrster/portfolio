package com.chriscarr.rees.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class DonePanel extends JPanel implements ActionListener {
	JButton done;
	JButton cancel;
	EntryPanel ep;
	boolean overrideMode;
	public DonePanel(EntryPanel ep){
		this.ep = ep;
		cancel = new JButton("Cancel");
		done = new JButton("Done");
		cancel.addActionListener(this);
		done.addActionListener(this);
		this.add(cancel);
		this.add(done);
	}
	
	public void setEnabled(boolean enabled){
		cancel.setEnabled(enabled);
		done.setEnabled(enabled);
	}

	public void actionPerformed(ActionEvent evt) {
		Object source = evt.getSource();
		if(source == done){
			ep.setPhase(EntryPanel.ADDPHASE);
			ep.save();
		} else if(source == cancel){
			if(!ep.isOverride()){
				ep.removeClient();
				ep.setPhase(EntryPanel.ADDPHASE);
			} else {
				ep.cancelOverride();
			}
		}
	}

	public void setOverrideMode(boolean selected) {
		if(selected){
			cancel.setEnabled(true);
		} else {
			cancel.setEnabled(false);
		}
	}
}
