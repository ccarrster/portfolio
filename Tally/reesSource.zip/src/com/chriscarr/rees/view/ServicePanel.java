package com.chriscarr.rees.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.chriscarr.rees.data.Service;
import com.chriscarr.rees.data.ServiceUseDay;
import com.chriscarr.rees.data.UseDayFileAccess;

@SuppressWarnings("serial")
public class ServicePanel extends JPanel implements ActionListener, MouseListener {
	
	//JLabel name;
	JTextField walkinField;
	JTextField phoneField;
	JLabel walkTextLabel;
	JLabel phoneTextLabel;
	String type;
	JPanel southPanel = new JPanel();
	EntryPanel ep;
	Service service;
	ServiceUseDay useDay;
	JCheckBox checkBox;
	boolean overrideMode = false;
	
	public ServicePanel(Service service, EntryPanel ep){
		useDay = new ServiceUseDay();
		useDay.setServiceId(service.getServiceId());
		this.service = service;
		this.ep = ep;
		this.setPreferredSize(new Dimension(220, 58));
		this.setLayout(new BorderLayout());
		this.add(southPanel, BorderLayout.CENTER);
		this.type = service.getServiceName();
		this.setBorder(new TitledBorder(type));
		checkBox = new JCheckBox();
		walkinField = new JTextField("0");
		phoneField = new JTextField("0");
		walkinField.addMouseListener(this);
		phoneField.addMouseListener(this);
		walkinField.setPreferredSize(new Dimension(32, 20));
		phoneField.setPreferredSize(new Dimension(32, 20));
		walkinField.setEditable(false);
		phoneField.setEditable(false);
		walkTextLabel = new JLabel("Walk:");
		phoneTextLabel = new JLabel("Phone:");
		southPanel.add(walkTextLabel);
		southPanel.add(walkinField);
		southPanel.add(phoneTextLabel);
		southPanel.add(phoneField);
		southPanel.add(checkBox);
		checkBox.addActionListener(this);
	}

	public void setEnabled(boolean enabled){
		checkBox.setEnabled(enabled);
		checkBox.setSelected(false);
		if(enabled){
			this.setBackground(Color.WHITE);
			southPanel.setBackground(Color.WHITE);
		} else {
			this.setBackground(Color.LIGHT_GRAY);
			southPanel.setBackground(Color.LIGHT_GRAY);
		}
	}
	
	public void actionPerformed(ActionEvent evt) {
		if(checkBox.isSelected()){
			if(ep.getClientType() == EntryPanel.WALKIN){
				useDay.incrementWalkinUse();
			} else if(ep.getClientType() == EntryPanel.PHONE){
				useDay.incrementPhoneUse();
			} 
		} else {
			if(ep.getClientType() == EntryPanel.WALKIN){
				useDay.decrementWalkinUse();
			} else if(ep.getClientType() == EntryPanel.PHONE){
				useDay.decrementPhoneUse();
			}
		}
		walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		phoneField.setText(Integer.toString(useDay.getPhoneUse()));
	}

	public void cancel() {
		if(checkBox.isSelected()){
			if(ep.getClientType() == EntryPanel.WALKIN){
				useDay.decrementWalkinUse();
			} else if(ep.getClientType() == EntryPanel.PHONE){
				useDay.decrementPhoneUse();
			}
			walkinField.setText(Integer.toString(useDay.getWalkinUse()));
			phoneField.setText(Integer.toString(useDay.getPhoneUse()));
		}
	}

	public void setOverrideMode(boolean selected) {
		overrideMode = selected;
		if(selected){
			walkinField.setBackground(Color.green);
			phoneField.setBackground(Color.green);
		} else {
			walkinField.setBackground(Color.white);
			phoneField.setBackground(Color.white);
			int walkinUse;
			int phoneUse;
			try{
				walkinUse = Integer.parseInt(walkinField.getText());
				phoneUse = Integer.parseInt(phoneField.getText());
				if(walkinUse < 0 || phoneUse < 0){
					throw new Exception("Walkin Use or Phone Use can not be less than 0");
				}
			} catch(Exception e){
				JOptionPane.showMessageDialog(this,
					    e.getMessage(),
					    "Number error",
					    JOptionPane.ERROR_MESSAGE);
				walkinField.setText(Integer.toString(useDay.getWalkinUse()));
				phoneField.setText(Integer.toString(useDay.getPhoneUse()));
			}
		}
	}

	public void overrideSuccess(){
		int walkinUse = Integer.parseInt(walkinField.getText());
		int phoneUse = Integer.parseInt(phoneField.getText());
		useDay.setWalkinUse(walkinUse);
		useDay.setPhoneUse(phoneUse);
		save();
	}
	
	public void save() {
		UseDayFileAccess.saveUseDay(useDay);
	}

	public void load() {
		useDay = UseDayFileAccess.loadUseDay(new Date(), useDay.getServiceId());
		walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		phoneField.setText(Integer.toString(useDay.getPhoneUse()));
	}

	public void switchDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(useDay.getDay());
		calendar.add(Calendar.DATE, 1);
		useDay.setDay(calendar.getTime());
		useDay.setPhoneUse(0);
		useDay.setWalkinUse(0);
		walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		phoneField.setText(Integer.toString(useDay.getPhoneUse()));
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent evt) {
		if(overrideMode){
			Object source = evt.getSource();
			
			int value = 0;
			if(source == walkinField){
				value = Integer.parseInt(walkinField.getText());
			} else if(source == phoneField){
				value = Integer.parseInt(phoneField.getText());
			}
			int button = evt.getButton();
			if(button == MouseEvent.BUTTON1){
				value++;
			} else {
				if(value > 0){
					value--;
				}
			}
			if(source == walkinField){
				walkinField.setText(Integer.toString(value));
				if(value != useDay.getWalkinUse()){
					ep.readyToSave(type, "walkin", useDay.getWalkinUse(), value);
				} else {
					ep.removeNodifications(type, "phone");
				} 
			} else if(source == phoneField){
				phoneField.setText(Integer.toString(value));
				if(value != useDay.getPhoneUse()){
					ep.readyToSave(type, "phone", useDay.getPhoneUse(), value);
				} else {
					ep.removeNodifications(type, "phone");
				}
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}
}
