package com.chriscarr.rees.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.chriscarr.rees.data.ServiceUseDay;
import com.chriscarr.rees.data.UseDayFileAccess;

@SuppressWarnings("serial")
public class ClientPanel extends JPanel implements ActionListener, MouseListener{
	JButton walkin;
	JButton phone;
	EntryPanel ep;
	ServiceUseDay useDay;
	JTextField walkinField;
	JTextField phoneField;
	JLabel walkTextLabel;
	JLabel phoneTextLabel;
	JCheckBox overrideMode;
	JLabel dateLabel;
	public ClientPanel(EntryPanel ep){
		this.ep = ep;
		useDay = new ServiceUseDay();
		walkin = new JButton("Walkin Client");
		phone = new JButton("Phone Client");
		this.add(walkin);
		this.add(phone);
		walkinField = new JTextField("0");
		phoneField = new JTextField("0");
		walkinField.addMouseListener(this);
		phoneField.addMouseListener(this);
		walkinField.setPreferredSize(new Dimension(32, 20));
		phoneField.setPreferredSize(new Dimension(32, 20));
		walkinField.setEditable(false);
		phoneField.setEditable(false);
		walkTextLabel = new JLabel("Walk:");
		phoneTextLabel = new JLabel("Phone:");
		overrideMode = new JCheckBox("Override");
		dateLabel = new JLabel(useDay.getDay().toString());
		this.add(walkTextLabel);
		this.add(walkinField);
		this.add(phoneTextLabel);
		this.add(phoneField);
		this.add(dateLabel);
		this.add(overrideMode);
		walkin.addActionListener(this);
		phone.addActionListener(this);
		overrideMode.addActionListener(this);
	}
	
	public void setEnabled(boolean enabled){
		walkin.setEnabled(enabled);
		phone.setEnabled(enabled);
		if(!overrideMode.isSelected()){
			overrideMode.setEnabled(enabled);
		}
		if(enabled){
			this.setBackground(Color.WHITE);
		} else {
			this.setBackground(Color.LIGHT_GRAY);
		}
	}

	public void actionPerformed(ActionEvent evt) {
		Object source = evt.getSource();
		if(source == walkin){
			ep.setClientType(EntryPanel.WALKIN);
			useDay.incrementWalkinUse();
			walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		} else if(source == phone){
			ep.setClientType(EntryPanel.PHONE);
			useDay.incrementPhoneUse();
			phoneField.setText(Integer.toString(useDay.getPhoneUse()));
		} else if(source == overrideMode){
			ep.setOverrideMode(overrideMode.isSelected());
		}
	}

	public void removeClient() {
		if(ep.getClientType() == EntryPanel.WALKIN){
			useDay.decrementWalkinUse();
			walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		} else if(ep.getClientType() == EntryPanel.PHONE){
			useDay.decrementPhoneUse();
			phoneField.setText(Integer.toString(useDay.getPhoneUse()));
		}
	}

	public void setOverrideMode(boolean selected) {
		overrideMode.setSelected(selected);
		if(selected){
			walkinField.setBackground(Color.green);
			phoneField.setBackground(Color.green);
		} else {
			walkinField.setBackground(Color.white);
			phoneField.setBackground(Color.white);
			int walkinUse;
			int phoneUse;
			try{
				walkinUse = Integer.parseInt(walkinField.getText());
				phoneUse = Integer.parseInt(phoneField.getText());
				if(walkinUse < 0 || phoneUse < 0){
					throw new Exception("Walkin Use or Phone Use can not be less than 0");
				}
			} catch(Exception e){
				JOptionPane.showMessageDialog(this,
					    e.getMessage(),
					    "Number error",
					    JOptionPane.ERROR_MESSAGE);
				walkinField.setText(Integer.toString(useDay.getWalkinUse()));
				phoneField.setText(Integer.toString(useDay.getPhoneUse()));
			}
		}
	}

	public void overrideSuccess(){
		int walkinUse = Integer.parseInt(walkinField.getText());
		int phoneUse = Integer.parseInt(phoneField.getText());
		useDay.setWalkinUse(walkinUse);
		useDay.setPhoneUse(phoneUse);
		save();
	}
	
	public void save() {
		UseDayFileAccess.saveUseDay(useDay);
	}

	public void load() {
		useDay = UseDayFileAccess.loadUseDay(new Date(), 0);
		walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		phoneField.setText(Integer.toString(useDay.getPhoneUse()));
	}

	public void switchDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(useDay.getDay());
		calendar.add(Calendar.DATE, 1);
		useDay.setDay(calendar.getTime());
		useDay.setPhoneUse(0);
		useDay.setWalkinUse(0);
		walkinField.setText(Integer.toString(useDay.getWalkinUse()));
		phoneField.setText(Integer.toString(useDay.getPhoneUse()));
		dateLabel.setText(useDay.getDay().toString());
	}

	@Override
	public void mouseClicked(MouseEvent evt) {
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent evt) {
		if(overrideMode.isSelected()){
			Object source = evt.getSource();
			
			int value = 0;
			if(source == walkinField){
				value = Integer.parseInt(walkinField.getText());
			} else if(source == phoneField){
				value = Integer.parseInt(phoneField.getText());
			}
			int button = evt.getButton();
			if(button == MouseEvent.BUTTON1){
				value++;
			} else {
				if(value > 0){
					value--;
				}
			}
			if(source == walkinField){
				walkinField.setText(Integer.toString(value));
				if(value != useDay.getWalkinUse()){
					ep.readyToSave("client", "walkin", useDay.getWalkinUse(), value);
				} else {
					ep.removeNodifications("client", "phone");
				} 
			} else if(source == phoneField){
				phoneField.setText(Integer.toString(value));
				if(value != useDay.getPhoneUse()){
					ep.readyToSave("client", "phone", useDay.getPhoneUse(), value);
				} else {
					ep.removeNodifications("client", "phone");
				}
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		
	}
}
