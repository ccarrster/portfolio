package com.chriscarr.rees.view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.chriscarr.rees.data.Service;
import com.chriscarr.rees.data.ServiceUseDay;
import com.chriscarr.rees.data.Services;
import com.chriscarr.rees.data.UseDayFileAccess;

public class ReportLoader2 {
	ArrayList<Service> localServices;
	
	public static final int DAYREPORT = 0;
	public static final int WEEKREPORT = 1;
	public static final int MONTHREPORT = 2;
	public static final int QUARTERREPORT = 3;
	
	public ReportLoader2(Services services){
		localServices = new ArrayList<Service>();
		ArrayList<Service> tempServices = services.getServices();
		for(Iterator<Service> iter = tempServices.iterator(); iter.hasNext();){
			Service service = iter.next();
			if(service.isReportable()){
				localServices.add(service);
			}
		}
	}
	public List<List<ServiceUseDay>> loadReport(Date startDate, int reportType) throws InvalidReportTypeException{
		if(reportType == DAYREPORT){
			return loadDay(startDate);
		} else if(reportType == WEEKREPORT){
			return loadWeek(startDate);
		} else if(reportType == MONTHREPORT){
			return loadMonth(startDate);
		} else if(reportType == QUARTERREPORT){
			return loadQuarter(startDate);
		} else {
			throw new InvalidReportTypeException();
		}
	}

	public List<List<ServiceUseDay>> loadDay(Date startDate){
		List<List<ServiceUseDay>> days = new ArrayList<List<ServiceUseDay>>();
		days.add(UseDayFileAccess.loadAllUseDay(startDate, localServices));
		return days;
	}
	
	private Date getFirstDayOfWeek(Date date){
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		cal.add(Calendar.DATE, -dayOfWeek + 1);
		return cal.getTime();
	}
	
	private Date getFirstDayOfMonth(Date date){
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		//Set the start date to the first day of the month
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		cal.add(Calendar.DATE, -dayOfMonth + 1);
		return cal.getTime();
	}
	
	private Date getFirstDayOfQuarter(Date date){
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int quarter = (int)(cal.get(Calendar.MONTH) / 3.0);
		cal.set(Calendar.MONTH, quarter * 3);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();
	}
	
	public List<List<ServiceUseDay>> loadWeek(Date startDate){
		Calendar cal = Calendar.getInstance();
		cal.setTime(getFirstDayOfWeek(startDate));
		startDate = cal.getTime();
		List<List<ServiceUseDay>> days = new ArrayList<List<ServiceUseDay>>();
		int week = cal.get(Calendar.WEEK_OF_YEAR);
		while(cal.get(Calendar.WEEK_OF_YEAR) == week){
			days.add(UseDayFileAccess.loadAllUseDay(startDate, localServices));
			cal.add(Calendar.DATE, 1);
			startDate = cal.getTime();
		}
		//Remove sat/sun
		days.remove(0);
		days.remove(days.size() - 1);
		return days;
	}
	
	public List<List<ServiceUseDay>> loadMonth(Date startDate){
		Calendar cal = Calendar.getInstance();
		cal.setTime(getFirstDayOfMonth(startDate));
		startDate = cal.getTime();
		List<List<ServiceUseDay>> days = new ArrayList<List<ServiceUseDay>>();
		int month = cal.get(Calendar.MONTH);
		int week = cal.get(Calendar.WEEK_OF_YEAR);
		while(cal.get(Calendar.MONTH) == month){
			List<ServiceUseDay> group = new ArrayList<ServiceUseDay>();
			while(cal.get(Calendar.WEEK_OF_YEAR) == week && cal.get(Calendar.MONTH) == month){
				group = ServiceUseDay.addLists(UseDayFileAccess.loadAllUseDay(startDate, localServices), group);
				cal.add(Calendar.DATE, 1);
				startDate = cal.getTime();
			}
			week++;
			days.add(group);
		}
		return days;
	}
	
	public List<List<ServiceUseDay>> loadQuarter(Date startDate){
		Calendar cal = Calendar.getInstance();
		cal.setTime(getFirstDayOfQuarter(startDate));
		int quarter = (int)(cal.get(Calendar.MONTH) / 3.0);
		startDate = cal.getTime();
		List<List<ServiceUseDay>> days = new ArrayList<List<ServiceUseDay>>();
		//Still in quarter
		int month = quarter * 3;
		while(((int)(month / 3.0)) == quarter){
			List<ServiceUseDay> group = new ArrayList<ServiceUseDay>();
			//Still in month
			while(cal.get(Calendar.MONTH) == month){
				group = ServiceUseDay.addLists(UseDayFileAccess.loadAllUseDay(startDate, localServices), group);
				cal.add(Calendar.DATE, 1);
				startDate = cal.getTime();
			}
			month++;
			days.add(group);
		}
		return days;
	}
	
	public Date getFirstDay(Date date, int reportType) throws InvalidReportTypeException{
		if(reportType == DAYREPORT){
			return date;
		} else if(reportType == WEEKREPORT){
			return getFirstDayOfWeek(date);
		} if(reportType == MONTHREPORT){
			return getFirstDayOfMonth(date);
		} else if(reportType == QUARTERREPORT){
			return getFirstDayOfQuarter(date);
		} else {
			throw new InvalidReportTypeException();
		}
	}
}
