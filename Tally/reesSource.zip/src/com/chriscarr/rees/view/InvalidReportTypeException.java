package com.chriscarr.rees.view;

@SuppressWarnings("serial")
public class InvalidReportTypeException extends Exception {

}
