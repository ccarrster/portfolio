package com.chriscarr.rees.view;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class Step3Panel extends JPanel {
	String stepString = "Step 3";
	EntryPanel ep;
	DonePanel donePanel;
	public Step3Panel(EntryPanel ep){
		donePanel = new DonePanel(ep);
		this.ep = ep;
		this.setBorder(new TitledBorder(stepString));
		this.add(donePanel);
	}
	
	public void setEnabled(boolean enabled){
		donePanel.setEnabled(enabled);
		if(enabled){
			this.setBackground(Color.WHITE);
		} else {
			this.setBackground(Color.LIGHT_GRAY);
		}
	}

	public void setOverrideMode(boolean selected) {
		donePanel.setOverrideMode(selected);
	}
}
