package com.chriscarr.rees.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import com.chriscarr.rees.data.Service;
import com.chriscarr.rees.data.Services;

@SuppressWarnings("serial")
public class Step2Panel extends JPanel {
	String stepString = "Step 2";
	Services services;
	EntryPanel ep;
	ArrayList<ServicePanel> servicePanels;
	public Step2Panel(EntryPanel ep, Services services){
		this.ep = ep;
		servicePanels = new ArrayList<ServicePanel>();
		this.services = services;
		this.setBorder(new TitledBorder(stepString));
		this.setLayout(new GridLayout(0, 3));
		ArrayList<Service> servicesList = services.getServices();
		for(int i = 0; i < servicesList.size(); i++){
			Service service = servicesList.get(i);
			if(service.isEditable()){
				ServicePanel sp = new ServicePanel(service, ep);
				servicePanels.add(sp);
				this.add(sp);
			}
		}
	}
	
	public void setEnabled(boolean enabled){
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).setEnabled(enabled);
		}
		if(enabled){
			this.setBackground(Color.WHITE);
		} else {
			this.setBackground(Color.LIGHT_GRAY);
		}
	}

	public void cancel() {
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).cancel();
		}
	}

	public void setOverrideMode(boolean selected) {
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).setOverrideMode(selected);
		}
	}

	public void save() {
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).save();
		}
	}

	public void load() {
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).load();
		}
	}

	public void switchDay() {
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).switchDay();
		}
	}

	public void overrideSuccess() {
		for(int i = 0; i < servicePanels.size(); i++){
			servicePanels.get(i).overrideSuccess();
		}
	}
}
