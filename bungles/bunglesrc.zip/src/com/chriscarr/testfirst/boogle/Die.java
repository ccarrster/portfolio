package com.chriscarr.testfirst.boogle;

public class Die {
	String[] chars;
	String currentChar;
	public Die(String[] chars){		
		this.chars = chars;
		currentChar = getRandomChar();
	}
	
	public String getRandomChar(){
		currentChar = chars[(int)(Math.random() * chars.length)];
		return currentChar;		
	}	
	
	public String getCurrentChar(){
		return currentChar;
	}	
}
