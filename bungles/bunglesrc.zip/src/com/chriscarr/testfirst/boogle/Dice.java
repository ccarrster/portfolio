package com.chriscarr.testfirst.boogle;

import java.util.ArrayList;
import java.util.List;



public class Dice {
	public static List<Die> getDefaultDice(){
		List<Die> dice = new ArrayList<Die>();
		int diceTotal = 16;
		String[][] diceArray = new String[diceTotal][6];
		int diceCounter = 0;
		diceArray[diceCounter++] = new String[]{"R", "Y", "V", "D", "E", "L"};
		diceArray[diceCounter++] = new String[]{"V", "W", "H", "E", "T", "R"};
		diceArray[diceCounter++] = new String[]{"J", "B", "O", "O", "B", "A"};
		diceArray[diceCounter++] = new String[]{"T", "I", "T", "S", "Y", "D"};
		diceArray[diceCounter++] = new String[]{"N", "G", "E", "W", "E", "H"};
		diceArray[diceCounter++] = new String[]{"L", "I", "E", "R", "X", "D"};
		diceArray[diceCounter++] = new String[]{"P", "A", "H", "S", "O", "C"};
		diceArray[diceCounter++] = new String[]{"R", "E", "T", "T", "Y", "L"};
		diceArray[diceCounter++] = new String[]{"S", "S", "O", "I", "T", "E"};
		diceArray[diceCounter++] = new String[]{"O", "O", "W", "T", "T", "A"};
		diceArray[diceCounter++] = new String[]{"E", "N", "G", "E", "A", "A"};		
		diceArray[diceCounter++] = new String[]{"Qu", "H", "M", "U", "N", "I"};
		diceArray[diceCounter++] = new String[]{"S", "P", "F", "A", "K", "F"};
		diceArray[diceCounter++] = new String[]{"S", "E", "E", "U", "I", "N"};
		diceArray[diceCounter++] = new String[]{"N", "H", "N", "L", "Z", "R"};
		diceArray[diceCounter++] = new String[]{"U", "O", "C", "M", "I", "T"};
		for(int diceIndex = 0; diceIndex < diceTotal; diceIndex++){
			dice.add(new Die(diceArray[diceIndex]));
		}
		return dice;
	}
}
