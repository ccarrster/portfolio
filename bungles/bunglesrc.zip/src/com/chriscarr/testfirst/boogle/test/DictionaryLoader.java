package com.chriscarr.testfirst.boogle.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.chriscarr.testfirst.boogle.Dictionary;

public class DictionaryLoader {
	public static List<String> loadDictionaryFromFile(String fileName) throws Exception{
		File dictionaryFile = new File(fileName);
		if(dictionaryFile.exists()){
			if(dictionaryFile.isFile()){
				List<String> wordList = new ArrayList<String>();					
				BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream(dictionaryFile)));
				String line;
				line = fileReader.readLine();					
				while(line != null){
					if(Dictionary.isWordClean(line)){
						wordList.add(line);
					} else {
						throw new Exception("Invalid format");
					}
					line = fileReader.readLine();
				}
				return wordList;
			}
		} else {
			throw new FileNotFoundException();
		}
		return null;
	}
}
