package com.chriscarr.testfirst.boogle.test;

import junit.framework.TestCase;

import com.chriscarr.testfirst.boogle.Dice;
import com.chriscarr.testfirst.boogle.LetterGrid;


public class TestLetterGrid extends TestCase{
	public void testGetValidLetterGrid(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = "a";
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.isValidLetterGrid());
	}
	
	public void testGetInvalidLetterGridEmptyString(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = "";
		LetterGrid letterGrid = new LetterGrid(letters);
		assertFalse(letterGrid.isValidLetterGrid());
	}
	
	public void testGetInvalidLetterGridNullString(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = null;
		LetterGrid letterGrid = new LetterGrid(letters);
		assertFalse(letterGrid.isValidLetterGrid());
	}
	
	public void testGetInvalidLetterGridUnsetString(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		LetterGrid letterGrid = new LetterGrid(letters);
		assertFalse(letterGrid.isValidLetterGrid());
	}
	
	public void testGetInvalidLetterGridUninitializedDimension(){
		String[][] letters = new String[1][1];		
		LetterGrid letterGrid = new LetterGrid(letters);
		assertFalse(letterGrid.isValidLetterGrid());
	}
	
	public void testGetInvalidLetterGridDefaultDice(){
		LetterGrid letterGrid = new LetterGrid(Dice.getDefaultDice());
		boolean validGrid = letterGrid.isValidLetterGrid();
		if(!validGrid){
			fail();
		}
	}
	
	public void testGetInvalidLetterGridManyChars(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = "ab";
		LetterGrid letterGrid = new LetterGrid(letters);
		assertFalse(letterGrid.isValidLetterGrid());
	}
	
	public void testGetInvalidLetterGridInvalidChars(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = " ";
		LetterGrid letterGrid = new LetterGrid(letters);
		assertFalse(letterGrid.isValidLetterGrid());
	}
	
	public void testAllLetters(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		String testLetter = "a";
		letters[0][0] = testLetter;		
		LetterGrid letterGrid = new LetterGrid(letters);
		String letterList = letterGrid.getAllLetters();
		assertTrue(letterList.length() == 1);
		assertTrue(letterList.contains(testLetter));
		assertTrue(letterList.substring(0, 1).equals(testLetter));
	}
	
	public void testAllLettersMultiDimensional(){
		int width = 1;
		int hegith = 2;
		String[][] letters = new String[width][hegith];
		letters[0] = new String[hegith];
		String testLetter = "a";
		letters[0][0] = testLetter;
		letters[0][1] = testLetter;
		LetterGrid letterGrid = new LetterGrid(letters);
		String letterList = letterGrid.getAllLetters();
		assertTrue(letterList.length() == 2);
		assertTrue(letterList.contains(testLetter));
		assertTrue(letterList.substring(0, 1).equals(testLetter));
		assertTrue(letterList.substring(1, 2).equals(testLetter));
	}
	
	public void testAllLettersMultiInvalidLetterGrid(){
		int width = 1;
		int hegith = 2;
		String[][] letters = new String[width][hegith];
		letters[0] = new String[hegith];
		String testLetter = "";
		letters[0][0] = testLetter;
		letters[0][1] = testLetter;
		LetterGrid letterGrid = new LetterGrid(letters);
		String letterList = letterGrid.getAllLetters();
		assertTrue(letterList == null);		
	}
	
	public void testValidLetterGrid(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = "a";		
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.getGridWidth() == 1);
		assertTrue(letterGrid.getGridHeight() == 1);
	}
	
	public void testInvalidLetterGrid(){
		String[][] letters = new String[1][1];
		letters[0] = new String[1];
		letters[0][0] = " ";		
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.getGridWidth() == -1);
		assertTrue(letterGrid.getGridHeight() == -1);
	}	
	
	public void testWordInGrid(){
		String[][] letters = new String[][]{{"f", "a", "a", "a"}, {"a", "i", "a", "a"}, {"a", "a", "s", "a"}, {"a", "h", "a", "a"}};				
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.wordInGrid("fish"));
		assertTrue(letterGrid.wordInGrid("hsif"));
		assertFalse(letterGrid.wordInGrid("fshi"));
	}
	
	public void testQWordInGrid(){
		String[][] letters = new String[][]{{"Qu", "i", "c", "k"}, {"a", "i", "k", "a"}, {"a", "a", "s", "a"}, {"a", "h", "a", "a"}};				
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.wordInGrid("quick"));		
		assertFalse(letterGrid.wordInGrid("fshi"));
	}
	
	public void testWordInGridOneLetter(){
		String[][] letters = new String[][]{{"f", "a", "a", "a"}, {"a", "i", "a", "a"}, {"a", "a", "s", "a"}, {"a", "h", "a", "a"}};				
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.wordInGrid("f"));
		assertFalse(letterGrid.wordInGrid("b"));
	}
	
	public void testGetLetterAt(){
		String[][] letters = new String[][]{{"a", "b"}, {"c", "d"}};
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.getLetterAt(0, 0).equals("a"));
		assertTrue(letterGrid.getLetterAt(0, 1).equals("b"));
		assertTrue(letterGrid.getLetterAt(1, 0).equals("c"));
		assertTrue(letterGrid.getLetterAt(1, 1).equals("d"));		
	}
	
	public void testGetLetterAtInvalidBounds(){
		String[][] letters = new String[][]{{"a", "b"}, {"c", "d"}};
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.getLetterAt(0, 2) == null);			
	}
	
	public void testWordInGridGetGets(){
		String[][] letters = new String[][]{{"v", "s", "g", "t"}, {"t", "t", "e", "p"}, {"i", "e", "n", "i"}, {"t", "l", "a", "a"}};				
		LetterGrid letterGrid = new LetterGrid(letters);
		assertTrue(letterGrid.wordInGrid("get"));
		assertTrue(letterGrid.wordInGrid("gets"));		
	}
}
