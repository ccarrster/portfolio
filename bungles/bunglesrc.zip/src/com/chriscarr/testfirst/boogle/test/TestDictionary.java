package com.chriscarr.testfirst.boogle.test;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.chriscarr.testfirst.boogle.Dictionary;

import junit.framework.TestCase;

public class TestDictionary extends TestCase{	
	
	public void testLoadDictionary(){
		try {
			
			new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
		} catch (FileNotFoundException e) {
			fail();
		} catch (IOException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testLoadDictionaryWithInvalidChars(){		
		try {
			new Dictionary(DictionaryLoader.loadDictionaryFromFile("invalidcharboggle.txt"));
			fail();
		} catch (FileNotFoundException e) {
			fail();
		} catch (IOException e) {
			fail();
		} catch (Exception e) {
			//Expected result
		}
	}
	
	public void testLoadNoFileDictionary(){
		try{
			new Dictionary(DictionaryLoader.loadDictionaryFromFile("nonexistant.txt"));
			fail();
		} catch(FileNotFoundException ex){
			//Expected
		} catch (IOException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testLoadNullDictionary(){
		try{
			new Dictionary(null);
			fail();
		} catch(NullPointerException ex){
			//Pass
		} catch (FileNotFoundException e) {
			fail();
		} catch (IOException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testGetFirstValueInDictionaryLowerCase(){
		Dictionary dictionary;
		try {
			dictionary = new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
			boolean isWord = dictionary.isWordInDicitonary("aah");
			assertTrue(isWord);
		} catch (FileNotFoundException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
		
	}
	
	public void testGetLastValueInDictionaryLowerCase(){
		Dictionary dictionary;
		try {
			dictionary = new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
			boolean isWord = dictionary.isWordInDicitonary("zyzzyvas");
			assertTrue(isWord);
		} catch (FileNotFoundException e) {
			fail();
		} catch (Exception e) {
			fail();
		}		
	}
	
	public void testGetValueNotInDictionary(){
		try{
			Dictionary dictionary = new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
			boolean isWord = dictionary.isWordInDicitonary("aaa");
			assertTrue(!isWord);
		} catch (FileNotFoundException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testGetValueWithWrongChars(){
		Dictionary dictionary;
		try {
			dictionary = new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
			try{
				dictionary.isWordInDicitonary("aa2");
				fail();
			}catch(Exception ex){}
			try{
				dictionary.isWordInDicitonary("aa_");
				fail();
			}catch(Exception ex){}
			try{
				dictionary.isWordInDicitonary("aa'");
				fail();
			}catch(Exception ex){}
			try{
				dictionary.isWordInDicitonary("a a");
				fail();
			}catch(Exception ex){}
		} catch (FileNotFoundException e) {
			fail();
		} catch (IOException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testGetValueInDictionaryMixedCase(){
		Dictionary dictionary;
		try {
			dictionary = new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
			boolean isWord = dictionary.isWordInDicitonary("aAh");
			assertTrue(isWord);
		} catch (FileNotFoundException e) {
			fail();
		} catch (Exception e) {
			fail();
		}
	}
	
	public void testGetValueInDictionaryUpperCase(){
		Dictionary dictionary;
		try {
			dictionary = new Dictionary(DictionaryLoader.loadDictionaryFromFile("boggle.txt"));
			boolean isWord = dictionary.isWordInDicitonary("AAH");
			assertTrue(isWord);
		} catch (FileNotFoundException e) {
			fail();
		} catch (Exception e) {
			fail();
		}	
	}
	
	public void testScoreWord(){
		assertEquals(Dictionary.scoreWord(null), -1);
		assertEquals(Dictionary.scoreWord(""), -1);
		assertEquals(Dictionary.scoreWord("ab"), -1);
		assertEquals(Dictionary.scoreWord("abc"), 1);
		assertEquals(Dictionary.scoreWord("abcd"), 1);
		assertEquals(Dictionary.scoreWord("abcde"), 2);
		assertEquals(Dictionary.scoreWord("abcdef"), 3);
		assertEquals(Dictionary.scoreWord("abcdefg"), 5);
		assertEquals(Dictionary.scoreWord("abcdefgh"), 11);
		assertEquals(Dictionary.scoreWord("abcdefghasdfasdfasdf"), 11);
	}
}
