package com.chriscarr.testfirst.boogle.test;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite(
				"Test for com.chriscarr.testfirst.boogle.test");
		//$JUnit-BEGIN$
		suite.addTestSuite(TestIsWordInLetters.class);
		suite.addTestSuite(TestDictionary.class);
		suite.addTestSuite(TestLetterGrid.class);
		suite.addTestSuite(TestWordLists.class);
		suite.addTestSuite(TestTimer.class);
		//$JUnit-END$
		return suite;
	}

}
