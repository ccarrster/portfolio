package com.chriscarr.testfirst.boogle.test;

import java.util.ArrayList;
import java.util.List;

import com.chriscarr.testfirst.boogle.Dictionary;

import junit.framework.TestCase;

public class TestWordLists extends TestCase {
	public void testWordLists(){
		List<List<String>> wordLists = new ArrayList<List<String>> ();
		List<String> wordListPlayer1 = new ArrayList<String>();
		List<String> wordListPlayer2 = new ArrayList<String>();
		List<String> wordListPlayer3 = new ArrayList<String>();
		wordListPlayer1.add("fish");
		wordListPlayer2.add("fish");
		wordListPlayer3.add("fish");
		wordListPlayer1.add("goat");
		wordListPlayer2.add("goat");
		wordListPlayer1.add("ninja");
		wordLists.add(wordListPlayer1);
		wordLists.add(wordListPlayer2);
		wordLists.add(wordListPlayer3);
		Dictionary.removeDuplicateWords(wordLists);
		assertTrue(wordListPlayer1.size() == 1);
		assertTrue(wordListPlayer2.size() == 0);
		assertTrue(wordListPlayer3.size() == 0);
	}
}
