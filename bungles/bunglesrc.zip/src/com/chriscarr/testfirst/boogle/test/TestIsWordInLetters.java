package com.chriscarr.testfirst.boogle.test;

import com.chriscarr.testfirst.boogle.Dictionary;

import junit.framework.TestCase;

public class TestIsWordInLetters extends TestCase {
	public void testWordValidInChars(){
		String board = "hsifxxx";
		boolean result = Dictionary.isWordInLetters("fish", board);
		assertTrue(result);
	}
	
	public void testWordInvalidInChars(){
		String board = "hsifxxx";
		boolean result = Dictionary.isWordInLetters("xxxx", board);
		assertTrue(result);
	}
	
	public void testWordValidSplitInChars(){
		String board = "hxsifxxx";
		boolean result = Dictionary.isWordInLetters("xxxx", board);
		assertTrue(result);
	}
	
	public void testWordMixedCaseWordValidSplitInChars(){
		String board = "hxsifxxx";
		boolean result = Dictionary.isWordInLetters("xXxx", board);
		assertTrue(result);
	}
	
	public void testWordMixedCaseBoardValidSplitInChars(){
		String board = "hxsifXxx";
		boolean result = Dictionary.isWordInLetters("xxxx", board);
		assertTrue(result);
	}
}
