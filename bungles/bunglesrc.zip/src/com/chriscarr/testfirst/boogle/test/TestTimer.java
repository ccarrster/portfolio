package com.chriscarr.testfirst.boogle.test;

import com.chriscarr.testfirst.boogle.Dictionary;
import java.util.TimerTask;

import junit.framework.TestCase;

public class TestTimer extends TestCase{
	public void testTimer(){
		TimesUp task = new TimesUp();
		Dictionary.startTimer(100, task);
		assertFalse(task.timesUp);
		try {
			Thread.sleep(150);
		} catch (InterruptedException e) {
		}
		assertTrue(task.timesUp);
	}
	private class TimesUp extends TimerTask{
		public boolean timesUp = false;
		public void run() {
			timesUp = true;
		}
	}

	
}
