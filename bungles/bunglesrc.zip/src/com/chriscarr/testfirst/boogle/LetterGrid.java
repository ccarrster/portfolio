package com.chriscarr.testfirst.boogle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class LetterGrid {
	//Width then height, X, Y
	private String[][] letterGrid = null;
	private static final String EMPTYSTRING = "";
	public LetterGrid(String[][] letterGrid){
		this.letterGrid = letterGrid;
		if(!isValidLetterGrid()){
			this.letterGrid = null;
		}
	}
	
	public LetterGrid(List<Die> dice) {
		double squareRoot = Math.sqrt(dice.size());
		if(squareRoot % 1.0 == 0){
			int gridSize = (int)squareRoot;
			String[][] letterGrid = new String[gridSize][gridSize];
			Iterator<Die> diceIter = dice.iterator();			
			for(int width = 0; width < gridSize; width++){
				letterGrid[width] = new String[gridSize];
				for(int height = 0; height < gridSize; height++){
					if(diceIter.hasNext()){
						letterGrid[width][height] = diceIter.next().getRandomChar();
					}
				}
			}
			this.letterGrid = letterGrid;
		}
	}

	public int getGridWidth(){
		if(isValidLetterGrid()){
			return letterGrid.length;
		} else {
			return -1;
		}		
	}
	
	public int getGridHeight(){
		if(isValidLetterGrid()){
			return letterGrid[0].length;
		} else {
			return -1;
		}
	}
	
	/**
	 * Must contain at least a [1][1] 2 dimensional array of String
	 * The Strings must not be null or empty string
	 * The Strings length must be 1 character
	 * The Strings must be a-z
	 * The Strings will be saved as lowercase
	 * @param letterGrid
	 * @return
	 */
	public boolean isValidLetterGrid(){
		if(letterGrid == null){
			return false;
		} else if(letterGrid.length == 0){
			return false;
		} else if(letterGrid[0].length == 0){
			return false;
		}		
		for(int widthIndex = 0; widthIndex < letterGrid.length; widthIndex++){
			for(int heightIndex = 0; heightIndex < letterGrid[0].length; heightIndex++){
				String letter = letterGrid[widthIndex][heightIndex];
				if(letter == null){
					return false;
				} else if(letter.equals("")){
					return false;
				} else if(letter.length() != 1 && !letter.toLowerCase().equals("qu")){
					return false;
				} else if(!Dictionary.isWordClean(letter)){
					return false;
				}
			}
		}
		return true;
	}
	
	public String getAllLetters(){		
		if(letterGrid != null){
			StringBuffer allLetters = new StringBuffer();
			for(int widthIndex = 0; widthIndex < letterGrid.length; widthIndex++){
				for(int heightIndex = 0; heightIndex < letterGrid[0].length; heightIndex++){
					allLetters.append(letterGrid[widthIndex][heightIndex]);
				}
			}
			return allLetters.toString();
		} else {
			return null;
		}
	}

	private boolean containsCharacters(String word) {
		if(isValidLetterGrid()){
			if(word != null && !word.equals(EMPTYSTRING)){
				return Dictionary.isWordInLetters(word, getAllLetters());
			}
		}
		return false;
	}

	public boolean wordInGrid(String word) {
		word = word.toLowerCase();
		if(!containsCharacters(word)){
			return false;
		} else {	
			String firstLetter = word.substring(0, 1);
			if(firstLetter.equals("q")){
				if(word.length() >= 2 && word.substring(0, 2).equals("qu")){
					firstLetter = "qu";
				}
			}
			for(int widthIndex = 0; widthIndex < letterGrid.length; widthIndex++){
				for(int heightIndex = 0; heightIndex < letterGrid[0].length; heightIndex++){					
					String currentLetter = letterGrid[widthIndex][heightIndex].toLowerCase();
					if(firstLetter.equals(currentLetter)){
						List<Point> matchedLetters = new ArrayList<Point>();
						matchedLetters.add(new Point(widthIndex, heightIndex));
						if(!firstLetter.equals("qu")){
							if(wordInGrid(matchedLetters, word.substring(1).toLowerCase())){
								return true;
							}
						} else {
							if(wordInGrid(matchedLetters, word.substring(2).toLowerCase())){
								return true;
							}
						}
					}
				}
			}			
			return false;
		}		
	}
	
	private boolean wordInGrid(List<Point> matchedLetters, String remainingLetters){
		if(remainingLetters.equals(EMPTYSTRING)){
			return true;
		} else {
			Point lastPoint = matchedLetters.get(matchedLetters.size() - 1);
			List<Point> neighbours = getNeighbours(lastPoint);
			//Removes all the neighbours already used in the word
			neighbours.removeAll(matchedLetters);
			for(Iterator<Point> neighbourIter = neighbours.iterator(); neighbourIter.hasNext();){
				Point neighbourPoint = neighbourIter.next();
				String neighbourLetter = letterGrid[neighbourPoint.getWidth()][neighbourPoint.getHeight()].toLowerCase();
				if(neighbourLetter.equals(remainingLetters.substring(0, 1))){
					matchedLetters.add(neighbourPoint);
					if (wordInGrid(matchedLetters, remainingLetters.substring(1))){
						return true;
					}
				}
			}			
		}
		return false;	
	}
	
	private List<Point> getNeighbours(Point point){
		int width = point.getWidth();
		int height = point.getHeight();
		int gridWidth = letterGrid.length;
		int gridHeight = letterGrid[0].length;
		List<Point> neighbours = new ArrayList<Point>();
		if(width > 0 && height < gridHeight - 1){	
			neighbours.add(new Point(width - 1, height + 1));			
		}
		
		if(height < gridHeight - 1){
			neighbours.add(new Point(width, height + 1));			
		}
		
		if(width < gridWidth - 1 && height < gridHeight - 1){
			neighbours.add(new Point(width + 1, height + 1));			
		}
		
		if(width > 0 && height > 0){
			neighbours.add(new Point(width - 1, height - 1));			
		}
		
		if(height > 0){
			neighbours.add(new Point(width, height - 1));			
		}
		
		if(width < gridWidth - 1 && height > 0){
			neighbours.add(new Point(width + 1, height - 1));			
		}
		
		if(width < gridWidth - 1){
			neighbours.add(new Point(width + 1, height));			
		}
		
		if(width > 0){
			neighbours.add(new Point(width - 1, height));
		}
		return neighbours;
	}
	
	private class Point{
		int width;
		int height;		
		public Point(int width, int height){
			this.width = width;
			this.height = height;			
		}
		
		public int getWidth(){
			return width;
		}
		public int getHeight(){
			return height;
		}
		public boolean equals(Object point){
			Point other = (Point)point;
			return other.width == width && other.height == height;
		}
	}

	public String getLetterAt(int width, int height) {
		if(letterGrid == null){
			return null;
		}
		if(width >= 0 && width < letterGrid.length && height >= 0 && height < letterGrid[0].length ){
			return letterGrid[width][height];
		} else {
			return null;
		}
	}
}
