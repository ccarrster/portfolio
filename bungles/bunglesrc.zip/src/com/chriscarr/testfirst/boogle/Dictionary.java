package com.chriscarr.testfirst.boogle;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Holds a list of valid words to check against
 * Intent is for word games, could be used for a spell check validation
 * @author ccarr
 *
 */
public class Dictionary {

	List<String> wordList;
	
	/**
	 * Creates a dicitonary from a file
	 * @param fileName Name of the file dictionary to load
	 * @throws Exception 
	 * @throws FileIsDirectoryException If the file is a directory
	 * @throws InvalidCharacterException If the file contains non alpha characters besides newline
	 */
	public Dictionary(List<String> wordList) throws Exception{
		if(wordList != null){
			this.wordList = wordList;
		} else {
			throw new NullPointerException();
		}
	}

	/**
	 * 
	 * @param word
	 * @return True only if the word contains only alpha characters
	 */
	public static boolean isWordClean(String word){
		word = word.toLowerCase();
		Pattern wordPattern = Pattern.compile("^[a-z]*$");
		Matcher wordMatch = wordPattern.matcher(word);
		return wordMatch.matches();        	
	}
	
	/**
	 * Check if the word is in the dictionary
	 * @param word
	 * @return If the word is in the dictionary
	 * @throws InvalidCharacterException Thrown if the word contains non alpha characters
	 */
	public boolean isWordInDicitonary(String word) throws Exception{
		word = word.toLowerCase();        
        if(!isWordClean(word)){
        	throw new Exception("Invalid format");
        } else {
			if(wordList != null){
				return wordList.contains(word);
			} else {
				return false;
			}
		}
	}
	
	public static boolean isWordInLetters(String word, String characters) {
		if(word == null){
			return false;
		}
		if(word.equals("")){
			return false;
		}	
		word = word.toLowerCase();
		characters = characters.toLowerCase();
		for(int characterIndex = 0; characterIndex < word.length(); characterIndex++){
			String character = word.substring(characterIndex, characterIndex + 1);
			int charactersIndex = characters.indexOf(character);
			if(charactersIndex == -1){
				return false;
			} else {
				characters.replaceFirst(character, "");
			}
		}
		return true;
	}
	
	public static int scoreWord(String word){
		int score = -1;
		if(word == null){
			return score;
		}
		int wordLength = word.length();
		if(wordLength >= 3 && wordLength <= 4){
			score = 1;
		} else if(wordLength == 5){
			score = 2;
		} else if(wordLength == 6){
			score = 3;
		} else if(wordLength == 7){
			score = 5;
		} else if(wordLength >= 8){
			score = 11;
		}
		return score;
	}

	public static void removeDuplicateWords(List<List<String>> wordLists) {
		HashMap<String, Integer> duplicateWords = new HashMap<String, Integer>();
		for(Iterator<List<String>> wordListsIter = wordLists.iterator(); wordListsIter.hasNext();){
			List<String> wordList = wordListsIter.next();
			for(Iterator<String> wordListIter = wordList.iterator(); wordListIter.hasNext();){
				String word = wordListIter.next();
				if(duplicateWords.containsKey(word)){
					Integer wordCount = duplicateWords.get(word);
					wordCount = wordCount + 1;
					duplicateWords.put(word, wordCount);
				} else {
					duplicateWords.put(word, new Integer(1));
				}
			}
		}
		Set<Entry<String, Integer>> allWordCounts = duplicateWords.entrySet();
		
		for(Iterator<Entry<String, Integer>> allWordCountsIter = allWordCounts.iterator(); allWordCountsIter.hasNext();){
			Entry<String, Integer> entry = allWordCountsIter.next();
			if(entry.getValue() > 1){
				for(Iterator<List<String>> wordListsIter = wordLists.iterator(); wordListsIter.hasNext();){
					List<String> wordList = wordListsIter.next();
					wordList.remove(entry.getKey());					
				}
			}
		}		
	}
	
	public static void startTimer(int delayMiliseconds, TimerTask timesUp){
		Timer timer = new Timer();
		timer.schedule(timesUp, delayMiliseconds);
	}
}
