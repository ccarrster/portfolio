/*
 * Main.java
 *
 * Created on December 23, 2006, 12:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bilgepuzzle;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Chris Carr ccarrster@gmail.com
 */
public class Main {  
    /** Creates a new instance of Main */
    public static int defaultColumns = 6;
    public static int defaultRows = 12;
    public static int removeNumber = 3;
    public static int numberOfTypes = 4;
    public static int pointsToWin = 100;
    public Main() {
    }    
    private static void printInfo(){        
        System.out.println("To swap pieces enter comma separated numbers. eg: '0,4'");
        System.out.println("To exit enter 'q'");
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        System.out.println("Welcome to CCarr's Swap'n Float game.");
        System.out.println("Information about the game should be available at:");
        System.out.println("http://geocities.com/thechriscarrpages");
        System.out.println("The coordinate given and the piece to the right of it are swapped.");
        System.out.println("When three or more pieces are in a horizontal or vertical row they are removed.");
        System.out.println("Pieces float up when the pieces ontop of them are removed.");
        System.out.println("Random pieces are added to the bottem.");
        System.out.println("The following variables can be set via command line args.");
        System.out.println("All must be set, in the correct order.");
        System.out.println("Number of Columns, Number of rows, Number of pieces in a line before they are removed, Number of types of pieces, Number of points to win");
        System.out.println("The following example shows the default values.");
        System.out.println("eg. java -cp BilgePuzzle.jar bilgepuzzle.Main 6 12 3 4 100");
        System.out.println(args.length);
        if(args.length == 5){
            int[] ints = new int[5];
            for(int i = 0; i < args.length; i++){
                System.out.println(args[i]);
                ints[i] = Integer.parseInt(args[i]);
            }
            int i = 0;
            defaultColumns = ints[i++];
            defaultRows = ints[i++];
            removeNumber = ints[i++];
            numberOfTypes = ints[i++];
            pointsToWin = ints[i++];
        }
        printInfo();
        //Create board pieces
        String pieceString;       
        PuzzlePiece[][] puzzlePieces = new PuzzlePiece[defaultColumns][defaultRows];
        for(int x = 0; x < puzzlePieces.length; x++){
            for(int y = 0; y < puzzlePieces[0].length; y++){                
                pieceString = PuzzlePiece.generateRandomType(Main.numberOfTypes);
                puzzlePieces[x][y] = new PuzzlePiece(pieceString);
                if(x != 0){
                    puzzlePieces[x - 1][y].addPuzzlePiece(puzzlePieces[x][y], PuzzlePiece.EAST);
                }
                if(y != 0){
                    puzzlePieces[x][y - 1].addPuzzlePiece(puzzlePieces[x][y], PuzzlePiece.SOUTH);
                }
            }
        }       
               
        PuzzlePiece head = puzzlePieces[0][0];    
        //Setup board so no lines at start
        int piecesMarked = PuzzleTraverser.traversePuzzle(head);                                
        while(piecesMarked != 0){            
            PuzzleTraverser.cleanUpPuzzle(head);            
            PuzzleTraverser.fillPieces(head);                           
            piecesMarked = PuzzleTraverser.traversePuzzle(head);                        
        }        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String temp;        
        int points = 0;      
        try{            
            while(points < pointsToWin){
                System.out.println(PuzzleTraverser.puzzleToString(head));
                System.out.println("Points:" + points);

                    temp = br.readLine();
                    if(temp != null){
                        String[] inputStrings = temp.split(",");
                        if(inputStrings.length == 1){
                            if("q".equals(inputStrings[0])){
                                System.exit(0);
                            } else {
                                printInfo();
                            }
                        } else if(inputStrings.length == 2){
                            try{
                                int x = Integer.parseInt(inputStrings[0]);
                                int y = Integer.parseInt(inputStrings[1]);
                                PuzzleTraverser.swapRight(head, x, y);                                    
                                int tempPoints = PuzzleTraverser.traversePuzzle(head);                        
                                while(tempPoints != 0){            
                                    points += tempPoints;
                                    PuzzleTraverser.cleanUpPuzzle(head);            
                                    PuzzleTraverser.fillPieces(head);                           
                                    tempPoints = PuzzleTraverser.traversePuzzle(head);                        
                                }  
                            }catch(Exception e){
                                printInfo();                                                                
                            }
                        } else {
                            printInfo();
                        }
                    }

            }
        }catch(Exception e){
           e.printStackTrace();
        }
        System.out.println("Winner is you. " + points);
        
    }
    
}
