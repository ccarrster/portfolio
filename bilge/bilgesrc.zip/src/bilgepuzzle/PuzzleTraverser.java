/*
 * PuzzleTraverser.java
 *
 * Created on December 23, 2006, 12:20 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bilgepuzzle;

import java.lang.reflect.Method;
import java.util.Stack;

/**
 *
 * @author Chris
 */
public class PuzzleTraverser {        
    /** Creates a new instance of PuzzleTraverser */
   //TODO: Clean up moon science strings
    /** head must be top left of puzzle */
    public static int traversePuzzle(PuzzlePiece head){
        int piecesRemoved = 0;                
        //Horizontal
        piecesRemoved += traverseLine(head, "getSouth", "getEast");
        //Vertical
        piecesRemoved += traverseLine(head, "getEast", "getSouth");
        return piecesRemoved;
    }
    
    static public void swapRight(PuzzlePiece head, int x, int y){
        PuzzlePiece currentPiece = head;
        for(int xx = 0; xx < x; xx++){
            if(currentPiece == null){
                return;
            }
            currentPiece = currentPiece.getEast();
        }        
        for(int yy = 0; yy < y; yy++){
            if(currentPiece == null){
                return;
            }
            currentPiece = currentPiece.getSouth();
        }
        if(currentPiece == null || currentPiece.getEast() == null){
            return;
        }
        String tempType = currentPiece.getType();
        currentPiece.setType(currentPiece.getEast().getType());
        currentPiece.getEast().setType(tempType);
    }
    
    static public void fillPieces(PuzzlePiece head){            
        fillPieces(head, "getEast", "getSouth");      
    }  
    
    static public void fillPieces(PuzzlePiece head, String index, String step){        
        try{
            PuzzlePiece currentLine = head;        
            PuzzlePiece currentPiece = currentLine;                
            while(currentPiece != null){
                fillPiece(currentPiece);
                Method indexMethod = currentPiece.getClass().getMethod(index);                
                Method stepMethod = currentPiece.getClass().getMethod(step);  
                String currentType = currentPiece.getType();
                if((PuzzlePiece)stepMethod.invoke(currentPiece) == null){                                
                    currentLine = (PuzzlePiece)indexMethod.invoke(currentLine);
                    currentPiece = currentLine;                       
                } else {
                    currentPiece = (PuzzlePiece)stepMethod.invoke(currentPiece);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    static public void cleanUpPuzzle(PuzzlePiece head){            
        cleanUpPuzzle(head, "getEast", "getSouth");      
    }   
                        
    static public void cleanUpPuzzle(PuzzlePiece head, String index, String step){        
        try{
            PuzzlePiece currentLine = head;        
            PuzzlePiece currentPiece = currentLine;                
            while(currentPiece != null){
                floatUp(currentPiece);
                Method indexMethod = currentPiece.getClass().getMethod(index);                
                Method stepMethod = currentPiece.getClass().getMethod(step);  
                String currentType = currentPiece.getType();
                if((PuzzlePiece)stepMethod.invoke(currentPiece) == null){                                
                    currentLine = (PuzzlePiece)indexMethod.invoke(currentLine);
                    currentPiece = currentLine;                       
                } else {
                    currentPiece = (PuzzlePiece)stepMethod.invoke(currentPiece);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
        
    
    public static String puzzleToString(PuzzlePiece head){
        return puzzleToString(head, "getSouth", "getEast");
    }        
    
    public static String puzzleToString(PuzzlePiece head, String index, String step){
        StringBuffer stringBuffer = new StringBuffer();
        try{
            PuzzlePiece currentLine = head;        
            PuzzlePiece currentPiece = currentLine;                
            while(currentPiece != null){
                String remove;
                if(currentPiece.isRemove()){
                    remove = "*";                   
                } else {
                    remove = " ";
                }
                stringBuffer.append("[" + currentPiece.getType() + remove + "]");
                Method indexMethod = currentPiece.getClass().getMethod(index);                
                Method stepMethod = currentPiece.getClass().getMethod(step);  
                String currentType = currentPiece.getType();
                if((PuzzlePiece)stepMethod.invoke(currentPiece) == null){                                
                    currentLine = (PuzzlePiece)indexMethod.invoke(currentLine);
                    currentPiece = currentLine;   
                    stringBuffer.append("\n");
                } else {
                    currentPiece = (PuzzlePiece)stepMethod.invoke(currentPiece);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return stringBuffer.toString();
    }
    
    private static int traverseLine(PuzzlePiece head, String index, String step){
        int piecesRemoved = 0;
        try{
            PuzzlePiece currentLine = head;        
            PuzzlePiece currentPiece = currentLine;        
            Stack typeStack = new Stack();             
            while(currentPiece != null){            
                Method indexMethod = currentPiece.getClass().getMethod(index);                
                Method stepMethod = currentPiece.getClass().getMethod(step);  
                String currentType = currentPiece.getType();
                if((PuzzlePiece)stepMethod.invoke(currentPiece) == null){
                    typeStack.push(currentPiece);
                    piecesRemoved += processStack(typeStack);                
                    currentLine = (PuzzlePiece)indexMethod.invoke(currentLine);
                    currentPiece = currentLine;                                
                } else {
                    typeStack.push(currentPiece);
                    if(!currentPiece.getType().equals(((PuzzlePiece)stepMethod.invoke(currentPiece)).getType())){                                    
                        piecesRemoved += processStack(typeStack);
                    }
                    currentPiece = (PuzzlePiece)stepMethod.invoke(currentPiece);
                }
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return piecesRemoved;
    }
    
    private static int processStack(Stack stack){
        int piecesRemoved = 0;
        if(stack.size() >= Main.removeNumber){
            while(stack.size() > 0){
                PuzzlePiece current = (PuzzlePiece)stack.pop();
                if(current != null){
                    if(!current.isRemove()){
                        current.setRemove(true);
                        piecesRemoved++;
                    }
                }
            }
        } else {
            stack.removeAllElements();
        }
        return piecesRemoved;
    }
    
    private static void floatUp(PuzzlePiece pieceToFloat){
        if((pieceToFloat.getNorth() != null) && (pieceToFloat.getNorth().isRemove()) && (!pieceToFloat.isRemove())){
            PuzzlePiece potentialPiece = pieceToFloat;
            boolean placed = false;
            while(!placed){
                PuzzlePiece goTo = potentialPiece.getNorth();
                if(goTo == null || !goTo.isRemove()){
                    potentialPiece.setType(pieceToFloat.getType());
                    potentialPiece.setRemove(false);
                    pieceToFloat.setRemove(true);
                    placed = true;
                } else {
                    potentialPiece = goTo;
                }
            }
        }
    }
    
    private static void fillPiece(PuzzlePiece puzzlePiece){
        if(puzzlePiece.isRemove()){
            puzzlePiece.setType(PuzzlePiece.generateRandomType(Main.numberOfTypes));
            puzzlePiece.setRemove(false);
        }
    }
    
}
