/*
 * PuzzlePiece.java
 *
 * Created on December 23, 2006, 12:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bilgepuzzle;

import java.awt.Image;
import java.awt.Point;

/**
 *
 * @author Chris
 */
public class PuzzlePiece {
    public static final String NORTH = "North";
    public static final String SOUTH = "South";
    public static final String EAST = "East";
    public static final String WEST = "West";  
    
    private String type;
    private boolean remove;
    private Image image;    
    private PuzzlePiece north;
    private PuzzlePiece south;
    private PuzzlePiece east;
    private PuzzlePiece west;
    /** Creates a new instance of PuzzlePiece */
    public PuzzlePiece(String type) {
        this.type = type;
        setRemove(false);
        setNorth(null);
        setSouth(null);
        setEast(null);
        setWest(null);
    }       
    
    public void addPuzzlePiece(PuzzlePiece newPiece, String side){
        if(newPiece != null){
            if(side.equals(NORTH)){
                setNorth(newPiece);
                newPiece.setSouth(this);
            } else if(side.equals(SOUTH)){
                setSouth(newPiece);
                newPiece.setNorth(this);
            } else if(side.equals(EAST)){
                setEast(newPiece);
                newPiece.setWest(this);
            } else if(side.equals(WEST)){
                setWest(newPiece);
                newPiece.setEast(this);
            } else {
                System.out.println(side + " is an invalid side to add a piece to. Only North, South, East, West are valid.");
            }
        }
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isRemove() {
        return remove;
    }

    public void setRemove(boolean remove) {
        this.remove = remove;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public PuzzlePiece getNorth() {
        return north;
    }

    public void setNorth(PuzzlePiece north) {
        this.north = north;
    }

    public PuzzlePiece getSouth() {
        return south;
    }

    public void setSouth(PuzzlePiece south) {
        this.south = south;
    }

    public PuzzlePiece getEast() {
        return east;
    }

    public void setEast(PuzzlePiece east) {
        this.east = east;
    }

    public PuzzlePiece getWest() {
        return west;
    }

    public void setWest(PuzzlePiece west) {
        this.west = west;
    }
    
    public static String generateRandomType(int types)
    {
        int random = (int)(Math.random() * types);      
        char x = 'A';
        x = (char)(x + random);     
        return new String("" + x);
    }
}
