/*
 * PlayingCard.java
 *
 * Created on February 26, 2006, 11:26 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing;

import ccarr.cards.Card;
/**
 *
 * @author z
 */
public class PlayingCard implements Card{

    public static final int cardsPerSuit = 13;
    public static final int suits = 4;    
    
    int value;
    int suit;
    /** Creates a new instance of PlayingCard */
    public PlayingCard(int value, int suit) {
        this.value = value;
        this.suit = suit;
    }
    
    public int getSuit(){
        return suit;
    }
    
    public int getValue(){
        return value;
    }
    
    public static String getSuitName(int suit){
        switch (suit){
            case 0:
                    return "Spades";
            case 1:
                    return "Hearts";
            case 2:
                    return "Clubs";
            case 3:
                    return "Diamonds";            
        }    
        return "Invalid suit";
    }
    
    public static String getValueName(int value){
        switch (value){
            case 0:
                    return "Two";
            case 1:
                    return "Three";
            case 2:
                    return "Four";
            case 3:
                    return "Five";            
            case 4:
                    return "Six";
            case 5:
                    return "Seven";
            case 6:
                    return "Eight";
            case 7:
                    return "Nine";
            case 8:
                    return "Ten";
            case 9:
                    return "Jack";
            case 10:
                    return "Queen";
            case 11:
                    return "King";
            case 12:
                    return "Ace";
        }    
        return "Invalid value";
    }
    
    public static String getValueSymbol(int value){
        switch (value){
            case 0:
                    return "2";
            case 1:
                    return "3";
            case 2:
                    return "4";
            case 3:
                    return "5";            
            case 4:
                    return "6";
            case 5:
                    return "7";
            case 6:
                    return "8";
            case 7:
                    return "9";
            case 8:
                    return "10";
            case 9:
                    return "J";
            case 10:
                    return "Q";
            case 11:
                    return "K";
            case 12:
                    return "A";
        }    
        return "Invalid value";
    }
}
