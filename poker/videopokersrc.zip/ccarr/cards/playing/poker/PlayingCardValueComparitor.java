/*
 * PlayingCardValueComparitor.java
 *
 * Created on February 27, 2006, 11:46 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker;

import ccarr.cards.playing.PlayingCard;
import java.util.Comparator;

/**
 *
 * @author z
 */
public class PlayingCardValueComparitor implements Comparator{
    
    /** Creates a new instance of PlayingCardValueComparitor */
    public PlayingCardValueComparitor() {
    }

    public int compare(Object obj, Object obj1) {
        PlayingCard firstCard = (PlayingCard)obj;
        PlayingCard secondCard = (PlayingCard)obj1;
        return firstCard.getValue() - secondCard.getValue();
    }
    
}
