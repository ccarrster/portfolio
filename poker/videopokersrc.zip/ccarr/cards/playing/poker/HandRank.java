/*
 * HandRank.java
 *
 * Created on February 27, 2006, 10:38 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker;

import ccarr.cards.playing.PlayingCard;
/**
 *
 * @author z
 */
public class HandRank{    
    
    static String[] nameForRank = new String[]{"Royal Flush", "Straight Flush", "Four of a Kind", "Full House", "Flush", "Straight", "Three of a kind", "Two Pair", "One Pair", "Low"};
    
    int rank;
    int[] values;
    int[] valueSummary;
    boolean isStraight;
    boolean isFlush;
    /** Creates a new instance of HandRank */
    public HandRank() {
        values = new int[PlayingCard.cardsPerSuit];
        valueSummary = new int[PlayingCard.suits + 1];
    }  
    
    public static String getNameForRank(int rank){
        if(rank > 0 && rank <= 10){
            return nameForRank[rank - 1];
        } else {
            return null;
        }
    }
    
    public int getRank(){
        return rank;
    }
    
    public int[] getValues(){
        return values;
    }
    
    public int[] getValueSummary(){
        return valueSummary;
    }
    
    public boolean isStraight(){
        return isStraight;
    }
    
    public boolean isFlush(){
        return isFlush;
    }
}
