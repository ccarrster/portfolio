/*
 * Odds.java
 *
 * Created on December 17, 2006, 5:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ccarr.cards.playing.poker.videopoker;

public class Odds { 
    private int bet;
    private int tokens;
    static final int[] odds = {800, 50, 25, 9, 6, 4, 3, 2, 1, 0};    
    public static int getOdds(int rank){
        if(rank > 0 && rank <= 10){
            return odds[rank - 1];
        } else {
            return 0;
        }
    }
    public boolean takeBet(){
        if(tokens >= bet){
            tokens = tokens - bet;
            return true;
        } else {
          return false;  
        }
    }
    public int processHand(int rank){
        int winnings = getOdds(rank) * bet;
        tokens = tokens + winnings;
        return winnings;
    }
    public void setBet(int bet){
        this.bet = bet;
    }
    public int getBet(){
        return bet;
    }
    public void setTokens(int tokens){
        this.tokens = tokens;
    }
    public int getTokens(){
        return tokens;
    }
}
