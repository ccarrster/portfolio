/*
 * GameFrame.java
 *
 * Created on March 4, 2006, 4:32 PM
 */

package ccarr.cards.playing.poker.videopoker;
import ccarr.cards.Card;
import ccarr.cards.playing.poker.cardimages.CardImageFetcher;
import ccarr.cards.playing.poker.videopoker.CardPanel;
import ccarr.cards.playing.poker.videopoker.Odds;
import ccarr.cards.playing.PlayingCard;
import ccarr.cards.playing.PlayingCardDeck;
import ccarr.cards.playing.poker.HandRank;
import ccarr.cards.playing.poker.HandRanker;
import ccarr.cards.playing.poker.cardimages.PokerCardImageFetcher;
import java.awt.*;
import java.awt.image.*;
import java.io.File;
import javax.swing.JToggleButton;

/**
 *
 * @author  z
 */
public class GameFrame extends java.awt.Frame {        
    CardPanel cardPanel1 = new CardPanel();
    CardPanel cardPanel2 = new CardPanel();
    CardPanel cardPanel3 = new CardPanel();
    CardPanel cardPanel4 = new CardPanel();
    CardPanel cardPanel5 = new CardPanel(); 
    private static int CARDSPERHAND = 5;
    private static String HOLD = "Hold";
    private static String DRAW = "Draw";
    private static String PLAY = "Play";
    String gameState = DRAW;
    CardImageFetcher pokerCardImageFetcher = new PokerCardImageFetcher("C:\\java\\cardimages", "png");
    PlayingCardDeck playingCardDeck;
    CardPanel[] cardPanels;
    JToggleButton[] holdDrawButtons;
    Odds odds = new Odds();
    /** Creates new form GameFrame */
    public GameFrame() {
        initComponents();
        for(int rank = 1; rank < 10; rank++){
            jTextArea2.append(HandRank.getNameForRank(rank) + " " + Odds.getOdds(rank) + "\n");
        }
        holdDrawButtons = new JToggleButton[CARDSPERHAND];
        holdDrawButtons[0] = jToggleButton5;
        holdDrawButtons[1] = jToggleButton4;
        holdDrawButtons[2] = jToggleButton3;
        holdDrawButtons[3] = jToggleButton2;
        holdDrawButtons[4] = jToggleButton1;
        cardPanels = new CardPanel[CARDSPERHAND];        
        cardPanels[0] = cardPanel1;        
        cardPanels[1] = cardPanel2;        
        cardPanels[2] = cardPanel3;        
        cardPanels[3] = cardPanel4;        
        cardPanels[4] = cardPanel5;
        int i = 0;        
        jPanel16.add(cardPanels[i++], java.awt.BorderLayout.CENTER);
        jPanel17.add(cardPanels[i++], java.awt.BorderLayout.CENTER);
        jPanel18.add(cardPanels[i++], java.awt.BorderLayout.CENTER);
        jPanel19.add(cardPanels[i++], java.awt.BorderLayout.CENTER);
        jPanel20.add(cardPanels[i++], java.awt.BorderLayout.CENTER);
        initGame();
    }
        
    private void initGame(){        
        odds.setTokens(100);
        odds.setBet(1);
        jTextField2.setText(Integer.toString(odds.getTokens()));        
    }
    
    private void newGame(){     
        if(odds.takeBet()){
            jTextField2.setText(Integer.toString(odds.getTokens()));
            for(int i = 0; i < cardPanels.length; i++){
                holdDrawButtons[i].setSelected(false);
            }
            playingCardDeck = new PlayingCardDeck();        
            Card[] hand = playingCardDeck.pullCards(true, CARDSPERHAND);                                                         
            for(int i = 0; i < cardPanels.length; i++){
                cardPanels[i].setCard(hand[i]);            
                cardPanels[i].setCardImageFetcher(pokerCardImageFetcher);
            }        
            //label1.setText("");
            gameState = PLAY;
            this.repaint();            
        } else {
            jTextArea1.append("\nNo more tokens left");
        }
    }
    
    private void drawNewCards(){        
        for(int i = 0; i < cardPanels.length; i++){
            if(!holdDrawButtons[i].isSelected()){
                cardPanels[i].setCard((playingCardDeck.pullCards(true, 1)[0]));
            }
        }
        //A pair of 10/s with ace, king, queen
        PlayingCard[] handToBeat = new PlayingCard[CARDSPERHAND];
        handToBeat[0] = new PlayingCard(8, 0);
        handToBeat[1] = new PlayingCard(8, 1);
        handToBeat[2] = new PlayingCard(12, 0);
        handToBeat[3] = new PlayingCard(11, 0);
        handToBeat[4] = new PlayingCard(10, 0);
        PlayingCard[] playingCards = new PlayingCard[CARDSPERHAND];
        for(int i = 0; i < cardPanels.length; i++){
            playingCards[i] = (PlayingCard)cardPanels[i].getCard();
        }
        HandRanker handRanker = new HandRanker();        
        int winner = handRanker.compare(playingCards, handToBeat);
        String winLoseString;
        if(winner <= 0){
            winLoseString = "Loses";
        } else {
            winLoseString = "Wins";
        }
        int rank = handRanker.generateRank(playingCards).getRank();
        jTextArea1.append("\n" + HandRank.getNameForRank(rank) + ": " + winLoseString);
        //So you don't get paid for a pair less than jacks
        if(winner <= 0){
            rank = 10;
        }
        int winnings = odds.processHand(rank);
        if(winnings > 0){
            jTextArea1.append(" " + winnings + " tokens");
        }
        
        jTextField2.setText(Integer.toString(odds.getTokens())); 
        gameState = DRAW;
        this.repaint();        
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jToggleButton5 = new javax.swing.JToggleButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jToggleButton4 = new javax.swing.JToggleButton();
        jPanel8 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jToggleButton3 = new javax.swing.JToggleButton();
        jPanel9 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jToggleButton2 = new javax.swing.JToggleButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.X_AXIS));

        jTextArea1.setColumns(20);
        jTextArea1.setEditable(false);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1);

        add(jPanel1, java.awt.BorderLayout.WEST);

        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.X_AXIS));

        jTextArea2.setColumns(20);
        jTextArea2.setEditable(false);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jPanel2.add(jScrollPane2);

        add(jPanel2, java.awt.BorderLayout.EAST);

        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.X_AXIS));

        jLabel4.setText("Tokens");
        jPanel3.add(jLabel4);

        jTextField2.setEditable(false);
        jPanel3.add(jTextField2);

        jLabel2.setText("Bet");
        jPanel3.add(jLabel2);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                betChanged(evt);
            }
        });

        jPanel3.add(jComboBox1);

        jButton1.setText("Play/Draw");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel3.add(jButton1);

        add(jPanel3, java.awt.BorderLayout.SOUTH);

        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.X_AXIS));

        jPanel6.setLayout(new javax.swing.BoxLayout(jPanel6, javax.swing.BoxLayout.Y_AXIS));

        jPanel16.setLayout(new javax.swing.BoxLayout(jPanel16, javax.swing.BoxLayout.X_AXIS));

        jPanel6.add(jPanel16);

        jToggleButton5.setText("Hold/Draw");
        jPanel11.add(jToggleButton5);

        jPanel6.add(jPanel11);

        jPanel4.add(jPanel6);

        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.Y_AXIS));

        jPanel17.setLayout(new javax.swing.BoxLayout(jPanel17, javax.swing.BoxLayout.X_AXIS));

        jPanel7.add(jPanel17);

        jToggleButton4.setText("Hold/Draw");
        jPanel12.add(jToggleButton4);

        jPanel7.add(jPanel12);

        jPanel4.add(jPanel7);

        jPanel8.setLayout(new javax.swing.BoxLayout(jPanel8, javax.swing.BoxLayout.Y_AXIS));

        jPanel18.setLayout(new javax.swing.BoxLayout(jPanel18, javax.swing.BoxLayout.X_AXIS));

        jPanel8.add(jPanel18);

        jToggleButton3.setText("Hold/Draw");
        jPanel14.add(jToggleButton3);

        jPanel8.add(jPanel14);

        jPanel4.add(jPanel8);

        jPanel9.setLayout(new javax.swing.BoxLayout(jPanel9, javax.swing.BoxLayout.Y_AXIS));

        jPanel19.setLayout(new javax.swing.BoxLayout(jPanel19, javax.swing.BoxLayout.X_AXIS));

        jPanel9.add(jPanel19);

        jToggleButton2.setText("Hold/Draw");
        jPanel13.add(jToggleButton2);

        jPanel9.add(jPanel13);

        jPanel4.add(jPanel9);

        jPanel10.setLayout(new javax.swing.BoxLayout(jPanel10, javax.swing.BoxLayout.Y_AXIS));

        jPanel20.setLayout(new javax.swing.BoxLayout(jPanel20, javax.swing.BoxLayout.X_AXIS));

        jPanel10.add(jPanel20);

        jToggleButton1.setText("Hold/Draw");
        jPanel15.add(jToggleButton1);

        jPanel10.add(jPanel15);

        jPanel4.add(jPanel10);

        add(jPanel4, java.awt.BorderLayout.CENTER);

        jLabel1.setText("CCarr Video Poker");
        jPanel5.add(jLabel1);

        add(jPanel5, java.awt.BorderLayout.NORTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void betChanged(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_betChanged
        odds.setBet(Integer.parseInt((String)jComboBox1.getSelectedItem()));
    }//GEN-LAST:event_betChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(gameState.equals(DRAW)){
            newGame();            
        } else if(gameState.equals(PLAY)){
            drawNewCards();            
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit(0);
    }//GEN-LAST:event_exitForm
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameFrame().setVisible(true);
            }
        });
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JToggleButton jToggleButton3;
    private javax.swing.JToggleButton jToggleButton4;
    private javax.swing.JToggleButton jToggleButton5;
    // End of variables declaration//GEN-END:variables
    
}
