/*
 * CardPanel.java
 *
 * Created on March 4, 2006, 3:02 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker.videopoker;

import ccarr.cards.*;
import ccarr.cards.playing.poker.cardimages.CardImageFetcher;
import java.awt.*;
import java.io.File;

/**
 *
 * @author z
 */
public class CardPanel extends Panel{
    
    private Image image;
    private Card card;  
    private CardImageFetcher cardImageFetcher;
    
    /** Creates a new instance of CardPanel */
    public CardPanel(){        
    }        
    
    public void paint(Graphics g){
        super.paint(g);
        if(image != null){
            g.drawImage(image, 0, 0, this);
        }
    }
    
    public void setCardImageFetcher(CardImageFetcher cardImageFetcher){
        this.cardImageFetcher = cardImageFetcher;
        if(card != null){            
            setImage();    
        }
    }
    public Card getCard(){
        return card;
    }
    public void setCard(Card card){
        this.card = card;
        if(cardImageFetcher != null){            
            setImage();
        }
    }                   
    
    private void setImage(){
        try{
            image = cardImageFetcher.fetchImage(card); 
            this.repaint();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
