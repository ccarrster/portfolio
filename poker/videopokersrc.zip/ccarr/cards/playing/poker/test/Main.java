/*
 * Main.java
 *
 * Created on February 26, 2006, 10:35 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker.test;

import ccarr.cards.playing.PlayingCardDeck;
import ccarr.cards.playing.PlayingCard;
import ccarr.cards.playing.poker.HandRanker;
/**
 *
 * @author z
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
        rankTest();
        comparitorTest();
        
        //HandRanker handRanker = new HandRanker();        
           
                
        //Seeing how long it takes to get one hand of each type in order of awfulness
        
        
        /*
        PlayingCardDeck playingCardDeck;
        int rank = 10;
        while(rank > 0){
            playingCardDeck = new PlayingCardDeck();        
            Card[] hand = playingCardDeck.pullCards(true, 5);            
            PlayingCard[] playingCards = new PlayingCard[hand.length];
            for(int i = 0; i < hand.length; i++){
                playingCards[i] = (PlayingCard)hand[i];
            }
            HandRank handRank = handRanker.generateRank(playingCards);                   
            if(rank == handRank.getRank()){
                for(int i = 0; i < hand.length; i++){
                    PlayingCard currentCard = (PlayingCard)hand[i];
                    System.out.println(PlayingCard.getValueName(currentCard.getValue()) + " of " + PlayingCard.getSuitName(currentCard.getSuit()));
                }
                System.out.println("Rank: " + handRank.getRank());
                --rank;
            }
        } */
        /*        
        //Playing a single hand of poker
        PlayingCardDeck playingCardDeck = new PlayingCardDeck();
        Card[] hand1 = playingCardDeck.pullCards(true, 5);        
        PlayingCard[] playingCards1 = new PlayingCard[hand1.length];
        for(int i = 0; i < hand1.length; i++){
            playingCards1[i] = (PlayingCard)hand1[i];
        }
        Card[] hand2 = playingCardDeck.pullCards(true, 5);
        PlayingCard[] playingCards2 = new PlayingCard[hand2.length];
        for(int i = 0; i < hand2.length; i++){
            playingCards2[i] = (PlayingCard)hand2[i];
        }
        int winner = handRanker.compare(playingCards1, playingCards2);                    
        
        if(winner < 0){
            System.out.println("Player 2 Wins: " + handRanker.generateRank(playingCards2).getRank());
        } else if(winner > 0){
            System.out.println("Player 1 Wins: " + handRanker.generateRank(playingCards2).getRank());
        } else {
            System.out.println("Tie");
        }        
        System.out.println("Player 1's hand");
        for(int i = 0; i < playingCards1.length; i++){            
            System.out.println(PlayingCard.getValueName(playingCards1[i].getValue()) + " of " + PlayingCard.getSuitName(playingCards1[i].getSuit()));
        }
        System.out.println("Player 2's hand");
        for(int i = 0; i < playingCards2.length; i++){            
            System.out.println(PlayingCard.getValueName(playingCards2[i].getValue()) + " of " + PlayingCard.getSuitName(playingCards2[i].getSuit()));
        }
         */
        
                 
    }
    
    private void comparitorTest(){
        HandRanker handRanker = new HandRanker();
        //Testing hand comparitor
        PlayingCard[] testHand;
        PlayingCard[] testHand2;
        //I need to create specific hands and test for equal and not equal
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(3, 1), new PlayingCard(4, 3), new PlayingCard(11, 1), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 1), new PlayingCard(3, 2), new PlayingCard(4, 1), new PlayingCard(11, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("Low not equal");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(3, 1), new PlayingCard(4, 3), new PlayingCard(11, 1), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 1), new PlayingCard(3, 2), new PlayingCard(6, 1), new PlayingCard(11, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("Low broken");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(4, 3), new PlayingCard(11, 1), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 2), new PlayingCard(0, 3), new PlayingCard(4, 1), new PlayingCard(11, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("Pair not equal");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(4, 3), new PlayingCard(11, 1), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(1, 2), new PlayingCard(1, 3), new PlayingCard(4, 1), new PlayingCard(11, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("Pair broken");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(4, 3), new PlayingCard(4, 2), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 2), new PlayingCard(0, 3), new PlayingCard(4, 1), new PlayingCard(4, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("2 Pair not equal");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(4, 3), new PlayingCard(4, 2), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 2), new PlayingCard(0, 3), new PlayingCard(6, 1), new PlayingCard(6, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("2 Pair broken: high pair");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(4, 3), new PlayingCard(4, 2), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(1, 2), new PlayingCard(1, 3), new PlayingCard(4, 1), new PlayingCard(4, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("2 Pair broken: low pair");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(4, 3), new PlayingCard(4, 2), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 2), new PlayingCard(0, 3), new PlayingCard(4, 1), new PlayingCard(4, 0), new PlayingCard(6, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("2 Pair broken: extra card");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(0, 3), new PlayingCard(11, 1), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(1, 0), new PlayingCard(1, 3), new PlayingCard(1, 1), new PlayingCard(11, 0), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("3 of a kind broken");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(0, 3), new PlayingCard(1, 1), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(1, 0), new PlayingCard(1, 3), new PlayingCard(1, 1), new PlayingCard(1, 2), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("4 of a kind broken");
        }                
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 1), new PlayingCard(2, 1), new PlayingCard(3, 1), new PlayingCard(4, 1), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("Flush not equal");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0), new PlayingCard(5, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(6, 1), new PlayingCard(2, 1), new PlayingCard(3, 1), new PlayingCard(4, 1), new PlayingCard(5, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("Flush broken");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 3), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0), new PlayingCard(1, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 2), new PlayingCard(2, 1), new PlayingCard(3, 1), new PlayingCard(4, 1), new PlayingCard(1, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("Straight not equal");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 3), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0), new PlayingCard(1, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(5, 2), new PlayingCard(2, 1), new PlayingCard(3, 1), new PlayingCard(4, 1), new PlayingCard(1, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("Straight broken");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(0, 2), new PlayingCard(4, 0), new PlayingCard(4, 1)};                
        testHand2 = new PlayingCard[]{new PlayingCard(3, 3), new PlayingCard(3, 2), new PlayingCard(3, 1), new PlayingCard(4, 3), new PlayingCard(4, 2)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("full house broken");
        }
                        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0), new PlayingCard(1, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(0, 1), new PlayingCard(2, 1), new PlayingCard(3, 1), new PlayingCard(4, 1), new PlayingCard(1, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("Straight flush not equal");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0), new PlayingCard(1, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(5, 1), new PlayingCard(2, 1), new PlayingCard(3, 1), new PlayingCard(4, 1), new PlayingCard(1, 1)};
        if(handRanker.compare(testHand, testHand2) >= 0){
            System.out.println("Straight flush broken");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(12, 0), new PlayingCard(11, 0), new PlayingCard(10, 0), new PlayingCard(9, 0), new PlayingCard(8, 0)};                
        testHand2 = new PlayingCard[]{new PlayingCard(12, 1), new PlayingCard(11, 1), new PlayingCard(10, 1), new PlayingCard(9, 1), new PlayingCard(8, 1)};
        if(handRanker.compare(testHand, testHand2) != 0){
            System.out.println("Royal flush not equal");
        }       
    }
    
    private void rankTest(){
         HandRanker handRanker = new HandRanker();                        
        PlayingCard[] testHand;        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(3, 1), new PlayingCard(4, 3), new PlayingCard(11, 1), new PlayingCard(5, 0)};
        if(handRanker.generateRank(testHand).getRank() != 10){
            System.out.println("low rank failure");
        }
        
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(2, 3), new PlayingCard(11, 1), new PlayingCard(3, 0)};
        if(handRanker.generateRank(testHand).getRank() != 9){
            System.out.println("pair rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(11, 3), new PlayingCard(11, 1), new PlayingCard(2, 0)};
        if(handRanker.generateRank(testHand).getRank() != 8){
            System.out.println("2 pair rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(0, 3), new PlayingCard(10, 1), new PlayingCard(11, 0)};
        if(handRanker.generateRank(testHand).getRank() != 7){
            System.out.println("3 of a kind rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(1, 1), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0)};
        if(handRanker.generateRank(testHand).getRank() != 6){
            System.out.println("straight rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(1, 1), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(12, 0)};
        if(handRanker.generateRank(testHand).getRank() != 6){
            System.out.println("straight low ace rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(1, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(11, 0)};
        if(handRanker.generateRank(testHand).getRank() != 5){
            System.out.println("flush rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(0, 3), new PlayingCard(11, 1), new PlayingCard(11, 0)};
        if(handRanker.generateRank(testHand).getRank() != 4){
            System.out.println("full house rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(0, 1), new PlayingCard(0, 3), new PlayingCard(0, 2), new PlayingCard(11, 0)};
        if(handRanker.generateRank(testHand).getRank() != 3){
            System.out.println("4 of a kind rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(1, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(4, 0)};
        if(handRanker.generateRank(testHand).getRank() != 2){
            System.out.println("straight flush rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(0, 0), new PlayingCard(1, 0), new PlayingCard(2, 0), new PlayingCard(3, 0), new PlayingCard(12, 0)};
        if(handRanker.generateRank(testHand).getRank() != 2){
            System.out.println("low ace straight flush rank failure");
        }
        
        testHand = new PlayingCard[]{new PlayingCard(8, 0), new PlayingCard(9, 0), new PlayingCard(10, 0), new PlayingCard(11, 0), new PlayingCard(12, 0)};
        if(handRanker.generateRank(testHand).getRank() != 1){
            System.out.println("royal flush rank failure");
        }
           
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main();
    }
    
}
