/*
 * HandRanker.java
 *
 * Created on February 27, 2006, 10:37 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker;

import ccarr.cards.playing.PlayingCard;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
/**
 *
 * @author z
 */
public class HandRanker implements Comparator {
    
    public static final int HANDSIZE = 5;
    
    /** Creates a new instance of HandRanker */
    public HandRanker() {
    }  
    
    private boolean isValidHand(PlayingCard[] playingCards){
        if(playingCards != null && playingCards.length == HANDSIZE){
            for(int i = 0; i < playingCards.length; i++){
                if(playingCards[i] == null){
                    return false;
                }                
            }
            return true;
        }
        return false;
    }
    
    private boolean isFlush(PlayingCard[] playingCards){
        if(isValidHand(playingCards)){
            int[] suits = new int[PlayingCard.suits];
            for(int i = 0; i < playingCards.length; i++){               
               suits[playingCards[i].getSuit()]++;                              
            }
            for(int i = 0; i < suits.length; i++){
                if(suits[i] == HANDSIZE){
                    return true;
                }
            }            
        }        
        return false;
    }
        
    public PlayingCard[] orderCards(PlayingCard[] cards){
        if(isValidHand(cards)){
            ArrayList cardArrayList = new ArrayList();
            for(int i = 0; i < cards.length; i++){                
                cardArrayList.add(cards[i]);                
            }
            Collections.sort(cardArrayList, new PlayingCardValueComparitor());
            return (PlayingCard[])cardArrayList.toArray(new PlayingCard[0]);
        }
        return null;
    }
    
    private PlayingCard[] straightOrderCards(PlayingCard[] cards){
        PlayingCard[] straightCards = orderCards(cards);        
        PlayingCard[] resultCards = new PlayingCard[cards.length];
        if(straightCards[0].getValue() == 2 && straightCards[cards.length - 1].getValue() == 12){
            resultCards[0] = straightCards[cards.length - 1];
            for(int i = 1; i < cards.length - 2; i++){
                resultCards[i] = straightCards[cards.length - 1 - i];
            }
        }
        return straightCards;
    }
    
    private boolean isStraight(PlayingCard[] cards){
        if(isValidHand(cards)){
            cards = orderCards(cards);
            int value = cards[0].getValue();
            for(int i = 0; i < cards.length; i++, value++){
                if(value != cards[i].getValue()){
                    //Ace-5 straight
                    if(i == cards.length - 1 && cards[i].getValue() == PlayingCard.cardsPerSuit - 1 && cards[0].getValue() == 0){
                        return true;                        
                    } else {
                        return false;
                    }
                }
            }
            //All card values incruement by 1
            return true;
        }
        return false;
    }
    
    public HandRank generateRank(PlayingCard[] cards){
        if(isValidHand(cards)){
            HandRank handRank = new HandRank();            
            for(int i = 0; i < cards.length; i++){
                PlayingCard currentCard = cards[i];
                handRank.values[currentCard.getValue()]++;            
            }
            
            for(int i = 0; i < handRank.values.length; i++){
                handRank.valueSummary[handRank.values[i]]++;
            }
            
            handRank.isFlush = isFlush(cards);
            handRank.isStraight = isStraight(cards);            
            //Royal Flush
            if(handRank.isFlush && handRank.isStraight && orderCards(cards)[0].getValue() == 8){
                handRank.rank = 1; 
            //Straight Flush
            } else if (handRank.isFlush && handRank.isStraight){
                handRank.rank = 2;
            //4 of a kind
            } else if (handRank.valueSummary[4] == 1){
                handRank.rank = 3;
            //Full house
            } else if (handRank.valueSummary[3] == 1 && handRank.valueSummary[2] == 1){
                handRank.rank = 4;
            //Flush              
            } else if (handRank.isFlush){
                handRank.rank = 5;
            //Straight
            } else if (handRank.isStraight){
                handRank.rank = 6;
            //3 of a kind
            } else if (handRank.valueSummary[3] == 1){
                handRank.rank = 7;
            //2 pair
            } else if (handRank.valueSummary[2] == 2){
                handRank.rank = 8;
            //1 pair
            } else if (handRank.valueSummary[2] == 1){
                handRank.rank = 9;
            //Low
            } else {
                handRank.rank = 10;
            }
            return handRank;
        }
        return null;
    }
    
        
    //Equal hands
    //If two/three/four/fullhouse(the three value) baced compare the values of the sets
    //If equal(pair/2 pair) then compare next highest card(repeat)
    //If out of cards split tie
    //Note:Make temporary hands, remove the cards that are equal to the other hand(s)

    //If straight based who has the highest card?
    //If same card tie
    //HandRanker should be part of this class or the tools should be public
    //This class sould retain the hand
    //Two must bcome one.
    //TODO complete and fix this
    public int compare(Object obj, Object obj1) {        
        //essential object 1 is a hand and object 2 is a hand use the HandRanker as a static resource
        
        PlayingCard[] hand1 = (PlayingCard[])obj;
        PlayingCard[] sortedHand1 = orderCards(hand1);
        PlayingCard[] straightSortedHand1 = straightOrderCards(hand1);
        PlayingCard[] hand2 = (PlayingCard[])obj1;
        PlayingCard[] sortedHand2 = orderCards(hand2);
        PlayingCard[] straightSortedHand2 = straightOrderCards(hand2);
        if(isValidHand(hand1) && isValidHand(hand2)){
            HandRank hand1Rank = generateRank(hand1);
            HandRank hand2Rank = generateRank(hand2);
            int difference = hand1Rank.getRank() - hand2Rank.getRank();
            if(difference != 0){
                //Low rank is better so * -1
                return difference * -1;
            } else {
                if(hand1Rank.isStraight()){
                    return straightSortedHand1[straightSortedHand1.length - 1].getValue() - straightSortedHand2[straightSortedHand2.length - 1].getValue();
                }
                if(hand1Rank.isFlush()){
                    return sortedHand1[sortedHand1.length - 1].getValue() - sortedHand2[sortedHand2.length - 1].getValue();
                }
                if(hand1Rank.getRank() == 3){
                    return (getSumsValue(4, hand1Rank))[0] - (getSumsValue(4, hand2Rank))[0];
                }
                if(hand1Rank.getRank() == 4 || hand1Rank.getRank() == 7){
                    return (getSumsValue(3, hand1Rank))[0] - (getSumsValue(3, hand2Rank))[0];
                }
                if(hand1Rank.getRank() == 8){
                    int differenceHighPair = (getSumsValue(2, hand1Rank))[1] - (getSumsValue(2, hand2Rank))[1];
                    int differenceLowPair = (getSumsValue(2, hand1Rank))[0] - (getSumsValue(2, hand2Rank))[0];
                    if(differenceHighPair != 0){
                        return differenceHighPair;
                    }
                    if(differenceLowPair != 0){
                        return differenceLowPair;
                    }
                    return (getSumsValue(1, hand1Rank))[0] - (getSumsValue(1, hand2Rank))[0];
                }
                if(hand1Rank.getRank() == 9){
                    int differencePair = (getSumsValue(2, hand1Rank))[0] - (getSumsValue(2, hand2Rank))[0];                    
                    if(differencePair != 0){
                        return differencePair;
                    }       
                    for(int position = sortedHand1.length - 1; position >= 0; --position){
                        int cardDifference = sortedHand1[position].getValue() - sortedHand2[position].getValue();
                        if(cardDifference != 0){
                            return cardDifference;
                        }
                    }                    
                    return compareCardValues(hand1, hand2);
                }
                if(hand1Rank.getRank() == 10){
                    return compareCardValues(hand1, hand2);
                }
            }
        }        
        return 0;    
    }
    
    private int compareCardValues(PlayingCard[] hand1, PlayingCard[] hand2){
        PlayingCard[] sortedHand1 = orderCards(hand1);
        PlayingCard[] sortedHand2 = orderCards(hand2);        
        for(int position = sortedHand1.length - 1; position >= 0; --position){
            int cardDifference = sortedHand1[position].getValue() - sortedHand2[position].getValue();
            if(cardDifference != 0){
                return cardDifference;
            }
        }                    
        return 0;
    }
    
    private int[] getSumsValue(int sum, HandRank handRank){
        int[] valueSummary = handRank.getValues();
        ArrayList values = new ArrayList();
        for(int i = 0; i < valueSummary.length; i++){
            if(valueSummary[i] == sum){
                values.add(new Integer(i));
            }
        }
        int[] results = new int[values.size()];
        for(int i = 0; i < results.length; i++){
            results[i] = ((Integer)values.get(i)).intValue();
        }
        return results;
    }
}
