/*
 * PokerCardImageFetcher.java
 *
 * Created on March 4, 2006, 6:43 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker.cardimages;

import ccarr.cards.Card;
import ccarr.cards.playing.poker.cardimages.CardImageFetcher;
import ccarr.cards.playing.PlayingCard;
import java.io.File;
/**
 *
 * @author z
 */
public class PokerCardImageFetcher implements CardImageFetcher{
    String folder;
    String extension;
    /** Creates a new instance of PokerCardImageFetcher */
    public PokerCardImageFetcher(String folder, String extension){
        this.folder = folder;
        this.extension = extension;
    }

    public java.awt.Image fetchImage(Card card) throws Exception {
        int value = ((PlayingCard)card).getValue();
        int suit = ((PlayingCard)card).getSuit();        
        switch(suit){
            case 0:
                    suit = 2;
                    break;
            case 1:
                    suit = 3;
                    break;
            case 2:
                    suit = 1;
                    break;
            case 3:
                    suit = 4;
                    break;
        }
                                     
        value = PlayingCard.cardsPerSuit - 1 - value;
        
        int picValue = 4 * value + suit;
        java.net.URL url = this.getClass().getResource( picValue + "." + extension );        
        return javax.imageio.ImageIO.read(url);        
    }
    
}
