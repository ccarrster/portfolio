/*
 * CardImageFetcher.java
 *
 * Created on March 4, 2006, 6:35 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ccarr.cards.playing.poker.cardimages;
import ccarr.cards.*;
import java.awt.Image;

/**
 *
 * @author z
 */
public interface CardImageFetcher {
    public Image fetchImage(Card card) throws Exception;
}
