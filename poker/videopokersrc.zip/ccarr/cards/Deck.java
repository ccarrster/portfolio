/*
 * Deck.java
 *
 * Created on February 26, 2006, 10:43 PM
 *
 * A multipurpose deck of cards
 */

package ccarr.cards;

import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author Christopher Gordon Carr
 */
public class Deck {
    ArrayList cards;
    /** Creates a new instance of Deck */
    //Top is deck size -1
    //bottom is 0
    public Deck() {
        cards = new ArrayList();
    }
    
    /*Purpose:Add a card to the deck, where it goes is not important
     */
    public void addCard(Card card){
        cards.add(card);
    }
    
    /*Purpose:Add a card to the top or bottom of the deck
     */
    public void addCard(boolean top, Card card){
        cards.add(topOrBottomCardLocation(top), card);
    }
    
    /*Purpose:Add multipule cards to the top or the bottom of the deck
     *The order of the array of cards is important
     *The cards will be added 1 at a time starting from card 0 and incrementing     
     */
    public void addCards(boolean top, Card[] newCards){
        for(int i = 0; i < newCards.length; i++){
            addCard(top, newCards[i]);
        }
    }
    
    /*Purpose:Add multipule cards, where they go is not important     
     */
    public void addCards(Card[] newCards){
        for(int i = 0; i < newCards.length; i++){
            addCard(newCards[i]);
        }
    }
    
    /*Purpose:To standardize which card is the top or bottom card
     */
    protected int topOrBottomCardLocation(boolean top){
        if(top){
            return getDeckSize() - 1;
        } else {
            return 0;
        }
    }
    
    /*Purpose:To standardize which direction cards are peeked/pulled at from the deck
     */
    private int topOrBottomIterator(boolean top, int value){
        if(top){
            return --value;
        } else {
            return ++value;
        }
    }
    
    /*Purpose:To take and remove cards from the deck
     */
    public Card[] pullCards(boolean top, int numberOfCards){
        Card[] pulledCards = peekCards(top, numberOfCards);
        for(int i = 0; i < pulledCards.length; i++){
            if(pulledCards[i] == null)
                break;
            cards.remove(pulledCards[i]);
        }
        return pulledCards;
    }
    
    /*Purpose:To randomize the deck
     */
    public void shuffle(){
        Random random = new Random(System.currentTimeMillis());
        ArrayList newCards = new ArrayList();
        while(cards.size() != 0){
            int randomNumber = random.nextInt(cards.size());
            newCards.add(cards.get(randomNumber));
            cards.remove(randomNumber);
        }
        cards = newCards;
    }
    
    /*Purpose:To look at cards from the deck but leave them there
     *Will fill the card[] with nulls if there are not enough cards
     *Game logic can deside what to do with that.
     */
    public Card[] peekCards(boolean top, int numberOfCards){
        Card[] peekedCards = new Card[numberOfCards];
        int cardLocation = topOrBottomCardLocation(top);
        for(int i = 0; i < numberOfCards; i++){
            if(cardLocation >= cards.size() || cardLocation < 0)
                break;
            peekedCards[i] = (Card)cards.get(cardLocation);
            cardLocation = topOrBottomIterator(top, cardLocation);            
        }      
        return peekedCards;
    }    
    
    /*Purpose:To know how many cards are in the deck
     */
    public int getDeckSize(){
        return cards.size();
    }
}
