package com.chriscarr.chat;

@SuppressWarnings("serial")
public class InvalidIdException extends Exception {

}
