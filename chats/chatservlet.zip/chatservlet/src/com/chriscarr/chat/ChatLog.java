package com.chriscarr.chat;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ChatLog {
	private List<ChatMessage> chatHistory;
	private List<String> handles;
	private int messageId;
	private int logId;
	public ChatLog(int logId){
		this.logId = logId;
		chatHistory = new ArrayList<ChatMessage>();
		handles = new ArrayList<String>();
		messageId = 0;
	}
	public int nextId(){
		return messageId++;
	}
	public List<ChatMessage> getMessagesAfter(int afterId){
		List<ChatMessage> messagesAfter = new ArrayList<ChatMessage>();
		for(Iterator<ChatMessage> chatHistoryIter = chatHistory.iterator(); chatHistoryIter.hasNext();){
			ChatMessage currentMessage = chatHistoryIter.next();
			if(currentMessage.getId() > afterId){
				messagesAfter.add(currentMessage);
			}
		}
		return messagesAfter;
	}
	public void addMessage(String message, String handle) throws EmptyMessageException, InvalidIdException, InvalidHandleException, InvalidTimestampException{		
		chatHistory.add(new ChatMessage(message, nextId(), handle, new Date()));
	}
	public int getLogId() {
		return logId;
	}
	public void join(String handle) throws HandleAlreadyInChatException {
		if(!handles.contains(handle)){
			handles.add(handle);
		} else {
			throw new HandleAlreadyInChatException();
		}
	}
	public void leave(String handle) throws HandleNotFoundInChatException {
		if(handles.contains(handle)){
			handles.remove(handle);
		} else {
			throw new HandleNotFoundInChatException();
		}
	}
	public List<String> getHandles() {
		return handles;
	}	
}
