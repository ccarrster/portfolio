package com.chriscarr.chat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class ChatServlet extends HttpServlet {

  private int logId;
  private List<ChatLog> chatLogs;

  public static final String CREATECHAT = "CREATECHAT";
  public static final String DESTROYCHAT = "DESTROYCHAT";
  public static final String JOINCHAT = "JOINCHAT";
  public static final String LEAVECHAT = "LEAVECHAT";
  public static final String ADDMESSAGE = "ADDMESSAGE";
  public static final String GETMESSAGE = "GETMESSAGE";
  public static final String GETCHATS = "GETCHATS";
  public static final String GETHANDLES = "GETHANDLES";
	
  public ChatServlet(){
	  chatLogs = new ArrayList<ChatLog>();
  }
  
  private ChatLog getChatLog(int logId) throws InvalidChatIdException{
	  for(Iterator<ChatLog> chatLogIter = chatLogs.iterator(); chatLogIter.hasNext();){
		  ChatLog chatLog = chatLogIter.next();
		  if(chatLog.getLogId() == logId){
			  return chatLog;			  
		  }
	  }
	  throw new InvalidChatIdException();
  }
  
  private int getChatId(String chatPram) throws InvalidChatIdException{
	  try{
		  return Integer.parseInt(chatPram);
	  } catch(NumberFormatException e){
		  throw new InvalidChatIdException();
	  }
  }
  
  private int getAfterId(String chatPram) throws InvalidAfterIdException{
	  try{
		  return Integer.parseInt(chatPram);
	  } catch(NumberFormatException e){
		  throw new InvalidAfterIdException();
	  }
  }
  
  public void doGet(HttpServletRequest request, HttpServletResponse response)
                               throws ServletException, IOException {
	  response.setContentType("text/xml"); 
      response.setHeader("Cache-Control", "no-cache");
      
      String messageType = request.getParameter("messageType");
      if(messageType != null && !messageType.equals("")){
    	  if(messageType.equals(CREATECHAT)){
    		  synchronized(chatLogs){
    			  ChatLog chatLog = new ChatLog(logId++);    		  
    			  chatLogs.add(chatLog);
    			  response.getWriter().write("<chatid>" + Integer.toString(chatLog.getLogId()) + "</chatid>");
    		  }    		  
    	  } else if(messageType.equals(DESTROYCHAT)){	      		 
			try {
				synchronized(chatLogs){
					ChatLog chatLog = getChatLog(getChatId(request.getParameter("chatId")));				
					chatLogs.remove(chatLog);
				}
				response.getWriter().write("<ok/>");
			} catch (InvalidChatIdException e) {
				response.getWriter().write("<error>Invalid Chat Id</error>");
			}			  
    	  } else if(messageType.equals(JOINCHAT)){
			try {
				synchronized(chatLogs){
					ChatLog chatLog = getChatLog(getChatId(request.getParameter("chatId")));
			     	chatLog.join(request.getParameter("handle"));
				}
	    		response.getWriter().write("<ok/>");
			} catch (InvalidChatIdException e) {
				response.getWriter().write("<error>Invalid chat id</error>");
			} catch (HandleAlreadyInChatException e) {
				response.getWriter().write("<error>Handle already in chat</error>");
			}    		 
    	  } else if(messageType.equals(LEAVECHAT)){    		 
			try {
				synchronized(chatLogs){
					ChatLog chatLog = getChatLog(getChatId(request.getParameter("chatId")));
					chatLog.leave(request.getParameter("handle"));
				}
	    		response.getWriter().write("<ok/>");
			} catch (InvalidChatIdException e) {
				response.getWriter().write("<error>Invalid chat id</error>");
			} catch (HandleNotFoundInChatException e) {
				response.getWriter().write("<error>Handle not in chat</error>");
			}
    	  } else if(messageType.equals(ADDMESSAGE)){
			try {
				synchronized(chatLogs){
					ChatLog chatLog = getChatLog(getChatId(request.getParameter("chatId")));
					chatLog.addMessage(request.getParameter("message"), request.getParameter("handle"));
				}
				response.getWriter().write("<ok/>");
			} catch (InvalidChatIdException e) {
				response.getWriter().write("<error>Invalid chat id</error>");
			} catch (EmptyMessageException e) {
				response.getWriter().write("<error>Empty message</error>");
			} catch (InvalidIdException e) {
				response.getWriter().write("<error>Invalid message id</error>");
			} catch (InvalidHandleException e) {
				response.getWriter().write("<error>Invalid handle</error>");
			} catch (InvalidTimestampException e) {
				response.getWriter().write("<error>Invalid timestamp</error>");
			}
    	  } else if(messageType.equals(GETMESSAGE)){
			try {
				List<ChatMessage> chatMessages = new ArrayList<ChatMessage>();
				StringBuffer messages = new StringBuffer();
				messages.append("<messages>");
				synchronized(chatLogs){
					ChatLog chatLog = getChatLog(getChatId(request.getParameter("chatId")));										
					chatMessages = chatLog.getMessagesAfter(getAfterId(request.getParameter("afterMessageId")));
				}
				for(Iterator<ChatMessage> chatMessagesIter = chatMessages.iterator(); chatMessagesIter.hasNext();){
					ChatMessage chatMessage = chatMessagesIter.next();
					messages.append("<message>");
					messages.append("<text>");
					messages.append(chatMessage.getMessage());
					messages.append("</text>");
					messages.append("<id>");
					messages.append(chatMessage.getId());
					messages.append("</id>");
					messages.append("<handle>");
					messages.append(chatMessage.getHandle());
					messages.append("</handle>");
					messages.append("<timestamp>");
					messages.append(chatMessage.getTimestamp());
					messages.append("</timestamp>");
					messages.append("</message>");
				}
				messages.append("</messages>");
				response.getWriter().write(messages.toString());
			} catch (InvalidChatIdException e) {
				response.getWriter().write("<error>Invalid chat id</error>");
			} catch (InvalidAfterIdException e) {
				response.getWriter().write("<error>Invalid after id</error>");
			}    		      		  
    	  } else if(messageType.equals(GETCHATS)){
    		  StringBuffer responseString = new StringBuffer();
    		  responseString.append("<chatids>");
    		  synchronized(chatLogs){
    			  for(Iterator<ChatLog> chatLogIter = chatLogs.iterator(); chatLogIter.hasNext();){
    				  ChatLog chatLog = chatLogIter.next();
    				  responseString.append("<chatid>");
    				  responseString.append(chatLog.getLogId());
    				  responseString.append("</chatid>");
    			  }  
    		  }
    		  responseString.append("</chatids>");
    	  	  response.getWriter().write(responseString.toString());
    	  } else if(messageType.equals(GETHANDLES)){
				try {
					synchronized(chatLogs){
						ChatLog chatLog = getChatLog(getChatId(request.getParameter("chatId")));
				     	List<String> handles = chatLog.getHandles();
				     	StringBuffer responseString = new StringBuffer();
						responseString.append("<handles>");
						for(Iterator<String> handlesIter = handles.iterator(); handlesIter.hasNext();){
							responseString.append("<handle>");
							responseString.append(handlesIter.next());
							responseString.append("</handle>");
						}  
						responseString.append("</handles>");
						response.getWriter().write(responseString.toString());
					}
					response.getWriter().write("<ok/>");
				} catch (InvalidChatIdException e) {
					response.getWriter().write("<error>Invalid chat id</error>");
				} 		  	  
    	  } else {
    		  response.getWriter().write("<error>Invalid message type</error>");
    	  }
      } else {
    	  response.getWriter().write("<error>Empty message type</error>");
      }      
  }
}