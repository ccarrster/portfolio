package com.chriscarr.chat;

import java.util.Date;

public class ChatMessage {
	private String handle;
	private String message;
	private int id;
	private Date timestamp;
	
	public ChatMessage(String message, int id, String handle, Date timestamp) throws EmptyMessageException, InvalidIdException, InvalidHandleException, InvalidTimestampException {
		super();
		if(message == null || message.equals("")){
			throw new EmptyMessageException();
		}
		if(id < 0){
			throw new InvalidIdException();
		}
		if(handle == null || handle.equals("")){
			throw new InvalidHandleException();
		}
		if(timestamp == null){
			throw new InvalidTimestampException();
		}
		this.message = message;
		this.id = id;
		this.handle = handle;
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}
	public int getId() {
		return id;
	}
	public String getHandle() {
		return handle;
	}
	public Date getTimestamp() {
		return timestamp;
	}
}
