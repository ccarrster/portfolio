package com.chriscarr.chat;

@SuppressWarnings("serial")
public class HandleAlreadyInChatException extends Exception {

}
