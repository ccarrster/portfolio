//<![CDATA[

  function initRequest() {
       if (window.XMLHttpRequest) {
           return new XMLHttpRequest();
       } else if (window.ActiveXObject) {
           isIE = true;
           return new ActiveXObject("Microsoft.XMLHTTP");
       }
   }

   function createChat() {
	var url = "/chatservlet/chatservlet?messageType=CREATECHAT";
	var req = initRequest();
	req.onreadystatechange = function() {
	   if (req.readyState == 4) {
		   if (req.status == 200) {
			   parseCreateChat(req.responseXML);
		   } else if (req.status == 204){
			   alert('error');
		   }
	   }
	};
	req.open("GET", url, true);
	req.send(null);
   }

   function parseCreateChat(responseXML) {
   	var chatId = responseXML.getElementsByTagName("chatid")[0];
   	alert(chatId.childNodes[0].nodeValue);
   }
   
   function receiveMessages(chatId){
   }
   function getMessages(chatId, afterId){
   }
   function sendMessage(chatId, message, handle){
   }
   function destroyChat(chatId){
   }
   function joinChat(chatId){
   }
   function leaveChat(chatId){
   }


   //]]>