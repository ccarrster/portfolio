package com.chriscarr.chat;

@SuppressWarnings("serial")
public class InvalidAfterIdException extends Exception {

}
