package com.chriscarr.chat;

@SuppressWarnings("serial")
public class HandleNotFoundInChatException extends Exception {

}
