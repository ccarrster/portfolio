package com.chriscarr.simplemaze.game;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Treasure {

	int treasureId;
	public Treasure(int treasureId) {
		this.treasureId = treasureId;
	}

	public Image getImage() {		
		try {
			return ImageIO.read(new File(treasureId + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
