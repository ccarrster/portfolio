package com.chriscarr.simplemaze.game;

public class GameLauncher {

	public GameLauncher(){
		new Game();
	}
	
	public static void main(String[] args) {
		new GameLauncher();
	}

}
