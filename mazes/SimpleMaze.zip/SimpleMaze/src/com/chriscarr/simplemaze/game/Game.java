package com.chriscarr.simplemaze.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.chriscarr.simplemaze.CardinalPassage;
import com.chriscarr.simplemaze.PushGrid;
import com.chriscarr.simplemaze.Tile;

public class Game {
	/*
	 * Players
	 * Turns
	 * Players positions
	 * Board of tiles
	 * Players moving
	 * Treasures
	 * Scoring treasures
	 * drawing the board
	 * rotating the piece
	 * placing the piece(is it valid)
	 * end game
	 * home squares
	 * who starts first
	 * how many players are there
	 */
	
	/*
	 * One player only
	 * Swing
	 * No treasures at first/home base
	 * No board shifting at first/rotating pieces
	 * Just move, draw
	 * move, draw
	 */
	int players = 1;
	int boardWidth = 7;
	int boardHeight = 7;	
	//treasures = 24
	int totalTiles = boardWidth * boardHeight;
	CardinalPassage[][] board;
	List<Tile> freeTiles;
	List<Treasure> treasures;
	Tile freeTile;	
	MazePanel panel;
	
	public Game(){		
		System.out.println("Move tiles with: wer,tgb,vcx,zaq (push from: north,east,south,west)");
		//TODO draw free tile
		//TODO rotate free tile
		//TODO move players
		//TODO collect treasure
		//TODO home base logic
		//TODO peek treasure card
		
		treasures = new ArrayList<Treasure>();
		for(int i = 0; i < 24; i++){
			treasures.add(new Treasure(i));
		}
		Collections.shuffle(treasures);
		
		freeTiles = new ArrayList<Tile>();
		//T with treasure
		for(int i = 0; i < 4; i++){
			//TODO add treasure
			freeTiles.add(new Tile(false, true, true, true, treasures.remove(0)));
		}
		//L with treasure
		for(int i = 0; i < 8; i++){
			//TODO add treasure
			freeTiles.add(new Tile(false, true, true, false, treasures.remove(0)));		
		}
		//L without treasure
		for(int i = 0; i < 10; i++){
			freeTiles.add(new Tile(false, true, true, false));
		}
		//Straight
		for(int i = 0; i < 12; i++){
			freeTiles.add(new Tile(false, true, false, true));
		}
		Collections.shuffle(freeTiles);
		
		board = new CardinalPassage[boardWidth][boardHeight];
		
		for(int i = 0; i < boardWidth; i++){
			board[i] = new CardinalPassage[boardHeight];
		}
		
		//4 courners
		board[0][0] = new Tile(false, true, true, false);
		board[0][0].setBlueUser(true);
		board[boardWidth - 1][0] = new Tile(false, false, true, true);
		board[boardWidth - 1][0].setRedUser(true);
		board[0][boardHeight - 1] = new Tile(true, true, false, false);
		board[0][boardHeight - 1].setYellowUser(true);
		board[boardWidth - 1][boardHeight - 1] = new Tile(true, false, false, true);
		board[boardWidth - 1][boardHeight - 1].setGreenUser(true);
		
		//Sides
		//Top
		board[2][0] = new Tile(false, true, true, true, treasures.remove(0));
		board[4][0] = new Tile(false, true, true, true, treasures.remove(0));
		
		//bottom
		board[2][boardHeight - 1] = new Tile(true, true, false, true, treasures.remove(0));
		board[4][boardHeight - 1] = new Tile(true, true, false, true, treasures.remove(0));
		
		//left
		board[0][2] = new Tile(true, true, true, false, treasures.remove(0));
		board[0][4] = new Tile(true, true, true, false, treasures.remove(0));
		
		//right
		board[boardWidth - 1][2] = new Tile(true, false, true, true, treasures.remove(0));
		board[boardWidth - 1][4] = new Tile(true, false, true, true, treasures.remove(0));
		
		//Middle
		board[2][2] = new Tile(false, true, true, true, treasures.remove(0));
		board[2][4] = new Tile(true, true, true, false, treasures.remove(0));
		board[4][2] = new Tile(true, false, true, true, treasures.remove(0));
		board[4][4] = new Tile(true, true, false, true, treasures.remove(0));
		
		//The rest
		for(int column = 0; column < boardWidth; column++){			
			for(int row = 0; row < boardHeight; row++){
				if(board[column][row] == null){
					board[column][row] = getRandomTile();
				}
			}
		}
		int imageWidth = 50;
		int imageHeight = 50;
		MazeFrame frame = new MazeFrame(this, imageWidth, imageHeight);		
		panel = new MazePanel(imageWidth, imageHeight);
		panel.setGrid(board);
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
		
		freeTile = freeTiles.remove(0);		
	}
	
	public Tile getFreeTile(){
		return freeTile;
	}
	
	public void rotateFreeTile(){
		freeTile.rotate();
	}
	
	private void pushAt(int direction, int index){
		PushGrid<CardinalPassage> pushGrid = new PushGrid<CardinalPassage>(board);
		freeTile = (Tile) pushGrid.pushAt(direction, index, freeTile);	
		if(direction == PushGrid.NORTH || direction == PushGrid.SOUTH){
			for(int row = 0; row < boardHeight; row++){
				board[index][row] = pushGrid.getAt(index, row);
			}
		} else if(direction == PushGrid.EAST || direction == PushGrid.WEST){
			for(int column = 0; column < boardWidth; column++){
				board[column][index] = pushGrid.getAt(column, index);
			}
		}
	}
	
	private Tile rotateTile(Tile tile){
		int rotations = (int)(Math.random() * 4);
		for(int i = 0; i < rotations; i++){
			tile.rotate();
		}
		return tile;
	}
	
	private Tile getRandomTile(){
		Tile tile = freeTiles.remove(0);
		return rotateTile(tile);
	}

	public void keyTyped(char keyChar) {
		if(keyChar == 'w'){
			pushAt(PushGrid.NORTH, 1);
		} else if(keyChar == 'e'){
			pushAt(PushGrid.NORTH, 3);
		} else if(keyChar == 'r'){
			pushAt(PushGrid.NORTH, 5);
		} else if(keyChar == 't'){
			pushAt(PushGrid.EAST, 1);
		} else if(keyChar == 'g'){
			pushAt(PushGrid.EAST, 3);
		} else if(keyChar == 'b'){
			pushAt(PushGrid.EAST, 5);
		} else if(keyChar == 'v'){
			pushAt(PushGrid.SOUTH, 5);
		} else if(keyChar == 'c'){
			pushAt(PushGrid.SOUTH, 3);
		} else if(keyChar == 'x'){
			pushAt(PushGrid.SOUTH, 1);
		} else if(keyChar == 'z'){
			pushAt(PushGrid.WEST, 5);
		} else if(keyChar == 'a'){
			pushAt(PushGrid.WEST, 3);
		} else if(keyChar == 'q'){
			pushAt(PushGrid.WEST, 1);
		} else {
			return;
		}
		panel.setGrid(board);
		
	}

	public void getThere(int x, int y) {		
		System.out.println(x + "," + y);
	}
}
