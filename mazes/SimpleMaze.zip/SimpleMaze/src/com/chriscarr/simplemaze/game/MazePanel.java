package com.chriscarr.simplemaze.game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.chriscarr.simplemaze.CardinalPassage;

@SuppressWarnings("serial")
public class MazePanel extends JPanel {
	int imageHeight;
	int imageWidth;
	CardinalPassage[][] grid;
	BufferedImage xPath;
	BufferedImage iPath;
	BufferedImage lPath;
	BufferedImage tPath;
	BufferedImage onePath;
	BufferedImage noPath;
	//TODO load images
	BufferedImage blueUser;
	BufferedImage redUser;
	BufferedImage greenUser;
	BufferedImage yellowUser;
	
	public MazePanel(int imageWidth, int imageHeight){
		this.imageWidth = imageWidth;
		this.imageHeight = imageHeight;
		try {
			blueUser = ImageIO.read(new File("blue.png"));
			redUser = ImageIO.read(new File("red.png"));
			greenUser = ImageIO.read(new File("green.png"));
			yellowUser = ImageIO.read(new File("yellow.png"));
			xPath = ImageIO.read(new File("xPath.jpg"));
			lPath = ImageIO.read(new File("lPath.jpg"));
			iPath = ImageIO.read(new File("iPath.jpg"));
			noPath = ImageIO.read(new File("noPath.jpg"));
			onePath = ImageIO.read(new File("onePath.jpg"));
			tPath = ImageIO.read(new File("tPath.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public void setGrid(CardinalPassage[][] grid){
		this.grid = grid;
		this.setPreferredSize(new Dimension(imageWidth * grid.length, imageHeight * grid[0].length));
		this.repaint();
	}
	
	public static BufferedImage rotate(BufferedImage img, int angle) {  
		int w = img.getWidth();  
		int h = img.getHeight();  
		BufferedImage dimg = new BufferedImage(w, h, img.getType());  
		Graphics2D g = dimg.createGraphics();  
		g.rotate(Math.toRadians(angle), w/2, h/2);  
		g.drawImage(img, null, 0, 0);  
		return dimg;  
	}
	
	public void paint(Graphics g){
		if(grid != null){
			for(int row = 0; row < grid.length; row++){
				for(int column = 0; column < grid[row].length; column++){
					boolean n = grid[row][column].isOpenNorth();
					boolean e = grid[row][column].isOpenEast();
					boolean s = grid[row][column].isOpenSouth();					
					boolean w = grid[row][column].isOpenWest();
					if(n && e && s && w){
						g.drawImage(xPath, row * imageWidth, column * imageHeight, this);
					} else if(n && e && s && !w){
						g.drawImage(tPath, row * imageWidth, column * imageHeight, this);
					} else if(!n && e && s && w){
						g.drawImage(rotate(tPath, 90), row * imageWidth, column * imageHeight, this);
					} else if(n && !e && s && w){
						g.drawImage(rotate(tPath, 180), row * imageWidth, column * imageHeight, this);
					} else if(n && e && !s && w){
						g.drawImage(rotate(tPath, 270), row * imageWidth, column * imageHeight, this);
					} else if(n && e && !s && !w){
						g.drawImage(lPath, row * imageWidth, column * imageHeight, this);
					} else if(!n && e && s && !w){
						g.drawImage(rotate(lPath, 90), row * imageWidth, column * imageHeight, this);
					} else if(!n && !e && s && w){
						g.drawImage(rotate(lPath, 180), row * imageWidth, column * imageHeight, this);
					} else if(n && !e && !s && w){
						g.drawImage(rotate(lPath, 270), row * imageWidth, column * imageHeight, this);
					} else if(n && !e && s && !w){
						g.drawImage(iPath, row * imageWidth, column * imageHeight, this);
					} else if(!n && e && !s && w){
						g.drawImage(rotate(iPath, 90), row * imageWidth, column * imageHeight, this);
					} else if(n && !e && !s && !w){
						g.drawImage(onePath, row * imageWidth, column * imageHeight, this);
					} else if(!n && e && !s && !w){
						g.drawImage(rotate(onePath, 90), row * imageWidth, column * imageHeight, this);
					} else if(!n && !e && s && !w){
						g.drawImage(rotate(onePath, 180), row * imageWidth, column * imageHeight, this);
					} else if(!n && !e && !s && w){
						g.drawImage(rotate(onePath, 270), row * imageWidth, column * imageHeight, this);
					} else {
						g.drawImage(noPath, row * imageWidth, column * imageHeight, this);
					}
					//TODO treasures
					//Treasure is a 16 by 16 image
					if(grid[row][column].isTreasure()){
						Treasure treasure = grid[row][column].getTreasure();
						g.drawImage(treasure.getImage(), (row * imageWidth) + 17, (column * imageHeight) + 17, this);
					}
					if(grid[row][column].isBlueUser()){
						g.drawImage(blueUser, (row * imageWidth) + 5, (column * imageHeight) + 5, this);
					}
					if(grid[row][column].isRedUser()){
						g.drawImage(redUser, (row * imageWidth) + 5, (column * imageHeight) + 30, this);
					}
					if(grid[row][column].isGreenUser()){
						g.drawImage(greenUser, (row * imageWidth) + 30, (column * imageHeight) + 5, this);
					}
					if(grid[row][column].isYellowUser()){
						g.drawImage(yellowUser, (row * imageWidth) + 30, (column * imageHeight) + 30, this);
					}
				}
			}
		}
		g.setColor(Color.black);
		g.fillOval(16, 16, 19, 19);
		g.setColor(Color.blue);
		g.fillOval(17, 17, 16, 16);
		
		g.setColor(Color.black);		
		g.fillOval((imageWidth * (grid.length - 1)) + 16, 16, 18, 18);
		g.setColor(Color.red);
		g.fillOval((imageWidth * (grid.length - 1)) + 17, 17, 16, 16);
		
		g.setColor(Color.black);
		g.fillOval(16, (imageHeight * (grid[0].length - 1)) + 16, 19, 19);
		g.setColor(Color.yellow);
		g.fillOval(17, (imageHeight * (grid[0].length - 1)) + 17, 16, 16);
		
		g.setColor(Color.black);
		g.fillOval((imageWidth * (grid.length - 1)) + 16, (imageHeight * (grid[0].length - 1)) + 16, 19, 19);
		g.setColor(Color.green);
		g.fillOval((imageWidth * (grid.length - 1)) + 17, (imageHeight * (grid[0].length - 1)) + 17, 16, 16);
		
	}
}
