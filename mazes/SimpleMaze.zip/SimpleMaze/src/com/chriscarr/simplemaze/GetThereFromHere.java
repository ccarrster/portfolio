package com.chriscarr.simplemaze;

public class GetThereFromHere {
	
	//Psudo code
	/*
	 * x,y of where you are
	 * x,y of where you want to go
	 * grid of passages
	 * 
	 * recursive
	 * Is this where I wanted to go?
	 * return true
	 * else mark the square as traveled and try my unmarked neighbors(N,E,S,W)
	 * if all my neigbours did not return true unmark as visited
	 * return false
	 */
	
	public static boolean canIGetThereFromHere(int xHere, int yHere, int xThere, int yThere, CardinalPassage[][] grid){
		if(xHere == xThere && yHere == yThere){
			return true;
		} else {			
			//Mark as visited
			grid[xHere][yHere].setVisited(true);
			if(yHere != 0 && canNorth(grid[xHere][yHere], grid[xHere][yHere - 1]) && !grid[xHere][yHere - 1].isVisited()){
				if(canIGetThereFromHere(xHere, yHere - 1, xThere, yThere, grid)){
					grid[xHere][yHere].setVisited(false);
					return true;
				}
			}
			if(xHere != grid.length - 1 && canEast(grid[xHere][yHere], grid[xHere + 1][yHere]) && !grid[xHere + 1][yHere].isVisited()){
				if(canIGetThereFromHere(xHere + 1, yHere, xThere, yThere, grid)){
					grid[xHere][yHere].setVisited(false);
					return true;
				}
			}
			if(yHere != grid[0].length - 1 && canSouth(grid[xHere][yHere], grid[xHere][yHere + 1]) && !grid[xHere][yHere + 1].isVisited() ){
				if(canIGetThereFromHere(xHere, yHere + 1, xThere, yThere, grid)){
					grid[xHere][yHere].setVisited(false);
					return true;
				}
			}
			if(xHere != 0 && canWest(grid[xHere][yHere], grid[xHere - 1][yHere]) && !grid[xHere - 1][yHere].isVisited()){
				if(canIGetThereFromHere(xHere - 1, yHere, xThere, yThere, grid)){
					grid[xHere][yHere].setVisited(false);
					return true;
				}
			}
			//Unmark as visited
			grid[xHere][yHere].setVisited(false);
			return false;
		}
	}
	
	private static boolean canNorth(CardinalPassage from, CardinalPassage to){
		return to != null && from.isOpenNorth() && to.isOpenSouth();			
	}
	private static boolean canEast(CardinalPassage from, CardinalPassage to){
		return to != null && from.isOpenEast() && to.isOpenWest();	
	}
	private static boolean canSouth(CardinalPassage from, CardinalPassage to){
		return to != null && from.isOpenSouth() && to.isOpenNorth();
	}
	private static boolean canWest(CardinalPassage from, CardinalPassage to){
		return to != null && from.isOpenWest() && to.isOpenEast();
	}
}
