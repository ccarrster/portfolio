package com.chriscarr.simplemaze;

import com.chriscarr.simplemaze.game.Treasure;

public class Tile implements CardinalPassage {

	boolean openNorth;
	boolean openEast;
	boolean openSouth;
	boolean openWest;
	boolean visited;
	Treasure treasure = null;
	boolean redUser = false;
	boolean greenUser = false;
	boolean yellowUser = false;
	boolean blueUser = false;
	
	public Tile(boolean openNorth,	boolean openEast, boolean openSouth, boolean openWest){
		this.openNorth = openNorth;
		this.openEast = openEast;
		this.openSouth = openSouth;
		this.openWest = openWest;		
		visited = false;
	}
	
	public Tile(boolean openNorth,	boolean openEast, boolean openSouth, boolean openWest, Treasure treasure){
		this.openNorth = openNorth;
		this.openEast = openEast;
		this.openSouth = openSouth;
		this.openWest = openWest;
		this.treasure = treasure;
		visited = false;		
	}
	
	public boolean isOpenNorth() {
		return openNorth;
	}
	
	public boolean isOpenEast() {
		return openEast;
	}

	public boolean isOpenSouth() {
		return openSouth;
	}

	public boolean isOpenWest() {
		return openWest;
	}
	
	public void rotate(){
		boolean tempNorth = openNorth;
		boolean tempEast = openEast;
		boolean tempSouth = openSouth;
		boolean tempWest = openWest;
		openEast = tempNorth;
		openSouth = tempEast;
		openWest = tempSouth;
		openNorth = tempWest;
	}

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	
	public Treasure getTreasure() {
		return treasure;
	}

	public boolean isTreasure() {
		return !(treasure == null);
	}

	public boolean isBlueUser() {
		return blueUser;
	}

	public boolean isGreenUser() {
		return greenUser;
	}

	public boolean isRedUser() {
		return redUser;
	}

	public boolean isYellowUser() {		
		return yellowUser;
	}

	public void setBlueUser(boolean b) {
		blueUser = b;
	}

	public void setGreenUser(boolean b) {
		greenUser = b;
	}

	public void setRedUser(boolean b) {
		redUser = b;
	}

	public void setYellowUser(boolean b) {
		yellowUser = b;
	}	

}
