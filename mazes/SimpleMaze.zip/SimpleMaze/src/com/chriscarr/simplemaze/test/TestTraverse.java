package com.chriscarr.simplemaze.test;

import com.chriscarr.simplemaze.GetThereFromHere;
import com.chriscarr.simplemaze.Tile;

import junit.framework.TestCase;

public class TestTraverse extends TestCase {
	public void testTraverse(){
		Tile tile = new Tile(false, false, false, false);
		Tile[][] grid = new Tile[][]{{tile}};
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 0, grid));
	}
	
	public void testTraverseTwoTilesNS(){
		Tile tiles = new Tile(true, false, false, false);
		Tile tilen = new Tile(false, false, true, false);
		Tile[][] grid = new Tile[][]{{tilen, tiles}};
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 1, 0, 0, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 1, grid));
	}
	
	public void testTraverseTwoTilesNSNoPathSouth(){
		Tile tiles = new Tile(false, false, false, false);
		Tile tilen = new Tile(false, false, true, false);
		Tile[][] grid = new Tile[][]{{tilen, tiles}};
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 1, 0, 0, grid));
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 1, grid));
	}
	
	public void testTraverseTwoTilesNSNoPathNorth(){
		Tile tiles = new Tile(true, false, false, false);
		Tile tilen = new Tile(false, false, false, false);
		Tile[][] grid = new Tile[][]{{tilen, tiles}};
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 1, 0, 0, grid));
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 1, grid));
	}
	
	public void testTraverseTwoTilesEW(){
		Tile tilew = new Tile(false, true, false, false);
		Tile tilee = new Tile(false, false, false, true);
		Tile[][] grid = new Tile[][]{{tilew},{tilee}};
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 0, 1, 0, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(1, 0, 0, 0, grid));
	}
	
	public void testTraverseTwoTilesEWEastClosed(){
		Tile tilew = new Tile(false, true, false, false);
		Tile tilee = new Tile(false, false, false, false);
		Tile[][] grid = new Tile[][]{{tilew},{tilee}};
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 0, 1, 0, grid));
		assertFalse(GetThereFromHere.canIGetThereFromHere(1, 0, 0, 0, grid));
	}
	
	public void testTraverseTwoTilesEWWestClosed(){
		Tile tilew = new Tile(false, false, false, false);
		Tile tilee = new Tile(false, false, false, true);
		Tile[][] grid = new Tile[][]{{tilew},{tilee}};
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 0, 1, 0, grid));
		assertFalse(GetThereFromHere.canIGetThereFromHere(1, 0, 0, 0, grid));
	}
	
	public void testTraverseThreeTilesNS(){
		Tile tilet = new Tile(false, false, true, false);
		Tile tilem = new Tile(true, false, true, false);
		Tile tileb = new Tile(true, false, false, false);
		Tile[][] grid = new Tile[][]{{tilet, tilem, tileb}};
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 2, 0, 0, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 2, grid));
	}
	
	public void testTraverseHorseShoeTiles(){
		Tile tiletl = new Tile(false, true, true, false);
		Tile tiletr = new Tile(true, false, true, true);
		Tile tilebl = new Tile(true, false, false, false);
		Tile tilebr = new Tile(true, false, false, false);
		Tile[][] grid = new Tile[][]{{tiletl, tilebl}, {tiletr, tilebr}};
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 1, 1, 1, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(1, 1, 0, 1, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(1, 0, 0, 1, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 1, grid));
	}
	
	public void testTraverseTwoITilesGrid(){
		Tile tiletl = new Tile(false, false, true, false);
		Tile tiletr = new Tile(true, false, true, false);
		Tile tilebl = new Tile(true, false, false, false);
		Tile tilebr = new Tile(true, false, false, false);
		Tile[][] grid = new Tile[][]{{tiletl, tilebl}, {tiletr, tilebr}};
		assertTrue(GetThereFromHere.canIGetThereFromHere(0, 0, 0, 1, grid));
		assertTrue(GetThereFromHere.canIGetThereFromHere(1, 1, 1, 0, grid));
		assertFalse(GetThereFromHere.canIGetThereFromHere(1, 0, 0, 1, grid));
		assertFalse(GetThereFromHere.canIGetThereFromHere(0, 0, 1, 1, grid));
	}
}
