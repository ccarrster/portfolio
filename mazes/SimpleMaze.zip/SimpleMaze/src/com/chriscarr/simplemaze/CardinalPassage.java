package com.chriscarr.simplemaze;

import com.chriscarr.simplemaze.game.Treasure;

public interface CardinalPassage {
	public boolean isOpenNorth();
	public boolean isOpenEast();
	public boolean isOpenSouth();
	public boolean isOpenWest();
	public boolean isVisited();
	public void setVisited(boolean visited);
	public boolean isTreasure();
	public Treasure getTreasure();
	public boolean isBlueUser();
	public boolean isRedUser();
	public boolean isGreenUser();
	public boolean isYellowUser();
	public void setBlueUser(boolean b);
	public void setRedUser(boolean b);
	public void setGreenUser(boolean b);
	public void setYellowUser(boolean b);
}
