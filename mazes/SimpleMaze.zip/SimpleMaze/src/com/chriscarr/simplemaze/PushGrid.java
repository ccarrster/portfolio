package com.chriscarr.simplemaze;

public class PushGrid<E> {
	public static final int NORTH = 1;
	public static final int EAST = 2;
	public static final int SOUTH = 3;
	public static final int WEST = 4;
	E[][] grid;
	
	public PushGrid(E[][] grid){
		this.grid = grid;
	}
	
	public E getAt(int x, int y){
		return grid[x][y];
	}
	
	public void setAt(int x, int y, E object){
		grid[x][y] = object;
	}
	
	public E[][] getGrid(){
		return grid;
	}
	
	//Returns object pushed out
	public E pushAt(int fromDirection, int index, E newObject){
		E pushedOut = null;
		if(fromDirection == NORTH){
			int x = index;
			int y = grid[x].length - 1;
			pushedOut = grid[x][y];
			for(;y > 0; y--){
				grid[x][y] = grid[x][y - 1];
			}
			grid[x][0] = newObject;
			
		} else if(fromDirection == EAST){
			int x = 0;
			int y = index;
			pushedOut = grid[x][y];
			for(;x < grid.length - 1; x++){
				grid[x][y] = grid[x + 1][y];
			}
			grid[grid.length - 1][y] = newObject;
		} else if(fromDirection == SOUTH){
			int x = index;
			int y = 0;
			pushedOut = grid[x][y];
			for(;y < grid[x].length - 1; y++){
				grid[x][y] = grid[x][y + 1];
			}
			grid[x][grid[x].length - 1] = newObject;
		} else if(fromDirection == WEST){
			int x = grid.length - 1;
			int y = index;
			pushedOut = grid[x][y];
			for(;x > 0; x--){
				grid[x][y] = grid[x - 1][y];
			}
			grid[0][y] = newObject;
		}
		return pushedOut;
	}
}
