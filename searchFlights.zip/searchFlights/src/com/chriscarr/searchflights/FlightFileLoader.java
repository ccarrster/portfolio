package com.chriscarr.searchflights;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class FlightFileLoader {
	SimpleDateFormat sdf = new SimpleDateFormat("M-d-yyyy HH:mm:ss");
	public Date parseDate(String dateString) throws ParseException{
		String standardDateString = dateString.replace("/", "-");
		return sdf.parse(standardDateString);
	}
	
	public int cleanPrice(String priceString){
		return Integer.parseInt(priceString.replaceAll("[^0-9]", ""));
	}
	
	public List<Flight> loadFile(String filePath) throws IOException {
		List<Flight> result = new ArrayList<Flight>();
		File file = new File(filePath);
		BufferedReader br = new BufferedReader(new FileReader(file));
		String header = br.readLine();
		String[] headers = header.split("[,|]");
		String line;
		while ((line = br.readLine()) != null) {
			HashMap<String, String> flightHash = new HashMap<String, String>();
			String[] flightParts = line.split("[,|]");
			for(int i = 0; i < flightParts.length; i++){
				flightHash.put(headers[i], flightParts[i]);
			}
			
			try {
				result.add(new Flight(flightHash.get("Origin"), parseDate(flightHash.get("Departure Time")), flightHash.get("Destination"), parseDate(flightHash.get("Destination Time")), cleanPrice(flightHash.get("Price"))));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		br.close();
		return result;
	}

}
