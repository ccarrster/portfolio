package com.chriscarr.searchflights;

public class Search {

	private String origin;
	private String destination;
	
	public Search(String origin, String destination){
		this.origin = origin;
		this.destination = destination;
	}
	
	public String getOrigin() {
		return origin;
	}

	public String getDestination() {
		return destination;
	}

}
