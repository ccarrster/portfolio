package com.chriscarr.searchflights;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileRunnable implements Runnable{
	private final String filePath;
	private final Search search;
	private final SearchFlights searchFlights;

	FileRunnable(Search search, String filePath, SearchFlights searchFlights) {
		this.filePath = filePath;
		this.search = search;
		this.searchFlights = searchFlights;
	}

	@Override
	public void run() {
		FlightFileLoader ffl = new FlightFileLoader();
		List<Flight> result = new ArrayList<Flight>();
		try {
			List<Flight> flights = ffl.loadFile(filePath);
			for(Flight flight : flights){
				if(search.getOrigin().equals(flight.getOrigin()) && search.getDestination().equals(flight.getDestination())){
					if(!result.contains(flight)){
						result.add(flight);	
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		searchFlights.setResult(result);
	}
}
