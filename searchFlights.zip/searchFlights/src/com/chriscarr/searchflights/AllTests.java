package com.chriscarr.searchflights;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for com.chriscarr.searchflights");
		//$JUnit-BEGIN$
		suite.addTestSuite(FileLoaderTest.class);
		suite.addTestSuite(CommandLineTest.class);
		suite.addTestSuite(FlightTest.class);
		suite.addTestSuite(SearchFlightsTest.class);
		//$JUnit-END$
		return suite;
	}

}
