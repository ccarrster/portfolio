package com.chriscarr.searchflights;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

public class FlightTest extends TestCase {
	public void testFlight(){
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy HH:mm:ss");
		String departureString = "31-08-1982 10:20:56";
		String arivalString = "31-08-1982 20:20:56";
		Date departure = null;
		Date arival = null;
		Date arival2 = null;
		try {
			departure = sdf.parse(departureString);
			arival = sdf.parse(arivalString);
			arival2 = sdf.parse(arivalString);
		} catch (ParseException e) {
			e.printStackTrace();
			fail();
		}
		
		Flight sut = new Flight("LAS", departure, "LAX", arival, 15100);
		assertEquals("LAS", sut.getOrigin());
		assertEquals(departure, sut.getDeparture());
		assertEquals("LAX", sut.getDestination());
		assertEquals(arival2, sut.getArival());
		assertEquals(15100, sut.getPrice());
		assertEquals("LAS --> LAX (8/31/1982 10:20:56 --> 8/31/1982 20:20:56) - $151.00", sut.toString());
	}
}
