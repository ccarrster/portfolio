package com.chriscarr.searchflights;

import junit.framework.TestCase;

public class CommandLineTest extends TestCase {
	
	public void testExampleParseCommandLine(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-o", "YYZ", "-d", "YYC"};
		try{
			Search search = sut.parseCommandLine(args);
			assertEquals("YYZ", search.getOrigin());
			assertEquals("YYC", search.getDestination());
		} catch(Exception e){
			e.printStackTrace();
			fail();
		}
	}
	
	public void testSearchLoadFiles(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-o", "YYZ", "-d", "YYC"};
		try{
			sut.parseCommandLine(args);
		} catch(Exception e){
			e.printStackTrace();
			fail();
		}
	}
	
	public void testInvalidCommandLineArgsBlank(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{};
		try{
			sut.parseCommandLine(args);
			fail();
		} catch(Exception e){
			//expected
		}
	}
	
	public void testInvalidCommandLineArgsNull(){
		SearchFlights sut = new SearchFlights();
		String[] args = null;
		try{
			sut.parseCommandLine(args);
			fail();
		} catch(Exception e){
			//expected
		}
	}
	
	public void testCommandLineArgsExtra(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-o", "YYZ", "-d", "YYC", "-q"};
		try{
			sut.parseCommandLine(args);
		} catch(Exception e){
			fail();
		}
	}
	
	public void testCommandLineArgsReversed(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-d", "YYZ", "-o", "YYC"};
		try{
			sut.parseCommandLine(args);
		} catch(Exception e){
			fail();
		}
	}
	
	public void testInvalidCommandLineArgsWrongArgsOrigin(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-q", "YYZ", "-d", "YYC"};
		try{
			sut.parseCommandLine(args);
			fail();
		} catch(Exception e){
			//expected
		}
	}
	
	public void testInvalidCommandLineArgsTooFew(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-q", "YYZ", "-d"};
		try{
			sut.parseCommandLine(args);
			fail();
		} catch(Exception e){
			//expected
		}
	}
	
	public void testInvalidCommandLineArgsWrongArgsDestination(){
		SearchFlights sut = new SearchFlights();
		String[] args = new String[]{"-o", "YYZ", "-q", "YYC"};
		try{
			sut.parseCommandLine(args);
			fail();
		} catch(Exception e){
			//expected
		}
	}
	
	public void testValidAirportCode(){
		SearchFlights sut = new SearchFlights();
		assertTrue(sut.isValidAirportCode("YYZ"));
		assertFalse(sut.isValidAirportCode(""));
		assertFalse(sut.isValidAirportCode(null));
		assertFalse(sut.isValidAirportCode("YY"));
		assertFalse(sut.isValidAirportCode("YYCZ"));
		assertFalse(sut.isValidAirportCode("YY3"));
	}
}
