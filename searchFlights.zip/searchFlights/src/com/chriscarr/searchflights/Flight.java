package com.chriscarr.searchflights;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Flight implements Comparable<Flight>{

	String origin;
	Date departure;
	String destination;
	Date arival;
	int price;
	
	SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy HH:mm:ss");
	DecimalFormat df = new DecimalFormat("'$'0.00");
	
	public Flight(String origin, Date departure, String destination, Date arival, int price) {
		this.origin = origin;
		this.departure = departure;
		this.destination = destination;
		this.arival = arival;
		this.price = price;
	}

	public String getOrigin() {
		return origin;
	}

	public String getDestination() {
		return destination;
	}

	public Date getDeparture() {
		return departure;
	}

	public Date getArival() {
		return arival;
	}

	public int getPrice() {
		return price;
	}

	public String toString(){
		return origin + " --> " + destination + " (" + sdf.format(departure) + " --> " + sdf.format(arival) + ") - " + df.format(price/100);
	}
	
	public boolean equals(Object other){
		Flight otherFlight = (Flight)other;
		if(otherFlight.origin.equals(origin) && 	
		otherFlight.departure.equals(departure) &&
		otherFlight.destination.equals(destination) &&
		otherFlight.arival.equals(arival) &&
		otherFlight.price == price){
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int compareTo(Flight other) {
		if(price < other.price){
			return -1;
		} else if(price > other.price){
			return 1;
		}
		if(departure.before(other.departure)){
			return -1;
		} else if(departure.after(other.departure)){
			return 1;
		}
		return 0;
	}
}
