package com.chriscarr.searchflights;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class SearchFlights {

	public List<Flight> sortedFlights = new ArrayList<Flight>();
	
	public synchronized void setResult(List<Flight> flights){
		for(int j = 0; j < flights.size(); j++){
			Flight flight = flights.get(j);
			if(!sortedFlights.contains(flight)){
				sortedFlights.add(flight);	
			}
		}
	}
	
	public static void main(String[] args) {
		SearchFlights searchFlights = new SearchFlights();
		List<Flight> flights = searchFlights.performSearch(args);
		for(Flight flight : flights){
			System.out.println(flight);
		}
	}
	
	public List<Flight> performSearch(String[] args){
		try {
			Search search = parseCommandLine(args);
			List<String> files = new ArrayList<String>();
			files.add("Provider1.txt");
			files.add("Provider2.txt");
			files.add("Provider3.txt");
			
		    List<Thread> threads = new ArrayList<Thread>();
		    for (String filePath : files){ 
		      Runnable task = new FileRunnable(search, filePath, this);
		      Thread worker = new Thread(task);
		      worker.start();
		      threads.add(worker);
		    }
		    int running = 0;
		    do {
		      running = 0;
		      for (Thread thread : threads) {
		        if (thread.isAlive()) {
		          running++;
		        }
		      }
		    } while (running > 0);
		    Collections.sort(sortedFlights);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sortedFlights;
	}
	
	public Search parseCommandLine(String[] args) throws Exception {
		HashMap<String, String> argMap = new HashMap<String, String>();
		for(int i = 0; i + 1 < args.length; i += 2){
			argMap.put(args[i], args[i + 1]);
		}
		
		String origin = argMap.get("-o");
		String destination = argMap.get("-d");
		Search result = null;
		if(isValidAirportCode(origin) && isValidAirportCode(destination)){
			result = new Search(origin, destination);
		} else {
			throw new Exception("Usage: -o YYZ -d YYC");
		}
		return result;
	}

	public boolean isValidAirportCode(String code) {
		if(code == null){
			return false;
		}
		Pattern pattern = Pattern.compile("^[A-Z]{3}$");
		Matcher matcher = pattern.matcher(code);
		return matcher.find();
	}
}
