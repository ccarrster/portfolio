package com.chriscarr.searchflights;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

public class SearchFlightsTest extends TestCase {
	public void testSetResult(){
		SearchFlights sut = new SearchFlights();
		try{
			sut.setResult(null);
			fail();
		} catch(Exception e){
			//Expected
		}
		List<Flight> emptyList = new ArrayList<Flight>();
		sut.setResult(emptyList);
		assertTrue(sut.sortedFlights.isEmpty());
	}
	
	public void testFlights(){
		SearchFlights sut = new SearchFlights();
		List<Flight> flights = new ArrayList<Flight>();
		Flight flight = new Flight("YYZ", new Date(), "YYC", new Date(), 12500);
		flights.add(flight);
		sut.setResult(flights);
		assertEquals(1, sut.sortedFlights.size());
		List<Flight> flights2 = new ArrayList<Flight>();
		flights2.add(flight);
		sut.setResult(flights2);
		assertEquals(1, sut.sortedFlights.size());
		List<Flight> flights3 = new ArrayList<Flight>();
		Flight flight2 = new Flight("YYK", new Date(), "YYC", new Date(), 12500);
		flights3.add(flight2);
		sut.setResult(flights3);
		assertEquals(2, sut.sortedFlights.size());
	}
	
	public void testPerformSearch(){
		SearchFlights sut = new SearchFlights();
		List<Flight> flights = sut.performSearch(new String[]{"-o", "YYZ", "-d", "YYC"});
		assertEquals(3, flights.size());
	}
}
