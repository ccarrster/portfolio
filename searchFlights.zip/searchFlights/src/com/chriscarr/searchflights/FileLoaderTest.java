package com.chriscarr.searchflights;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

public class FileLoaderTest extends TestCase {
	public void testLoadFile1(){
		FlightFileLoader sut = new FlightFileLoader();
		List<Flight> flights;
		try {
			flights = sut.loadFile("Provider1.txt");
			assertEquals(8, flights.size());
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy HH:mm:ss");
			String departureString0 = "23-06-2014 13:30:00";
			String arivalString0 = "23-06-2014 14:40:00";
			String departureString1 = "15-06-2014 6:45:00";
			String arivalString1 = "15-06-2014 8:54:00";
			Date departure0 = null;
			Date arival0 = null;
			Date departure1 = null;
			Date arival1 = null;
			try {
				departure0 = sdf.parse(departureString0);
				arival0 = sdf.parse(arivalString0);
				departure1 = sdf.parse(departureString1);
				arival1 = sdf.parse(arivalString1);
			} catch (ParseException e) {
				e.printStackTrace();
				fail();
			}
			Flight flight0 = flights.get(0);
			assertEquals("LAS", flight0.getOrigin());
			assertEquals("LAX", flight0.getDestination());
			assertEquals(departure0, flight0.getDeparture());
			assertEquals(arival0, flight0.getArival());
			assertEquals(15100, flight0.getPrice());
			Flight flight1 = flights.get(1);
			assertEquals("YYZ", flight1.getOrigin());
			assertEquals("YYC", flight1.getDestination());
			assertEquals(departure1, flight1.getDeparture());
			assertEquals(arival1, flight1.getArival());
			assertEquals(57800, flight1.getPrice());
		} catch (IOException e) {
			e.printStackTrace();
			fail();
		}
	}
	
	public void testLoadFile2(){
		FlightFileLoader sut = new FlightFileLoader();
		List<Flight> flights;
		try {
			flights = sut.loadFile("Provider2.txt");
			assertEquals(13, flights.size());
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy HH:mm:ss");
			String departureString0 = "21-06-2014 17:55:00";
			String arivalString0 = "21-06-2014 23:23:00";
			String departureString1 = "22-06-2014 9:45:00";
			String arivalString1 = "22-06-2014 21:20:00";
			Date departure0 = null;
			Date arival0 = null;
			Date departure1 = null;
			Date arival1 = null;
			try {
				departure0 = sdf.parse(departureString0);
				arival0 = sdf.parse(arivalString0);
				departure1 = sdf.parse(departureString1);
				arival1 = sdf.parse(arivalString1);
			} catch (ParseException e) {
				e.printStackTrace();
				fail();
			}
			Flight flight0 = flights.get(0);
			assertEquals("JFK", flight0.getOrigin());
			assertEquals("YEG", flight0.getDestination());
			assertEquals(departure0, flight0.getDeparture());
			assertEquals(arival0, flight0.getArival());
			assertEquals(58900, flight0.getPrice());
			Flight flight1 = flights.get(1);
			assertEquals("LAS", flight1.getOrigin());
			assertEquals("YYZ", flight1.getDestination());
			assertEquals(departure1, flight1.getDeparture());
			assertEquals(arival1, flight1.getArival());
			assertEquals(54900, flight1.getPrice());
		} catch (IOException e) {
			e.printStackTrace();
			fail();
		}
	}
	
	public void testLoadFile3(){
		FlightFileLoader sut = new FlightFileLoader();
		List<Flight> flights;
		try {
			flights = sut.loadFile("Provider3.txt");
			assertEquals(15, flights.size());
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy HH:mm:ss");
			String departureString0 = "29-06-2014 14:55:00";
			String arivalString0 = "29-06-2014 16:10:00";
			String departureString1 = "17-06-2014 14:55:00";
			String arivalString1 = "17-06-2014 17:10:00";
			Date departure0 = null;
			Date arival0 = null;
			Date departure1 = null;
			Date arival1 = null;
			try {
				departure0 = sdf.parse(departureString0);
				arival0 = sdf.parse(arivalString0);
				departure1 = sdf.parse(departureString1);
				arival1 = sdf.parse(arivalString1);
			} catch (ParseException e) {
				e.printStackTrace();
				fail();
			}
			Flight flight0 = flights.get(0);
			assertEquals("LAS", flight0.getOrigin());
			assertEquals("LAX", flight0.getDestination());
			assertEquals(departure0, flight0.getDeparture());
			assertEquals(arival0, flight0.getArival());
			assertEquals(20100, flight0.getPrice());
			Flight flight1 = flights.get(1);
			assertEquals("MIA", flight1.getOrigin());
			assertEquals("ORD", flight1.getDestination());
			assertEquals(departure1, flight1.getDeparture());
			assertEquals(arival1, flight1.getArival());
			assertEquals(54200, flight1.getPrice());
		} catch (IOException e) {
			e.printStackTrace();
			fail();
		}
	}
	
	public void testCleanPrice(){
		FlightFileLoader sut = new FlightFileLoader();
		assertEquals(115000, sut.cleanPrice("$1150.00"));
	}
}
