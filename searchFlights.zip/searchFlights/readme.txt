To run:
java -classpath searchFlights.jar com.chriscarr.searchflights.SearchFlights -o YYZ -d YYC