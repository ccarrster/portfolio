<html>
<head>
<title>Regular User Profile</title>
</head>
<body>

<?php

/*

create table rezauser (id INT NOT NULL AUTO_INCREMENT, salutation VARCHAR(500), firstname VARCHAR(500), lastname VARCHAR(500), username VARCHAR(500), password VARCHAR(500), birthyear VARCHAR(500), birthmonth VARCHAR(500), birthday VARCHAR(500), country VARCHAR(500), region VARCHAR(500), city VARCHAR(500), postal VARCHAR(500), address VARCHAR(500), phone VARCHAR(500), picture VARCHAR(500), PRIMARY KEY (id));

salutation, firstname, lastname, username, password, birthyear, birthmonth, birthday, country, region, city, postal, address, phone, picture

*/

$image_name = null;
if(isset($_FILES["picture"])){
if ((($_FILES["picture"]["type"] == "image/gif")
|| ($_FILES["picture"]["type"] == "image/jpeg")
|| ($_FILES["picture"]["type"] == "image/pjpeg"))
&& ($_FILES["picture"]["size"] < 200000))
  {
  if ($_FILES["picture"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["picture"]["error"] . "<br />";
    }
  else
    {
    if (file_exists("upload/" . $_FILES["picture"]["name"]))
      {
      //echo $_FILES["picture"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["picture"]["tmp_name"],
      "upload/" . $_FILES["picture"]["name"]);
      }
      $image_name = $_FILES["picture"]["name"];
    }
  }
else
{
	//echo "Invalid file";
}
}

$link = mysql_connect('localhost', 'username', 'password');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db('reza');
if(isset($_POST['actiontype'])){
	$action_type = $_POST['actiontype'];
	if($action_type == "insert"){
		if(isValidName('Salutation', $_POST['salutation']) && isValidName('First Name', $_POST['firstname'], 'First Name') && isValidName('Last Name', $_POST['lastname'], 'Last Name') && isValidName('User Name', $_POST['username'], 'User Name') && isValidName('Password', $_POST['password']) && isValidName('Birth Year', $_POST['birthyear'], 'Year') && isValidName('Birth Month', $_POST['birthmonth'], 'Month') && isValidName('Birth Day', $_POST['birthday'], 'Day') && isValidName('Country', $_POST['country'], 'Country') && isValidName('Region', $_POST['region'], 'Region') && isValidName('City', $_POST['city'], 'City') && isValidName('Postal/Zip', $_POST['postal'], 'Enter Text') && isValidName('Address', $_POST['address'], 'Enter Text') && isValidName('Phone', $_POST['phone'], 'Enter Text')){
			$sql = "insert into rezauser (salutation, firstname, lastname, username, password, birthyear, birthmonth, birthday, country, region, city, postal, address, phone, picture) value('".$_POST['salutation']."', '".$_POST['firstname']."', '".$_POST['lastname']."', '".$_POST['username']."', '".$_POST['password']."', '".$_POST['birthyear']."', '".$_POST['birthmonth']."', '".$_POST['birthday']."', '".$_POST['country']."', '".$_POST['region']."', '".$_POST['city']."', '".$_POST['postal']."', '".$_POST['address']."', '".$_POST['phone']."', '".$image_name."');";
			mysql_query($sql);
		} else {
			displayError();
		}
	} elseif($action_type == "update"){
		if(isValidName('Salutation', $_POST['salutation']) && isValidName('First Name', $_POST['firstname'], 'First Name') && isValidName('Last Name', $_POST['lastname'], 'Last Name') && isValidName('User Name', $_POST['username'], 'User Name') && isValidPasswordName('Password', $_POST['password']) && isValidName('Birth Year', $_POST['birthyear'], 'Year') && isValidName('Birth Month', $_POST['birthmonth'], 'Month') && isValidName('Birth Day', $_POST['birthday'], 'Day') && isValidName('Country', $_POST['country'], 'Country') && isValidName('Region', $_POST['region'], 'Region') && isValidName('City', $_POST['city'], 'City') && isValidName('Postal/Zip', $_POST['postal'], 'Enter Text') && isValidName('Address', $_POST['address'], 'Enter Text') && isValidName('Phone', $_POST['phone'], 'Enter Text') && isValid($_POST['fieldid'])){
			if(isset($image_name)){
				$picture = ", picture = '".$image_name."'";
			} else {
				$picture = "";
			}
			if($_POST['password'] != ''){
				$password = ", password = '".$_POST['password']."'";
			} else {
				$password = "";
			}
			$sql = "update rezauser set salutation = '".$_POST['salutation']."', firstname = '".$_POST['firstname']."', lastname = '".$_POST['lastname']."', username = '".$_POST['username']."'$password, birthyear = '".$_POST['birthyear']."', birthmonth = '".$_POST['birthmonth']."', birthday = '".$_POST['birthday']."', country = '".$_POST['country']."', region = '".$_POST['region']."', city = '".$_POST['city']."', postal = '".$_POST['postal']."', address = '".$_POST['address']."', phone = '".$_POST['phone']."'$picture where id = " . $_POST['fieldid'] . ";";
			mysql_query($sql);
		} else {
			displayError();
		}
	} elseif($action_type == "delete"){
		if(isValid($_POST['fieldid'])){
			$sql = "delete from rezauser where id = " . $_POST['fieldid'] . ";";
			mysql_query($sql);
		} else {
			displayError();
		}
	}
}

function isValid($field, $default = null){
	if($default != null && $field == $default){
		return false;
	}
	return preg_match("/^[a-zA-Z0-9 ]*$/", $field) && strlen($field) != 0 && strlen($field) <= 500;
}

function isValidPasswordName($fieldName, $field){
	if (preg_match("/^[a-zA-Z0-9 ]*$/", $field) && strlen($field) <= 500){
		return true;
	} else {
		echo $fieldName . " needs to be at least 1 character. Numbers, Letters and spaces only.";
		return false;
	}
}

function isValidName($fieldName, $field, $default = null){
	if($default != null && $field == $default){
		echo $fieldName . " can not have the default value. You must enter a value.";
		return false;
	}
	$result = preg_match("/^[a-zA-Z0-9 ]*$/", $field) && strlen($field) != 0 && strlen($field) <= 500;
	if($result == false){
		echo $fieldName . " has and invalid character.";
		return false;
	}
	$result = strlen($field) != 0;
	if($result == false){
		echo $fieldName . " needs to be at least 1 character.";
		return false;
	}
	$result = strlen($field) <= 500;
	if($result == false){
		echo $fieldName . " needs to be less than 500 characters.";
		return false;
	}
	return true;
}


function displayError(){
	echo "Letters, numbers and spaces only. 500 character max. At least one character. All fields are required.";
}

$result = mysql_query("select * from rezauser;");
if($result === false){
	echo mysql_error();
} else {
	while($row = mysql_fetch_array( $result )) {
		?>
		<form method="POST" enctype="multipart/form-data">
		<input type="hidden" name="actiontype" value="update">
		<input type="hidden" name="fieldid" value="<?php echo $row['id']; ?>">

		Salutation<select name="salutation"><option <?php if($row['salutation'] == "Mr"){echo ' selected="true"';} ?> value="Mr">Mr</option><option <?php if($row['salutation'] == "Ms"){echo ' selected="true"';} ?> value="Ms">Ms</option></select>
		First Name <input type="text" name="firstname" value="<?php echo $row['firstname']; ?>">
		Last Name <input type="text" name="lastname" value="<?php echo $row['lastname']; ?>">
		<br/>

		Birth Date <select name="birthyear"><option>Year</option><option <?php if($row['birthyear'] == "1980"){echo ' selected="true"';} ?> value="1980">1980</option><option <?php if($row['birthyear'] == "1981"){echo ' selected="true"';} ?> value="1981">1981</option></select>
		<select name="birthmonth"><option>Month</option><option <?php if($row['birthmonth'] == "January"){echo ' selected="true"';} ?> value="January">January</option><option <?php if($row['birthmonth'] == "February"){echo ' selected="true"';} ?> value="February">February</option></select>
		<select name="birthday"><option>Day</option><option <?php if($row['birthday'] == "13"){echo ' selected="true"';} ?> value="13">13</option><option <?php if($row['birthday'] == "14"){echo ' selected="true"';} ?> value="14">14</option></select>
		<br/>

		User Name <input type="text" name="username" value="<?php echo $row['username']; ?>">
		Password <input name="password" type="password">
		Picture <input type="file" name="picture" value="<?php echo $row['picture']; ?>">
		<?php
		if($row['picture'] != ""){
			echo '<img src="upload/' . $row['picture'] . '" height="50";>';
		}
		?>
		<br/>

		Phone <input type="text" name="phone" value="<?php echo $row['phone']; ?>">
		Area <select name="country"><option>Country</option><option <?php if($row['country'] == "Canada"){echo ' selected="true"';} ?> value="Canada">Canada</option><option <?php if($row['country'] == "Iran"){echo ' selected="true"';} ?> value="Iran">Iran</option></select>
		<select name="region"><option>Region</option><option <?php if($row['region'] == "Ontario"){echo ' selected="true"';} ?> value="Ontario">Ontario</option><option <?php if($row['region'] == "Azerbaijan"){echo ' selected="true"';} ?> value="Azerbaijan">Azerbaijan</option></select>
		<select name="city"><option>City</option><option <?php if($row['city'] == "Toronto"){echo ' selected="true"';} ?> value="Toronto">Toronto</option><option <?php if($row['city'] == "Baku"){echo ' selected="true"';} ?> value="Baku">Baku</option></select>
		Address <input type="text" name="address" value="<?php echo $row['address']; ?>">
		Postal/Zip <input type="text" name="postal" value="<?php echo $row['phone']; ?>">
		<br/>

		<input type="submit" value="UPDATE">
		</form>
		<?php
		echo '<form method="POST"><input type="hidden" name="fieldid" value="' . $row['id'] . '"><input type="hidden" name="actiontype" value="delete"><input type="submit" value="DELETE"></form><br/>';
	}
}
mysql_close($link);
?>
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="actiontype" value="insert">
Salutation<select name="salutation"><option value="Mr">Mr</option><option value="Ms">Ms</option></select>
First Name <input type="text" name="firstname" value="First Name">
Last Name <input type="text" name="lastname" value="Last Name">
<br/>

Birth Date <select name="birthyear"><option>Year</option><option value="1980">1980</option><option value="1981">1981</option></select>
<select name="birthmonth"><option>Month</option><option value="January">January</option><option value="February">February</option></select>
<select name="birthday"><option>Day</option><option value="13">13</option><option value="14">14</option></select>
<br/>

User Name <input type="text" name="username" value="User Name">
Password <input name="password" type="password">
Picture <input type="file" name="picture">
<br/>

Phone <input type="text" name="phone" value="Enter Text">
Area <select name="country"><option>Country</option><option value="Canada">Canada</option><option value="Iran">Iran</option></select>
<select name="region"><option>Region</option><option value="Ontario">Ontario</option><option value="Azerbaijan">Azerbaijan</option></select>
<select name="city"><option>City</option><option value="Toronto">Toronto</option><option value="Baku">Baku</option></select>
Address <input type="text" name="address" value="Enter Text">
Postal/Zip <input type="text" name="postal" value="Enter Text">
<br/>

<input type="submit" value="INSERT">
</form>
</body>
</html>