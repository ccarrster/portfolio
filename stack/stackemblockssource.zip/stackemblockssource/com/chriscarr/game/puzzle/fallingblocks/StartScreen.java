package com.chriscarr.game.puzzle.fallingblocks;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class StartScreen extends JFrame implements ActionListener, WindowListener, KeyListener, ScoreListener, NextPieceListener{
		
	private static int GAMEPLAY = 0;
	private static int MENUS = 1;
	private static int gameState = MENUS;	
	private static String title = "C�:'s Stack'em Blocks";
		
	
	private static int sideBoardWidth = 100;	
	
	private int gameWidth = 10;
	private int gameHeight = 20;
	private int blockSize = 30;
						
	//Default Game Options
	private static int DEFAULTLEFT = 37;
	private static int DEFAULTRIGHT = 39;
	private static int DEFAULTDOWN = 40;
	private static int DEFAULTROTATECOUNTERCLOCK = 90;
	private static int DEFAULTROTATECLOCK = 88;
	
	//Game options
	private static int left;
	private static int right;
	private static int down;
	private static int counterClock;
	private static int clock;
	
	
	
	//Main Screen
	JPanel mainPanel;
	JButton startButton;
	JButton exitButton;
	JButton optionsButton;
	JButton aboutButton;
	JButton instructionsButton;
	
	//Options Screen
	JPanel optionsPanel;
	JTextArea optionsText;
	JButton saveOptionsButton;
	JButton revertOptionsButton;
	JButton defaultOptionsButton;
	JButton backOptionsButton;
			
	//Instructions Screen
	JPanel instructionsPanel;
	JTextArea instructionsText;
	JButton backInstructionsButton;
	
	//Game Screen
	JPanel gamePanel;	
	GamePanel gameBoardPanel;
	JPanel sideBoardPanel;
	JButton quitButton;
	JLabel nextPieceLabel;
	JLabel scoreLabel;
	
	boolean keyListener = false;
	
	
	public StartScreen(){
		super();
		init();
		this.addWindowListener(this);		
	}
	
	public void init(){
		initGameOptions();
		
		//Main Screen
		mainPanel = new JPanel();
		mainPanel.setName(title);
		mainPanel.setPreferredSize(new Dimension(gameWidth * blockSize + sideBoardWidth, gameHeight * blockSize + sideBoardWidth));
		
		startButton = new JButton("Start");
		exitButton = new JButton("Exit");
		optionsButton = new JButton("Options");
		aboutButton = new JButton("About");
		instructionsButton = new JButton("Instructions");
		
		mainPanel.add(startButton);
		mainPanel.add(exitButton);
		//mainPanel.add(optionsButton);
		mainPanel.add(aboutButton);
		mainPanel.add(instructionsButton);

		startButton.setEnabled(true);
		exitButton.setEnabled(true);
		optionsButton.setEnabled(true);
		aboutButton.setEnabled(true);
		instructionsButton.setEnabled(true);
		
		startButton.addActionListener(this);
		exitButton.addActionListener(this);
		optionsButton.addActionListener(this);
		aboutButton.addActionListener(this);
		instructionsButton.addActionListener(this);
		
		//Options screen
		optionsPanel = new JPanel();
		optionsPanel.setName(title + " - Options");
		optionsPanel.setPreferredSize(new Dimension(gameWidth * blockSize + sideBoardWidth, gameHeight * blockSize + sideBoardWidth));
		
		optionsText = new JTextArea("Current Configuration:\n\n" + getConfig());
		saveOptionsButton = new JButton("Save");
		revertOptionsButton = new JButton("Revert");
		defaultOptionsButton = new JButton("Default");
		backOptionsButton = new JButton("Back");
		
		optionsPanel.add(optionsText);
		optionsPanel.add(saveOptionsButton);
		optionsPanel.add(revertOptionsButton);
		optionsPanel.add(defaultOptionsButton);
		optionsPanel.add(backOptionsButton);
		
		optionsText.setEditable(false);
		
		saveOptionsButton.setEnabled(false);
		revertOptionsButton.setEnabled(false);
		defaultOptionsButton.setEnabled(true);
		backOptionsButton.setEnabled(true);
		
		saveOptionsButton.addActionListener(this);
		revertOptionsButton.addActionListener(this);
		defaultOptionsButton.addActionListener(this);
		backOptionsButton.addActionListener(this);
		
		//Instructions screen
		instructionsPanel = new JPanel();
		instructionsPanel.setName(title + " - Instructions");
		instructionsPanel.setPreferredSize(new Dimension(gameWidth * blockSize + sideBoardWidth, gameHeight * blockSize + sideBoardWidth));
		
		instructionsText = new JTextArea("Try to see how long you can last before\n the blocks stack off the top of the screen.\nStack the blocks in a horizontal line\n to make them vanish.\n\n" + getConfig());
		backInstructionsButton = new JButton("Back");
		
		instructionsPanel.add(instructionsText);
		instructionsPanel.add(backInstructionsButton);
		
		instructionsText.setEditable(false);
		
		backInstructionsButton.setEnabled(true);
		
		backInstructionsButton.addActionListener(this);
		
		//game screen
		gamePanel = new JPanel();		
		gamePanel.setName(title + " - Game");
		gamePanel.setPreferredSize(new Dimension(gameWidth * blockSize + sideBoardWidth, gameHeight * blockSize));
		gamePanel.setLayout(new BoxLayout(gamePanel, BoxLayout.X_AXIS));
		
		gameBoardPanel = new GamePanel(gameWidth, gameHeight, blockSize);		
		gameBoardPanel.setPreferredSize(new Dimension(gameWidth * blockSize, gameHeight * blockSize));
		gameBoardPanel.addScoreListener(this);
		gameBoardPanel.addNextPieceListener(this);
		
		sideBoardPanel = new JPanel();		
		sideBoardPanel.setPreferredSize(new Dimension(sideBoardWidth, gameHeight));
		sideBoardPanel.setBackground(Color.GREEN);		
		nextPieceLabel = new JLabel();
		scoreLabel = new JLabel();
		this.setScore(0);
		
		quitButton = new JButton("End Game");
		
		gamePanel.add(gameBoardPanel);
		gamePanel.add(sideBoardPanel);
		sideBoardPanel.add(quitButton);
		sideBoardPanel.add(nextPieceLabel);
		sideBoardPanel.add(scoreLabel);
				
		quitButton.setEnabled(true);
		
		quitButton.addActionListener(this);
		
		//Screen initialization
		this.showPanel(mainPanel, MENUS);
		this.setVisible(true);
	}
	
	public void setScore(int score){
		scoreLabel.setText("Lines: " + score);
	}
	
	public void setNextPiece(String piece){
		nextPieceLabel.setText("Next Piece: " + piece);
	}
	
	private void initGameOptions(){
		//TODO Load and save options from a configuration file
		setDefaultOptions();
	}
	
	private void setDefaultOptions(){
		left = DEFAULTLEFT;
		right = DEFAULTRIGHT;
		down = DEFAULTDOWN;
		counterClock = DEFAULTROTATECOUNTERCLOCK;
		clock = DEFAULTROTATECLOCK;
	}
	
	public static void main(String[] args) {
		new StartScreen();
	}

	//Button event handlers
	public void actionPerformed(ActionEvent event) {
		//Main Screen
		if(event.getSource().equals(startButton)){
			start();
		} else if(event.getSource().equals(exitButton)){
			exit();
		} else if(event.getSource().equals(optionsButton)){
			options();
		} else if(event.getSource().equals(aboutButton)){
			about();
		} else if(event.getSource().equals(instructionsButton)){
			instructions();
			//Options Screen
		} else if(event.getSource().equals(saveOptionsButton)){
			saveOptions();
		} else if(event.getSource().equals(revertOptionsButton)){
			revertOptions();
		} else if(event.getSource().equals(defaultOptionsButton)){
			defaultOptions();
		} else if(event.getSource().equals(backOptionsButton)){
			backOptions();
		} else if(event.getSource().equals(backInstructionsButton)){
			backInstructions();
		} else if(event.getSource().equals(quitButton)){
			quitGame();
		} else {
			//Do nothing
			System.out.println("Unhandled action from: " + event.getSource());
		}
	}
		
	
	
	
	//Main Screen
	private void start(){					
		showPanel(gamePanel, StartScreen.GAMEPLAY);
		if(!keyListener){
			gamePanel.addKeyListener(this);
			keyListener = true;
		}
		gamePanel.requestFocus();
		gameBoardPanel.initBoard();
		gameBoardPanel.setPaused(false);
		
	}	
	
	private void exit(){
		this.dispose();
		System.exit(0);
	}
	
	private void options(){
		showPanel(optionsPanel, MENUS);
	}
	
	private void about(){
		javax.swing.JOptionPane.showMessageDialog(null,
				title + "\n Created by Christopher Gordon Carr 2007\nccarrster@gmail.com\nhttp://www.stormloader.com/chriscarr", title + " - About",
				javax.swing.JOptionPane.INFORMATION_MESSAGE);
	}
	
	private void instructions(){
		showPanel(instructionsPanel, this.MENUS);
	}

	//Options Screen
	
	private void saveOptions(){
		//TODO implement saveOptions
	}
	
	private void revertOptions(){
		//TODO implement revertOptions
	}
	
	private void defaultOptions(){
		setDefaultOptions();
		optionsText.setText(getOptionsText());
	}
	
	private void backOptions(){
		showPanel(mainPanel, this.MENUS);
	}
	
	//Instructions Screen
	private void backInstructions(){
		showPanel(mainPanel, this.MENUS);
	}
	
	//Instructions Screen
	private void quitGame(){
		gameBoardPanel.setPaused(true);		
		showPanel(mainPanel, this.MENUS);
	}
	
	//Utility methods
	private void showPanel(JPanel panel, int gameState){
		if(gameState != -1){
			StartScreen.gameState = gameState;
		}
		this.getContentPane().removeAll();
		this.getContentPane().add(panel);
		this.setTitle(panel.getName());
		this.pack();
		this.repaint();
	}
	
	private String getConfig(){
		return new String(KeyEvent.getKeyText(left) + ": move left\n" + KeyEvent.getKeyText(right) + ": move right\n" + KeyEvent.getKeyText(down) + ": Move down fast\n" + KeyEvent.getKeyText(counterClock) + ": rotate counter clockwise\n" + KeyEvent.getKeyText(clock) + ": rotate clockwise");
	}
	
	private String getOptionsText(){
		return "Current Configuration:\n\n"+ getConfig();
	}
	
	//Window event handlers
	public void windowActivated(WindowEvent arg0) {}
	public void windowClosed(WindowEvent arg0) {}
	public void windowDeactivated(WindowEvent arg0) {}
	public void windowDeiconified(WindowEvent arg0) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
	public void windowClosing(WindowEvent arg0) {
		exit();
	}
	
	public void dropRows(){
		//TODO implement dropRows
	}
	
	public void keyPressed(KeyEvent event) {	
		System.out.println(KeyEvent.getKeyText(event.getKeyCode()));
		if(event.getKeyCode() == GamePanel.getLeft()){
			gameBoardPanel.addMove(new MoveShapeEvent(MoveShapeEvent.LEFT));
		} else if(event.getKeyCode() == GamePanel.getRight()){
			gameBoardPanel.addMove(new MoveShapeEvent(MoveShapeEvent.RIGHT));
		} else if(event.getKeyCode() == GamePanel.getDown()){
			gameBoardPanel.addMove(new MoveShapeEvent(MoveShapeEvent.DOWN));
		} else if(event.getKeyCode() == GamePanel.getClock()){
			gameBoardPanel.addMove(new MoveShapeEvent(MoveShapeEvent.CLOCK));
		} else if(event.getKeyCode() == GamePanel.getCounterClock()){
			gameBoardPanel.addMove(new MoveShapeEvent(MoveShapeEvent.COUNTERCLOCK));
		}				
	}	
	
	public void keyReleased(KeyEvent arg0) {
		
	}

	public void keyTyped(KeyEvent arg0) {
		
	}
}
