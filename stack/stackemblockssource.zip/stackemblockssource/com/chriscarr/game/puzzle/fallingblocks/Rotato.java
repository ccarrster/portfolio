package com.chriscarr.game.puzzle.fallingblocks;

import java.awt.Color;

public class Rotato {
	private int row;
	private int column;
	private Color color;
	
	
	public Rotato(int row, int column, Color color){
		this.row = row;
		this.column = column;
		this.color = color;
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
}
