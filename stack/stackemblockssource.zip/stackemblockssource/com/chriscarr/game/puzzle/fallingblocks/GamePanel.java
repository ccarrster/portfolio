package com.chriscarr.game.puzzle.fallingblocks;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JPanel;


public class GamePanel extends JPanel{
	
	private int gameWidth;
	private int gameHeight;
	private int blockSize;
	
	private Block[][] blocks;
	
	boolean playing = true;
	int sleepTime = 50;
	int gravityEffect = 10;	
	GamePanel thisPanel;
	boolean paused;
	int nextPiece = -1;
	int completedLines = 0;
	
	private static Queue<MoveShapeEvent> moveQueue;
	private ArrayList scoreListeners;
	private ArrayList nextPieceListeners;
	
	//Default Game Options
	private static int DEFAULTLEFT = 37;
	private static int DEFAULTRIGHT = 39;
	private static int DEFAULTDOWN = 40;
	private static int DEFAULTROTATECOUNTERCLOCK = 90;
	private static int DEFAULTROTATECLOCK = 88;
	
	//Game options
	private static int left;
	private static int right;
	private static int down;
	private static int counterClock;
	private static int clock;
	
	public GamePanel(int gameWidth, int gameHeight, int blockSize){		
		thisPanel = this;
		this.gameWidth = gameWidth;
		this.gameHeight = gameHeight;
		this.blockSize = blockSize;
		paused = true;
		moveQueue = new LinkedList();
		scoreListeners = new ArrayList();
		nextPieceListeners = new ArrayList();
		setDefaultOptions();
		
		this.setPreferredSize(new Dimension((gameWidth * blockSize), (gameHeight * blockSize)));
		
		initBoard();
		
		new Thread(){			
			
			public void run(){
				int gravityCounter = 0;
				while(playing){
					while(paused){
						try {						
							Thread.sleep(sleepTime);
						} catch (InterruptedException e) {
							//Do nothing
						}
					}
					while(moveQueue.size() > 0){
						MoveShapeEvent mse = (MoveShapeEvent)moveQueue.remove();
						//We don't care about collisions attempting to move via the users commands
						mse.doMove(blocks);						
					}
					gravityCounter++;
					if(gravityCounter == gravityEffect){
						gravityCounter = 0;
						MoveShapeEvent gravity = new MoveShapeEvent(MoveShapeEvent.DOWN);
						boolean moveSuccess = gravity.doMove(blocks);
						if(!moveSuccess){
							blocks = gravity.getBackupArray();
							handleCollision();
							
							int[] numberInRows = new int[thisPanel.gameHeight];
							for(int row = thisPanel.gameHeight - 1; row >= 0; --row){						
								for(int column = 0; column < thisPanel.gameWidth; column++){							
									if(!blocks[row][column].getColor().equals(Block.defaultColor)){
										numberInRows[row]++;
									}
								}
							}
							for(int i = 0; i < numberInRows.length; i++){
								if(numberInRows[i] == thisPanel.gameWidth){
									removeRow(i);
									completedLines++;
									gravityEffect = 11 - (completedLines / 10);
									if(gravityEffect < 2){
										gravityEffect = 2;
									}
									Iterator iter = scoreListeners.iterator();
									while(iter.hasNext()){
										((ScoreListener)iter.next()).setScore(completedLines);
									}
								}
							}															
												
							newShape();
						}
					}
										
					
					
					
					try {
						repaint();
						Thread.sleep(sleepTime);
					} catch (InterruptedException e) {
						//Do nothing
					}
				}
			}
		}.start();
	}
	
	public void initBoard(){
		gravityEffect = 10;	
		nextPiece = -1;
		completedLines = 0;
		Iterator iter = scoreListeners.iterator();
		while(iter.hasNext()){
			((ScoreListener)iter.next()).setScore(completedLines);
		}
		
		blocks = new Block[gameHeight][gameWidth];
		
		for(int row = 0; row < gameHeight; row++){
			blocks[row] = new Block[gameWidth];
			for(int column = 0; column < gameWidth; column++){
				blocks[row][column] = new Block();
			}
		}	
		newShape();
	}
	
	public void addMove(MoveShapeEvent move){
		moveQueue.add(move);
	}
	
	public void handleCollision(){
		for(int row = thisPanel.gameHeight - 1; row >= 0; --row){			
			for(int column = 0; column < thisPanel.gameWidth; column++){							
				blocks[row][column].setFalling(false);
				blocks[row][column].setCenterPiece(false);
			}
		}						
	}
	
	public void removeRow(int rowToRemove){
		//Remove the completed row
		for(int column = 0; column < blocks[0].length; column++){											
			blocks[rowToRemove][column].setColor(Block.defaultColor);
		}
		
		//Move all the rows down one
		for(int row = rowToRemove; row > 0; --row){						
			for(int column = 0; column < blocks[0].length; column++){											
				blocks[row][column].setColor(blocks[row - 1][column].getColor());
			}
		}
		
		//Remove 0th row
		for(int column = 0; column < blocks[0].length; column++){											
			blocks[0][column].setColor(Block.defaultColor);
		}
	}
	
	private String intToPieceLetter(int i){
		if(i == 0){
			return "I";
		}
		if(i == 1){
			return "T";
		}
		if(i == 2){
			return "L";
		}
		if(i == 3){
			return "J";
		}
		if(i == 4){
			return "O";
		}
		if(i == 5){
			return "Z";
		}
		if(i == 6){
			return "S";
		}
		return "";
	}
	
	public void newShape(){
		int startRow = 0;
		if(blocks[0][4].getColor().equals(Block.defaultColor)){
			if(nextPiece == -1){
				nextPiece = (int)(Math.random() * 7);
			}
			int shape = nextPiece;
			nextPiece = (int)(Math.random() * 7);
			Iterator iter = nextPieceListeners.iterator();
			while(iter.hasNext()){
				((NextPieceListener)iter.next()).setNextPiece(intToPieceLetter(nextPiece));
			}
			if(shape == 0){
			//I
			blocks[startRow + 0][3].setColor(Color.red);
			blocks[startRow + 0][3].setFalling(true);			
			blocks[startRow + 0][4].setColor(Color.red);
			blocks[startRow + 0][4].setFalling(true);			
			blocks[startRow + 0][5].setColor(Color.red);
			blocks[startRow + 0][5].setFalling(true);			
			blocks[startRow + 0][5].setCenterPiece(true);
			blocks[startRow + 0][6].setColor(Color.red);
			blocks[startRow + 0][6].setFalling(true);
			
			}else if (shape == 1){
			//T
			blocks[startRow + 0][4].setColor(Color.blue);
			blocks[startRow + 0][4].setFalling(true);
			blocks[startRow + 0][5].setColor(Color.blue);
			blocks[startRow + 0][5].setFalling(true);
			blocks[startRow + 0][5].setCenterPiece(true);
			blocks[startRow + 0][6].setColor(Color.blue);
			blocks[startRow + 0][6].setFalling(true);
			blocks[startRow + 1][5].setColor(Color.blue);
			blocks[startRow + 1][5].setFalling(true);
			}else if (shape == 2){
			//L
			blocks[startRow + 1][3].setColor(Color.green);
			blocks[startRow + 1][3].setFalling(true);
			blocks[startRow + 1][4].setColor(Color.green);
			blocks[startRow + 1][4].setFalling(true);
			blocks[startRow + 1][4].setCenterPiece(true);
			blocks[startRow + 1][5].setColor(Color.green);
			blocks[startRow + 1][5].setFalling(true);			
			blocks[startRow + 0][5].setColor(Color.green);
			blocks[startRow + 0][5].setFalling(true);
			}else if (shape == 3){
			//J
			blocks[startRow + 0][3].setColor(Color.cyan);
			blocks[startRow + 0][3].setFalling(true);
			blocks[startRow + 0][4].setColor(Color.cyan);
			blocks[startRow + 0][4].setFalling(true);
			blocks[startRow + 0][4].setCenterPiece(true);
			blocks[startRow + 0][5].setColor(Color.cyan);
			blocks[startRow + 0][5].setFalling(true);
			blocks[startRow + 1][5].setColor(Color.cyan);
			blocks[startRow + 1][5].setFalling(true);
			}else if (shape == 4){
			//O
			blocks[startRow + 0][4].setColor(Color.yellow);
			blocks[startRow + 0][4].setFalling(true);
			blocks[startRow + 0][5].setColor(Color.yellow);
			blocks[startRow + 0][5].setFalling(true);
			blocks[startRow + 1][4].setColor(Color.yellow);
			blocks[startRow + 1][4].setFalling(true);
			blocks[startRow + 1][4].setCenterPiece(true);
			blocks[startRow + 1][5].setColor(Color.yellow);
			blocks[startRow + 1][5].setFalling(true);
			}else if (shape == 5){
			//Z
			blocks[startRow + 0][3].setColor(Color.gray);
			blocks[startRow + 0][3].setFalling(true);
			blocks[startRow + 0][4].setColor(Color.gray);
			blocks[startRow + 0][4].setFalling(true);
			blocks[startRow + 1][4].setColor(Color.gray);
			blocks[startRow + 1][4].setFalling(true);
			blocks[startRow + 1][4].setCenterPiece(true);
			blocks[startRow + 1][5].setColor(Color.gray);
			blocks[startRow + 1][5].setFalling(true);
			}else if (shape == 6){
			//S
			blocks[startRow + 0][5].setColor(Color.magenta);
			blocks[startRow + 0][5].setFalling(true);
			blocks[startRow + 0][4].setColor(Color.magenta);
			blocks[startRow + 0][4].setFalling(true);
			blocks[startRow + 1][4].setColor(Color.magenta);
			blocks[startRow + 1][4].setFalling(true);
			blocks[startRow + 1][4].setCenterPiece(true);
			blocks[startRow + 1][3].setColor(Color.magenta);
			blocks[startRow + 1][3].setFalling(true);
			}
			
		} else {
			System.out.println("Game over");
		}
		
	}
	
	public void paint(Graphics g){
		super.paint(g);
		for(int row = 0; row < gameHeight; row++){			
			for(int column = 0; column < gameWidth; column++){
				Block block = blocks[row][column];
				if(block.getColor().equals(Block.defaultColor)){
					
				} else {
					g.setColor(Color.black);
					g.drawRect(column * blockSize, row * blockSize, blockSize - 1, blockSize - 1);
				}
				Color color = block.getColor();				
				g.setColor(color);
				g.fillRect((column * blockSize) + 1, (row * blockSize) + 1, blockSize - 2, blockSize - 2);
			}
		}
	}
	
	
	
	private void setDefaultOptions(){
		left = DEFAULTLEFT;
		right = DEFAULTRIGHT;
		down = DEFAULTDOWN;
		counterClock = DEFAULTROTATECOUNTERCLOCK;
		clock = DEFAULTROTATECLOCK;
	}

	public static int getLeft() {
		return left;
	}

	public static void setLeft(int left) {
		GamePanel.left = left;
	}

	public static int getRight() {
		return right;
	}

	public static void setRight(int right) {
		GamePanel.right = right;
	}

	public static int getDown() {
		return down;
	}

	public static void setDown(int down) {
		GamePanel.down = down;
	}

	public static int getCounterClock() {
		return counterClock;
	}

	public static void setCounterClock(int counterClock) {
		GamePanel.counterClock = counterClock;
	}

	public static int getClock() {
		return clock;
	}

	public static void setClock(int clock) {
		GamePanel.clock = clock;
	}

	public boolean isPaused() {
		return paused;
	}

	public void setPaused(boolean paused) {
		this.paused = paused;
	}
	
	public void addScoreListener(ScoreListener listener){
		scoreListeners.add(listener);
	}
	
	public void addNextPieceListener(NextPieceListener listener){
		nextPieceListeners.add(listener);
	}
}
