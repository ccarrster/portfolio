package com.chriscarr.game.puzzle.fallingblocks;

import java.util.ArrayList;

public class Shape {
	private ArrayList<Block> blocks;

	public ArrayList<Block> getBlocks() {
		return blocks;
	}

	public void setBlocks(ArrayList<Block> blocks) {
		this.blocks = blocks;
	}		
}
