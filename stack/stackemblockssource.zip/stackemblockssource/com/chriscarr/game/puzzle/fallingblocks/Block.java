package com.chriscarr.game.puzzle.fallingblocks;

import java.awt.Color;

public class Block {	
	private Color color;
	private boolean falling;
	private boolean moved;
	private boolean centerPiece;
	public static Color defaultColor = Color.white;
	
	public Block(){
		color = defaultColor;
		falling = false;
		moved = false;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public boolean isFalling() {
		return falling;
	}
	public void setFalling(boolean falling) {
		this.falling = falling;
	}
	public boolean isMoved() {
		return moved;
	}
	public void setMoved(boolean moved) {
		this.moved = moved;
	}		
	
	public Block clone(){
		Block newBlock = new Block();
		newBlock.falling = falling;
		newBlock.moved = moved;
		newBlock.color = color;
		return newBlock;
	}
	public boolean isCenterPiece() {
		return centerPiece;
	}
	public void setCenterPiece(boolean centerPiece) {
		this.centerPiece = centerPiece;
	}	
}
