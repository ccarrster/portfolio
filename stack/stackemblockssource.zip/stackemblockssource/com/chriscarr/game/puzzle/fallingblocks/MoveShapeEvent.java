package com.chriscarr.game.puzzle.fallingblocks;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;

public class MoveShapeEvent {	
	private int direction;	
	
	public static final int LEFT = 0;
	public static final int RIGHT = 1;
	public static final int DOWN = 2;
	public static final int COUNTERCLOCK = 3;
	public static final int CLOCK = 4;
	
	public MoveShapeEvent(int direction){
		this.direction = direction;
	}		
	
	//Sss-Wap!
	private void swap(Block block1, Block block2){
		Color tempColor = block2.getColor();
		boolean falling = block2.isFalling();
		boolean moved = block2.isMoved();
		boolean centerPiece = block2.isCenterPiece();
		
		block2.setColor(block1.getColor());
		block2.setFalling(block1.isFalling());
		block2.setMoved(true);
		block2.setCenterPiece(block1.isCenterPiece());
		
		
		block1.setColor(tempColor);
		block1.setFalling(falling);
		block1.setMoved(moved);
		block1.setCenterPiece(centerPiece);
	}
	
	
	Block[][] backupArray;
	
	//Return true on success and false on collision or failure to move
	public boolean doMove(Block[][] blocks){
		backupArray = new Block[blocks.length][blocks[0].length];
		for(int row = 0; row < backupArray.length; row++){
			backupArray[row] = new Block[blocks[0].length];
			for(int column = 0; column < blocks[0].length; column++){
				backupArray[row][column] = (Block)blocks[row][column].clone();
			}
		}
		
		for(int row = 0; row < blocks.length; row++){
			for(int column = 0; column < blocks[0].length; column++){
				blocks[row][column].setMoved(false);
			}
		}
		
		if(direction == LEFT){
			System.out.println("Trying to move left");
			//Check to see if it is ok to move the blocks
			boolean noCollisions = true;
			for(int row = 0; row < blocks.length; row++){
				for(int column = 0; column < blocks[0].length; column++){
					Block currentBlock = blocks[row][column];
					if(currentBlock.isFalling()){						
						if(noCollisions){						
							if(column == 0){
								//Hit bottom
								noCollisions = false;
								System.out.println("Hit side");
							} else {
								Block nextBlock = blocks[row][column - 1];								
								if(!nextBlock.getColor().equals(Block.defaultColor) && !nextBlock.isFalling()){
									//Hit another block
									noCollisions = false;
									System.out.println("Hit another block");
								}
							}
						}
					}
				}
			}
			if(!noCollisions){
				System.out.println("Collision");
				return false;
			}
						
			for(int row = 0; row < blocks.length; row++){				
				for(int column = 1; column < blocks[0].length; column++){					
					Block currentBlock = blocks[row][column];
					Block nextBlock = blocks[row][column - 1];
					if(currentBlock.isFalling() && !currentBlock.isMoved()){						
						swap(currentBlock, nextBlock);
					}
				}
			}
			return true;
		}
		if(direction == RIGHT){
			System.out.println("Trying to move right");
			//Check to see if it is ok to move the blocks
			boolean noCollisions = true;
			for(int row = 0; row < blocks.length; row++){
				for(int column = 0; column < blocks[0].length; column++){
					Block currentBlock = blocks[row][column];
					if(currentBlock.isFalling()){						
						if(noCollisions){						
							if(column == blocks[0].length - 1){
								//Hit bottom
								noCollisions = false;
								System.out.println("Hit side");
							} else {
								Block nextBlock = blocks[row][column + 1];								
								if(!nextBlock.getColor().equals(Block.defaultColor) && !nextBlock.isFalling()){
									//Hit another block
									noCollisions = false;
									System.out.println("Hit another block");
								}
							}
						}
					}
				}
			}
			if(!noCollisions){
				System.out.println("Collision");
				return false;
			}
						
			for(int row = 0; row < blocks.length; row++){				
				for(int column = blocks[0].length - 2; column >= 0; column--){					
					Block currentBlock = blocks[row][column];
					Block nextBlock = blocks[row][column + 1];
					if(currentBlock.isFalling() && !currentBlock.isMoved()){						
						swap(currentBlock, nextBlock);
					}
				}
			}
			return true;
		}
		if(direction == DOWN){
			//Check to see if it is ok to move the blocks
			boolean noCollisions = true;
			for(int row = blocks.length - 1; row >= 0 ; row--){
				for(int column = 0; column < blocks[0].length; column++){
					Block currentBlock = blocks[row][column];
					if(currentBlock.isFalling()){
						if(noCollisions){						
							if(row == blocks.length - 1){
								//Hit bottom
								noCollisions = false;
								System.out.println("Hit bottom");
							} else {
								Block nextBlock = blocks[row + 1][column];							
								if(!nextBlock.getColor().equals(Block.defaultColor) && !nextBlock.isFalling()){
									//Hit another block
									noCollisions = false;
									System.out.println("Hit another block");
								}
							}
						}
					}
				}
			}
			if(!noCollisions){
				return false;
			}
			
			for(int row = blocks.length - 2; row >= 0; row--){
				for(int column = 0; column < blocks[0].length; column++){
					Block currentBlock = blocks[row][column];
					Block nextBlock = blocks[row + 1][column];
					if(currentBlock.isFalling() && !currentBlock.isMoved()){
						swap(currentBlock, nextBlock);
					}
				}
			}
			return true;
			
		}
		if(direction == CLOCK || direction == COUNTERCLOCK){
			int xVar = 0;
			int yVar = 0;
			if(direction == CLOCK){
				xVar = -1;
				yVar = +1;
			} else if(direction == COUNTERCLOCK){				
				xVar = +1;
				yVar = -1;			
			}
			System.out.println("Trying to rotate counter clockwise");
			//TODO rotate counter clock
			ArrayList blocksToRotate = new ArrayList();
			for(int row = blocks.length - 1; row >= 0 ; row--){
				for(int column = 0; column < blocks[0].length; column++){
					Block currentBlock = blocks[row][column];
					if(currentBlock.isFalling() && !currentBlock.isCenterPiece()){						
						blocksToRotate.add(new Rotato(row, column, currentBlock.getColor()));
					}
				}
			}
			for(int row = blocks.length - 1; row >= 0 ; row--){
				for(int column = 0; column < blocks[0].length; column++){
					Block currentBlock = blocks[row][column];
					if(currentBlock.isCenterPiece()){
						System.out.println("Rotating Counter Clockwise Around: " + row + " " + column);
						while(blocksToRotate.size() > 0){
							Iterator iter;					
							//Check for valid rotate
							iter = blocksToRotate.iterator();
							while(iter.hasNext()){
								Rotato rotato = (Rotato)iter.next();
								int x = rotato.getRow() - row;
								int y = rotato.getColumn() - column;
								//Within the board?								
								if((row + y * yVar) < 0 || (column + x * xVar) < 0 || (row + y * yVar) >= blocks.length || (column + x * xVar) >= blocks[0].length ){
									System.out.println("Outside the board");
									return false;
								}
								//Collided with another block?
								System.out.println("Row:" + (row + y * yVar) + " Column:" + (column + x * xVar));
								Block newBlock = blocks[row + y * yVar][column + x * xVar];								
								if(!newBlock.getColor().equals(Block.defaultColor) && !newBlock.isFalling()){
									System.out.println("Collided with another block");
									return false;
								}
							}
							//Remove old blocks
							iter = blocksToRotate.iterator();
							while(iter.hasNext()){
								Rotato rotato = (Rotato)iter.next();		
								Block oldBlock = blocks[rotato.getRow()][rotato.getColumn()];
								oldBlock.setColor(Block.defaultColor);
								oldBlock.setFalling(false);																
							}
							//Add new blocks
							iter = blocksToRotate.iterator();
							while(iter.hasNext()){
								Rotato rotato = (Rotato)iter.next();
								int x = rotato.getRow() - row;
								int y = rotato.getColumn() - column;	
								Block newBlock = blocks[row + y * yVar][column + x * xVar];
								newBlock.setColor(rotato.getColor());
								newBlock.setFalling(true);
							}
							blocksToRotate.removeAll(blocksToRotate);
						}
						return true;
					}
				}
			}
			return false;		
		}
		if(direction == COUNTERCLOCK){
			System.out.println("Trying to rotate clockwise");
			//TODO rotate clock
			return false;
		}
		return false;
	}

	public Block[][] getBackupArray() {
		return backupArray;
	}

	public void setBackupArray(Block[][] backupArray) {
		this.backupArray = backupArray;
	}
	
	
}
