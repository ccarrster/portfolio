package com.chriscarr.game.puzzle.fallingblocks;

public interface NextPieceListener {
	public void setNextPiece(String piece);
}
