package com.chriscarr.game.puzzle.fallingblocks;

public interface ScoreListener {
	public void setScore(int score);
}
