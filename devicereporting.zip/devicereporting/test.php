<?php
require('exinda.php');
class StackTest extends PHPUnit_Framework_TestCase
{
    public function testDBConnection()
    {
    	$mysqli = connectToDb();
    	$this->assertTrue(isset($mysqli));
    }

    public function testPadFirmware(){
    	$this->assertEquals('1.x.x.x', padFirmware('1'));
    	$this->assertEquals('1.2.x.x', padFirmware('1.2'));
    	$this->assertEquals('1.2.3.x', padFirmware('1.2.3'));
    	$this->assertEquals('1.2.3.4', padFirmware('1.2.3.4'));
    }

    public function testCompareDeltas(){
    	$deltaA10 = array('delta'=>10.0);
    	$deltaB10 = array('delta'=>10.0);
    	$delta20 = array('delta'=>20.0);
    	$deltaM10 = array('delta'=>-10.0);
    	$delta100 = array('delta'=>100.0);
    	$delta0 = array('delta'=>0.0);
    	$this->assertEquals(0, compareDeltas($deltaA10, $deltaB10));
    	$this->assertEquals(1, compareDeltas($deltaA10, $delta20));
    	$this->assertEquals(-1, compareDeltas($delta20, $deltaA10));
    	$this->assertEquals(1, compareDeltas($delta0, $deltaM10));
    	$this->assertEquals(-1, compareDeltas($delta100, $delta20));
    }

    public function testGetCustomerNames(){
		$this->assertEquals(6, count(getCustomerNames()));
		$this->assertEquals('Gorilla Corp.', getCustomerNames()[0]);
    }

    public function testPopulateSummary(){
    	populateDailySummary();
    	$mysqli = connectToDb();
    	$res = $mysqli->query("
			SELECT customer_id, firmware, count, day from appliance_status_summary;
    	");
    	$this->assertEquals(12, $res->num_rows);
    }

    public function testDeltaReportSummary(){
		populateDailySummary();
		$mysqli = connectToDb();
		//Cookie Inc has no delta so it should not be in the list of top 5 changes
		$res = $mysqli->query("
			INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(5, '7.2.1.2160', 2, DATE_SUB(CURDATE(), INTERVAL 7 DAY));
		");
		$this->assertFalse(strpos(formatReport(), 'Cookie Inc.'));
    }

	public function testPositiveDelta(){
		populateDailySummary();
		$mysqli = connectToDb();
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(0, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(1, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(2, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(3, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(4, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(5, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$this->assertTrue(strpos(formatReport(), 'Cookie Inc.') !== false);
    }

	public function testNegativeDelta(){
		populateDailySummary();
		$mysqli = connectToDb();
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(0, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(1, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(2, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(3, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(4, '7.2.1.2160', 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$res = $mysqli->query("INSERT INTO appliance_status_summary (customer_id, firmware, count, day) VALUES(5, '7.2.1.2160', 5, DATE_SUB(CURDATE(), INTERVAL 7 DAY));");
		$this->assertTrue(strpos(formatReport(), 'Cookie Inc.') !== false);
	}

    function setUp(){
    	$mysqli = connectToDb();
		$mysqli->query("delete from customer;");
		$mysqli->query("delete from appliance_status;");
		$mysqli->query("delete from customer_appliances;");
		$mysqli->query("delete from appliance_status_summary;");

		$mysqli->query("insert into customer (id, name) values(0, 'Gorilla Corp.');");
		$mysqli->query("insert into customer (id, name) values(1, 'A Company');");
		$mysqli->query("insert into customer (id, name) values(2, 'Y Company');");
		$mysqli->query("insert into customer (id, name) values(3, 'Monkey Co.');");
		$mysqli->query("insert into customer (id, name) values(4, 'Beverage Inc.');");
		$mysqli->query("insert into customer (id, name) values(5, 'Cookie Inc.');");

		$mysqli->query("insert into appliance_status (serial_number, firmware) values('A000000000', '7.2.1.2160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('B000000000', '7.2.1.2163');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('C000000000', '7.2.2.2463');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('D000000000', '7.2.2.2463');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('E000000000', '7.2.2.2463');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('F000000000', '7.2.0.3160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('G000000000', '7.2.0.3160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('H000000000', '7.4.0.5160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('I000000000', '7.4.0.5160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('J000000000', '7.4.0.5160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('K000000000', '7.2.1.2160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('L000000000', '7.2.1.2160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('M000000000', '7.2.1.2160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('N000000000', '7.2.1.2160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('O000000000', '7.2.1.2160');");
		$mysqli->query("insert into appliance_status (serial_number, firmware) values('P000000000', '7.2.1.2160');");


		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(0, 'A000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(0, 'C000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(0, 'D000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(2, 'E000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(1, 'B000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(2, 'F000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(2, 'G000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(3, 'H000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(3, 'I000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(4, 'J000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(1, 'K000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(2, 'L000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(3, 'M000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(4, 'N000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(5, 'O000000000');");
		$mysqli->query("insert into customer_appliances (customer_id, serial_number) values(5, 'P000000000');");
    }

    function tearDown(){
    	$mysqli = connectToDb();
    	$mysqli->query("delete from customer;");
		$mysqli->query("delete from appliance_status;");
		$mysqli->query("delete from customer_appliances;");
		$mysqli->query("delete from appliance_status_summary;");
    }
}
?>