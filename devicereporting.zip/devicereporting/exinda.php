<?php
function connectToDb(){
	$mysqli = new mysqli("localhost", "username", "password", "database");
	if ($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}
	return $mysqli;
}

function populateDailySummary(){
	$mysqli = connectToDb();
	$summaryQuery = $mysqli->query("
		SELECT c.id, aps.firmware, count(c.id) as count
		FROM customer_appliances ca
		JOIN customer c
		ON ca.customer_id = c.id
		JOIN appliance_status aps
		ON ca.serial_number = aps.serial_number
		GROUP BY c.id, aps.firmware;
	");
	if (!$summaryQuery) {
	   die('Invalid query: ' . mysql_error());
	}
	$deleteQuery = $mysqli->query("
		DELETE FROM appliance_status_summary WHERE day = CURDATE();
	");
	if (!$deleteQuery) {
	   die('Invalid query: ' . mysql_error());
	}
	while ($row = $summaryQuery->fetch_assoc()) {
		$customerId = $row['id'];
		$firmware = $row['firmware'];
		$count = $row['count'];
		$insertSummary = $mysqli->query("
			INSERT INTO appliance_status_summary (day, customer_id, firmware, count) values(NOW(), $customerId, '$firmware', $count);
		");
		if (!$insertSummary) {
		   die('Invalid query: ' . mysql_error());
		}
	}
}

function isFullFirmware($firmware){
	return count(explode('.', $firmware)) == 4;
}

/*
Returns A total count of appliances for each customer
Returns A list of appliance counts keyed on partial firmware version numbers
Returns Customers appliance counts and deltas from 7 days ago for each full revision
*/
function generateReport(){
	$mysqli = connectToDb();
	$res = $mysqli->query("
		SELECT today.customer_id, today.firmware, today.count, today.count - coalesce(lastweek.count, 0) as delta
		FROM appliance_status_summary today
		LEFT JOIN appliance_status_summary lastweek ON today.customer_id = lastweek.customer_id AND today.firmware = lastweek.firmware AND lastweek.day = DATE_SUB(CURDATE(), INTERVAL 7 DAY)
		WHERE today.day = CURDATE();
	");
	if (!$res) {
	   die('Invalid query: ' . mysql_error());
	}
	$customerDeviceCount = array();
	$reportHash = array();
	while ($row = $res->fetch_assoc()) {
		$customerId = $row['customer_id'];
		$firmware = $row['firmware'];
		$count = (int)$row['count'];
		$delta = (int)$row['delta'];
		if(array_key_exists($customerId, $customerDeviceCount)){
			$customerDeviceCount[$customerId] += $count;
		} else {
			$customerDeviceCount[$customerId] = $count;
		}
		$firmwareVersions = explode('.', $firmware);
		$partialFirmwareVersion = '';
		foreach($firmwareVersions as $firmwareVersionPiece){
			if($partialFirmwareVersion != ''){
				$partialFirmwareVersion .= '.';
			}
			$partialFirmwareVersion .= $firmwareVersionPiece;
			if(array_key_exists($partialFirmwareVersion, $reportHash)){
				$reportHash[$partialFirmwareVersion]['currentCount'] += $count;
			} else {
				$reportHash[$partialFirmwareVersion] = array('currentCount'=>$count);
			}
			if(isFullFirmware($partialFirmwareVersion)){
				if(array_key_exists('customers', $reportHash[$partialFirmwareVersion])){
					$reportHash[$partialFirmwareVersion]['customers'][$customerId] = array('currentCount'=>$count, 'delta'=>$delta);
				} else {
					$reportHash[$partialFirmwareVersion]['customers'] = array();
					$reportHash[$partialFirmwareVersion]['customers'][$customerId] = array('currentCount'=>$count, 'delta'=>$delta);
				}
			}
		}
	}
	$result = array('report'=>$reportHash, 'deviceCount'=>$customerDeviceCount);
	return $result;
}

function getCustomerNames(){

	$mysqli = connectToDb();
	$res = $mysqli->query("
		SELECT id, name
		FROM customer;
	");
	if (!$res) {
	   die('Invalid query: ' . mysql_error());
	}
	$customers = array();
	while ($row = $res->fetch_assoc()) {
		$customers[$row['id']] = $row['name'];
	}
	return $customers;
}

function compareDeltas($a, $b){
	if(abs($a['delta']) == abs($b['delta'])){
		return 0;
	}
	if(abs($a['delta']) < abs($b['delta'])){
		return 1;
	} else {
		return -1;
	}
}

function padFirmware($firmware){
	$versionPieceCount = substr_count($firmware, '.');
	while($versionPieceCount < 3){
		$firmware .= '.x';
		$versionPieceCount = substr_count($firmware, '.');
	}
	return $firmware;
}

function getCustomersDeltas($customers, $deviceCount){
	$result = array();
	$customerNames = getCustomerNames();
	foreach($customers as $customer=>$revCount){
		$delta = 0.0;
		if($deviceCount[$customer] != 0 && $revCount['delta'] != 0){
			$delta =  $revCount['delta'] / $deviceCount[$customer];
		}
		$result[] = array('name'=>$customerNames[$customer], 'delta'=>$delta);
	}
	return $result;
}

function getTopCustomersNames($customers){
	$countTopCustomers = 5;
	$topDeltaCustomers = array_slice($customers, 0, $countTopCustomers);
	$result = array();
	foreach($topDeltaCustomers as $topCustomer){
		$result[] = $topCustomer['name'];
	}
	return $result;
}


function formatReport(){
	$result = '';
	$todayReportHash = generateReport();
	ksort($todayReportHash['report']);
	foreach($todayReportHash['report'] as $rev=>$count){
		$result .= padFirmware($rev);
		$result .= ' -> ' . $count['currentCount'] . ' appliances';
		if(isset($count['customers'])){
			$customers = getCustomersDeltas($count['customers'], $todayReportHash['deviceCount']);
			usort($customers, 'compareDeltas');
			$names = getTopCustomersNames($customers);
			$result .= ' (' . implode(', ', $names) . ')';
		}
		$result .= "\n";
	}
	return $result;
}