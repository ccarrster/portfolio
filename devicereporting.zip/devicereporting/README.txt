Chris Carr - ccarrster@gmail.com 519 954 6062
Exinda PHP Assignment Submition

It uses the mysqli library
Asumption: If the company does not own any firmware of a specific version today, but did own it 7 days ago, we do not report on that. (There are no zero appliances listed in the example output)
Asumption: The percentage change is calculated by the delta of today's count and the count from 7 days ago, ignoring any changes inbetween.

Setup:
Need to setup username, password and database at the top of the exinda.php file
"username", "password", "database"

Also need to create this table in the database, as well as the other tables included in the assignment
	CREATE TABLE `appliance_status_summary` (
	  `customer_id` VARCHAR(10) NOT NULL,
	  `firmware` VARCHAR(45) NOT NULL,
	  `count` INT NOT NULL,
	  `day` DATE NOT NULL);
	  
Use this function to move data to the appliance_status_summary table. This would be called by a daily cron shortly after midnight.
populateDailySummary()

Use this function to get a text report. This would be the user called report function.
formatReport()

Sample input is in the phpunit test file test.php

Sample output from two of the unit tests are in output.txt