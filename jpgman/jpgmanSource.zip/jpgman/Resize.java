/*
 * Resize.java
 *
 * Created on February 5, 2005, 12:35 AM
 */

package jpgman;


import java.awt.*;
import java.awt.image.*;
import java.io.*;
import com.sun.image.codec.jpeg.*;

public class Resize extends Panel {


      // @param originalImage the file name of the image to resize
      // @param newImage the new file name for the resized image
      // @param factor the new image's width will be  width * factor.
      // The height will be proportionally scaled.

        public void doResize
          (String originalImage, String newImage, int height) {
            Image img = getToolkit().getImage(originalImage);
            loadImage(img);
            int iw = img.getWidth(this);
            int ih = img.getHeight(this);
            double factor = ((double)height / (double)ih);
            //Reduce the image
            int w = (int)(iw * factor);
            Image i2 = img.getScaledInstance(w, -1, 0);
            loadImage(i2);

            //Load it into a BufferedImage
            int i2w = i2.getWidth(this);
            int i2h = i2.getHeight(this);
            BufferedImage bi =
              new BufferedImage(i2w, i2h, BufferedImage.TYPE_INT_RGB);
            Graphics2D big = bi.createGraphics();
            big.drawImage(i2,0,0,this);

            //Use JPEGImageEncoder to write the BufferedImage to a file
            try{
             OutputStream os = new FileOutputStream(newImage);
             JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(os);
             encoder.encode(bi);
            } catch(IOException ioe){
             ioe.printStackTrace();
            }
        }


          //Cause the image to be loaded into the Image object

        private void loadImage(Image img){
          try {
          MediaTracker tracker = new MediaTracker(this);
          tracker.addImage(img, 0);
          tracker.waitForID(0);
          } catch (Exception e) {}
        }


    }



