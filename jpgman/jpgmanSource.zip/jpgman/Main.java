/*
 * Main.java
 *
 * Created on February 5, 2005, 12:21 AM
 */

package jpgman;


import java.io.File;
/**
 *
 * @author z
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     *Purpose: To process the command line arguments and call the appropriate methods
     *
     *Command Formats:
     *
    * flatten dir
    * thumbAllFirst dir height
    * thumbFirst dir height
    * thumbAllFirst dir dir height
    * thumbFirst dir dir height
    * thumbAll dir height
    * thumb dir height
    * thumbAll dir dir height
    * thumb dir dir height
    * renameFlattenAll dir dir digits
    * renameFlatten dir newName dir digits
    * renameFlattenAll dir digits
    * renameFlatten dir newName digits
    * deleteSize dir minSize
    * writeHtmlAll dir
    * writeHtml dir
    * deleteThumbsAll dir
    * deleteThumbs dir
     *
     *rem Examples of all commands:
*java -classpath jpgman.jar jpgman.Main flatten c:\test2
*java -classpath jpgman.jar jpgman.Main thumballfirst c:\test2 25
*java -classpath jpgman.jar jpgman.Main thumballfirst c:\test2 c:\test2 25
*java -classpath jpgman.jar jpgman.Main thumbfirst c:\test2\0038 200
*java -classpath jpgman.jar jpgman.Main thumbfirst c:\test2\0038 c:\test2 300
*java -classpath jpgman.jar jpgman.Main thumbAll c:\test2 200
*java -classpath jpgman.jar jpgman.Main thumbAll c:\test2 c:\test2 300
*java -classpath jpgman.jar jpgman.Main thumb c:\test2\0038 200
*java -classpath jpgman.jar jpgman.Main thumb c:\test2\0038 c:\test2 300
*java -classpath jpgman.jar jpgman.Main renameflattenall c:\test2 c:\goo 3
*java -classpath jpgman.jar jpgman.Main renameflattenall c:\test3 4
*java -classpath jpgman.jar jpgman.Main renameflatten c:\test2\0038 c:\goo sucker 3
*java -classpath jpgman.jar jpgman.Main renameflatten c:\test2\0042 pooface 4
*java -classpath jpgman.jar jpgman.Main deleteSize c:\test2 110
*java -classpath jpgman.jar jpgman.Main writeHtmlAll c:\test2
*java -classpath jpgman.jar jpgman.Main writeHtml c:\test2\0061
*java -classpath jpgman.jar jpgman.Main deleteThumbs c:\test2\0061
*java -classpath jpgman.jar jpgman.Main deleteThumbsAll c:\test2
     */
    public static void main(String[] args) {
        jpgren tool = new jpgren();
       
        if (args.length >= 2 && args.length <= 5){
            if (args[0].toLowerCase().equals("flatten")){
                if (args.length == 2){
                    tool.uniqueFolder(new File(args[1]));
                }
            } else if (args[0].toLowerCase().equals("thumballfirst")){
                if (args.length == 3){
                    tool.multiResizeOne(new File(args[1]), Integer.parseInt(args[2]));
                } else if (args.length == 4){
                    tool.multiResizeOne(new File(args[1]), new File(args[2]), Integer.parseInt(args[3]));
                } else {
                    invalidSyntax();
                }                
            } else if (args[0].toLowerCase().equals("thumbfirst")){
                 if (args.length == 3){
                    tool.resizeOne(new File(args[1]), Integer.parseInt(args[2]));
                } else if (args.length == 4){
                    tool.resizeOne(new File(args[1]), new File(args[2]), Integer.parseInt(args[3]));
                } else {
                    invalidSyntax();
                }      
            } else if (args[0].toLowerCase().equals("thumball")){
                 if (args.length == 3){
                    tool.multiResize(new File(args[1]), Integer.parseInt(args[2]));
                } else if (args.length == 4){
                    tool.multiResize(new File(args[1]), new File(args[2]), Integer.parseInt(args[3]));
                } else {
                    invalidSyntax();
                }      
            } else if (args[0].toLowerCase().equals("thumb")){
                if (args.length == 3){
                    tool.resize(new File(args[1]), Integer.parseInt(args[2]));
                } else if (args.length == 4){
                    tool.resize(new File(args[1]), new File(args[2]), Integer.parseInt(args[3]));
                } else {
                    invalidSyntax();
                }      
            } else if (args[0].toLowerCase().equals("renameflattenall")){
                if (args.length == 3){
                    tool.firstGiverMulti(new File(args[1]), Integer.parseInt(args[2]));
                } else if (args.length == 4){
                    tool.firstGiverMulti(new File(args[1]), new File(args[2]), Integer.parseInt(args[3]));
                } else {
                    invalidSyntax();
                }      
            } else if (args[0].toLowerCase().equals("renameflatten")){
                if (args.length == 4){
                    tool.firstGiver(new File(args[1]), args[2], Integer.parseInt(args[3]));
                } else if (args.length == 5){
                    //Note order changed 3/4
                    tool.firstGiver(new File(args[1]), args[3], new File(args[2]), Integer.parseInt(args[4]));
                } else {
                    invalidSyntax();
                }      
            } else if (args[0].toLowerCase().equals("deletesize")){
                if (args.length == 3){
                    tool.checkSize(new File(args[1]), Integer.parseInt(args[2]));
                } else {
                    invalidSyntax();
                }                     
            } else if (args[0].toLowerCase().equals("writehtmlall")){
                if (args.length == 2){
                    tool.multiWriteHTML(new File(args[1]));
                } else {
                    invalidSyntax();
                }        
            } else if (args[0].toLowerCase().equals("writehtml")){
                if (args.length == 2){
                    tool.writeHTML(new File(args[1]));
                } else {
                    invalidSyntax();
                }
            } else if (args[0].toLowerCase().equals("deletethumbsall")){
                if (args.length == 2){
                    tool.multiDeleteThumbs(new File(args[1]));
                } else {
                    invalidSyntax();
                }
            } else if (args[0].toLowerCase().equals("deletethumbs")){
                if (args.length == 2){
                    tool.deleteThumbs(new File(args[1]));
                } else {
                    invalidSyntax();
                }
            } else {
                invalidSyntax();
            }            
        } else {
            invalidSyntax();
        }
        
        
    }
    
    static void invalidSyntax(){
        System.out.println("Acceptable Syntax:\n\nflatten dir\nthumbAllFirst dir height\nthumbFirst dir height\nthumbAllFirst dir dir height\nthumbFirst dir dir height\nthumbAll dir height\nthumb dir height\nthumbAll dir dir height\nthumb dir dir height\nrenameFlattenAll dir dir digits\nrenameFlatten dir dir newName digits\nrenameFlattenAll dir digits\nrenameFlatten dir newName digits\ndeleteSize dir minSize\nwriteHtmlAll dir\nwriteHtml dir\ndeleteThumbsAll dir\ndeleteThumbs dir\n");
    }
    
}
