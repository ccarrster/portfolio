/*
 * jpgren.java
 *
 * Created on February 5, 2005, 12:36 AM
 */

package jpgman;

/**
 * jpgren.java
 *
 * Created on November 12, 2004, 10:16 PM
 */


import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;


/**
 *
 * @author  5
 */
public class jpgren {
    String rootPath;
    String prefix;
    int counter;
    Resize resizer;
    /** Creates a new instance of jpgren */
    public jpgren() {
        resizer = new Resize();
    }    
    
    /**
     *Purpose: to concatinate foldernames 2 layers deep
     *eg:
     *Goo
     *  Face
     *  Pants
     *
     *Becomes
     *GooFace
     *GooPants
     */
    public void uniqueFolder(File file){
        File[] files = file.listFiles();        
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                uniqueFolderRec(files[i]);
            }
        }        
    }
    
    /**
     *Purpose: Recersive worker of uniqueFolder
     */
    private void uniqueFolderRec(File file){
        File[] files = file.listFiles();        
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
               files[i].renameTo(new File(files[i].toString().substring(0, files[i].toString().lastIndexOf('\\')) + files[i].toString().substring(files[i].toString().lastIndexOf('\\') + 1, files[i].toString().length())));               
            }
        }        
        file.delete();
    }
   
    /**
     *To resize a directory full of directories full of images
     *eg.
     *Goo
     *  Face
     *      pic1.jpg
     *      pic2.jpg
     *  Pants
     *      pic1.jpg
     *      pic2.jpg
     *
     *Becomes
     *
     **Goo
     *  Face
     *      pic1.jpg
     *      pic2.jpg
     *      tpic1.jpg
     *      tpic2.jpg
     *  Pants
     *      pic1.jpg
     *      pic2.jpg
     *      tpic1.jpg
     *      tpic2.jpg
     */
    
    public void multiResizeOne(File file, int pixelHeight){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                resizeOne(files[i], pixelHeight);
            }
        }        
    }
    
    /**
     *Purpose: To resize one directory full of images
     *Note* Resized to pixel height 150
     *eg.
     *Goo
     *  pic1.jpg
     *  pic2.jpg
     *
     *Becomes
     *
     *Goo
     *  pic1.jpg
     *  pic2.jpg
     *  tpic1.jpg
     *  tpic2.jpg
     */
    public void resizeOne(File file, int pixelHeight){        
        File[] files = file.listFiles();
        if (files.length != 0){
            Arrays.sort(files);
            for(int i = 0; i < 1; i++){
                if(!files[i].isDirectory()){                
                    if((-1 != files[i].toString().toLowerCase().lastIndexOf(".jpg")) ||( -1 != files[i].toString().toLowerCase().lastIndexOf(".jpeg"))){
                        resizer.doResize(files[i].toString(), files[i].toString().substring(0, files[i].toString().lastIndexOf("\\")) + "\\t" + files[i].toString().substring((files[i].toString().lastIndexOf("\\") + 1)), pixelHeight);                                              
                    }
                }
            }        
        }
    }
    
    /**
     *Purpose: To resize the first image from a directory of a directory of images, and create them in a spesified folder
     *Eg.
     *dest is C:\trousers
     *
     *c:\trousers
     *
     *Goo
     *  Face
     *      face1.jpg
     *      face2.jpg
     *  Pants
     *      pants1.jpg
     *      pants2.jpg
     *
     *Becomes
     *
     *c:\trousers
     *  tface1.jpg
     *  tpants1.jpg
     *
     *Goo
     *  Face
     *      pic1.jpg
     *      pic2.jpg
     *  Pants
     *      pic1.jpg
     *      pic2.jpg
     */
    public void multiResizeOne(File file, File dest, int pixelHeight){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                resizeOne(files[i], dest, pixelHeight);
            }
        }        
    }
    
     /**
      *Purpose: To resize the first image from a directory of images, and create it in a spesified folder
      *Eg.
      *dest is C:\trousers
      *
      *c:\trousers
      *
      *Goo
      * goo1.jpg
      * goo2.jpg
      *
      *Becomes
      *
      *c:\trousers
      * tgoo1.jpg
      *
      *Goo
      * goo1.jpg
      * goo2.jpg
      */
    public void resizeOne(File file, File dest, int pixelHeight){
        File[] files = file.listFiles();
        if(files.length != 0){
            Arrays.sort(files);
            for(int i = 0; i < 1; i++){
                if(!files[i].isDirectory()){                
                    if((-1 != files[i].toString().toLowerCase().lastIndexOf(".jpg")) ||( -1 != files[i].toString().toLowerCase().lastIndexOf(".jpeg"))){
                        resizer.doResize(files[i].toString(), dest.toString() + "\\t" + files[i].toString().substring((files[i].toString().lastIndexOf("\\") + 1)), pixelHeight);
                    }
                }
            }   
        }
    }

    /**
     *Purpose: Resize all images in a directory of directory of images
     *eg.
     *Goo
     *  Face
     *      face1.jpg
     *      face2.jpg
     *  Pants
     *      pants1.jpg
     *      pants2.jpg
     *
     *Becomes
     *
     *Goo
     *  Face
     *      face1.jpg
     *      face2.jpg
     *      tface1.jpg
     *      tface2.jpg
     *  Pants
     *      pants1.jpg
     *      tpants1.jpg
     *      pants2.jpg
     *      tpants2.jpg
     */
    public void multiResize(File file, int pixelHeight){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                resize(files[i], pixelHeight);
            }
        }        
    }
    
    /**
     *Purpose: To resize a directory of directory of images and create them to a spesified directory
     */
     public void multiResize(File file, File dest, int pixelHeight){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                resize(files[i], dest, pixelHeight);
            }
        }        
    }
    
     /**
      *Purpose: To resize a directory of images   
      *Note* image pixel height is 150
      */
     public void resize(File file, int pixelHeight){        
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(!files[i].isDirectory()){                
                if((-1 != files[i].toString().toLowerCase().lastIndexOf(".jpg")) ||( -1 != files[i].toString().toLowerCase().lastIndexOf(".jpeg"))){                    
                    resizer.doResize(files[i].toString(), files[i].toString().substring(0, files[i].toString().lastIndexOf("\\")) + "\\t" + files[i].toString().substring((files[i].toString().lastIndexOf("\\") + 1)), pixelHeight);
                }
            }
        }        
    }
     
    /**
     *Purpose: To resize a directory of images and create them in a specific directory
     *Note* image pixel height is 150
     */
    public void resize(File file, File dest, int pixelHeight){        
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(!files[i].isDirectory()){                
                if((-1 != files[i].toString().toLowerCase().lastIndexOf(".jpg")) ||( -1 != files[i].toString().toLowerCase().lastIndexOf(".jpeg"))){
                    resizer.doResize(files[i].toString(), dest.toString() + "\\t" + files[i].toString().substring((files[i].toString().lastIndexOf("\\") + 1)), pixelHeight);
                }
            }
        }        
    }
    
    /**
     *Purpose: To clean a directory of directories of images and directories with images in them and move them all to a specified directory
     *eg.
     *Goo
     *  Face
     *      Happy.jpg
     *      sassface.jpg
     *  Pants
     *      bellbottems.jpg
     *      ShortPants
     *          redpants.jpg
     *      LongPants
     *          redpants.jpg
     *
     *Becomes
     *
     *Goo
     *  Face
     *      Face001.jpg
     *      Face002.jpg
     *  Pants
     *      Pants001.jpg
     *      Pants002.jpg
     *      Pants003.jpg
     */
    public void firstGiverMulti(File file, File path, int digits){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                firstGiver(files[i], files[i].getPath().substring(files[i].getPath().lastIndexOf('\\') + 1), path, digits);
            }else {
                files[i].delete();
            } 
        }                
    }

    /**
     *Purpose: To rename all the images in one directory and any directories below that and rename that directory
     */
    public void firstGiver(File file, String inPrefix, File path, int digits){
        rootPath = file.getPath();
        counter = 0;
        prefix = inPrefix;
        giver(file, digits);     
        file.renameTo(new File(path.toString() + "\\" + prefix));
    }
     /**
     *Purpose: To clean a directory of directories of images and directories with images in them
     *eg.
     *Goo
     *  Face
     *      Happy.jpg
     *      sassface.jpg
     *  Pants
     *      bellbottems.jpg
     *      ShortPants
     *          redpants.jpg
     *      LongPants
     *          redpants.jpg
     *
     *Becomes
     *
     *Goo
     *  Face
     *      Face001.jpg
     *      Face002.jpg
     *  Pants
     *      Pants001.jpg
     *      Pants002.jpg
     *      Pants003.jpg
     */
    public void firstGiverMulti(File file, int digits){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                firstGiver(files[i], files[i].getPath().substring(files[i].getPath().lastIndexOf('\\') + 1), digits);
            }else {
                files[i].delete();
            } 
        }                
    }

     /**
     *Purpose: To rename all the images in one directory and any directories below that
     */
    public void firstGiver(File file, String inPrefix, int digits){
        rootPath = file.getPath();
        counter = 0;
        prefix = inPrefix;
        giver(file, digits);    
        file.renameTo(new File(file.toString().substring(0, file.toString().lastIndexOf('\\')) + "\\" + prefix));
    }
    
    /**
     *Purpose: Recursive work hourse for first giver
     *Numbering starts at 1
     *works on jpg images that end in "jpg" or "jpeg" case insensitive
     *Deletes all other files and all directories
     */
    private void giver(File file, int digits){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){
                giver(files[i], digits);
                files[i].delete();
            } else {
                if((-1 != files[i].toString().toLowerCase().lastIndexOf(".jpg")) ||( -1 != files[i].toString().toLowerCase().lastIndexOf(".jpeg"))){
                    counter++;                                
                    String zeros = "";                                        
                    int X = 1;
                    for (int n = 0; n < digits; X = X * 10, n++){
                            if ((counter < X * 10 ) && (counter >= X)){
                                    for (int l = 0; l < digits - n - 1; l++){
                                            zeros = zeros + "0";
                                    }
                            }
                    }      
                    
                    files[i].renameTo(new File(rootPath + "\\" + prefix + zeros + counter + ".jpg"));                    
                } else {
                    files[i].delete();
                }
            }
        }        
    }
    
    /**
     *deletes directories in the given directory that have minSize or less files in them
     *Does not count files within directories
     */    
    public void checkSize(File file, int minSize){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            File[] imageFiles = files[i].listFiles();
            if (imageFiles.length <= minSize -1){
                for(int j = 0; j < imageFiles.length; j++){
                    imageFiles[j].delete();
                }
                files[i].delete();
            }                
        }
    }
    
    /**
     *Creates webpages for every folder and an index
     */    
    public void multiWriteHTML(File file){
        File[] files = file.listFiles();
        Arrays.sort(files);
        try{
            File indexFile = new File(file.toString() + "\\index.html");
            FileWriter writer = new FileWriter(indexFile);
            writer.write("<html><head><title></title></head><body>");            
            for(int i = 0; i < files.length; i++){
                if(files[i].isDirectory()){                
                    writeHTML(files[i]);
                    writer.write("<a href = \""  + files[i].toString() + ".html\">" + "<img src=\"" + files[i].toString() + "\\t" + files[i].toString().substring(files[i].toString().lastIndexOf("\\") + 1) + "001.jpg\">" + "</a>\n");
                }        
            }
            writer.write("</body></html>\n");
            writer.flush();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     *Creates a webpage for all the pics in a folder
     *<Start tags>
     *a href="image.jpg"
     *img src="timage.jpg"
     * s/a
     *<End tags>
     *
     *Ignores files that contain a 't' followed by the folder name
     */
    public void writeHTML(File file){
         try{
         File htmlFile = new File(file.toString().substring(0, file.toString().lastIndexOf("\\")) + "\\" + file.toString().substring((file.toString().lastIndexOf("\\") + 1)) + ".html");
         FileWriter writer = new FileWriter(htmlFile);
         writer.write("<html><head><title></title></head><body>");
         File[] files = file.listFiles();
         Arrays.sort(files);
         for(int i = 0; i < files.length; i++){             
            if(files[i].toString().lastIndexOf("t" + file.toString().substring((file.toString().lastIndexOf("\\") + 1))) == -1){
                writer.write("<a href = \"" + files[i].toString() + "\">" + "<img src=\"" + files[i].toString().substring(0, files[i].toString().lastIndexOf("\\")) + "\\t" + files[i].toString().substring((files[i].toString().lastIndexOf("\\") + 1))  + "\">" + "</a>\n");
            } 
         }
         writer.write("</body></html>\n");
         writer.flush();
         } catch (Exception e){
            e.printStackTrace();
         }
    }
    
    /**
     *Deletes thumbs in all directories
     **thumbs have the same prefix as the directory but with a lower case t in the begining
     */    
    public void multiDeleteThumbs(File file){
        File[] files = file.listFiles();
        for(int i = 0; i < files.length; i++){
            if(files[i].isDirectory()){                
                deleteThumbs(files[i]);
            } 
        }                
    }
    
    /**
     *Deletes thumbs in one directory
     *thumbs have the same prefix as the directory but with a lower case t in the begining
     */    
    public void deleteThumbs(File file){         
         File[] files = file.listFiles();         
         for(int i = 0; i < files.length; i++){             
            if(files[i].toString().lastIndexOf("t" + file.toString().substring((file.toString().lastIndexOf("\\") + 1))) != -1){
                files[i].delete();
            } 
         }         
    }    
}

