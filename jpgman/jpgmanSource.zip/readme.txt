C�:'s Jpg Ripper Tools

Files
sample.txt		A sample of the command lines used to run the application
readme.txt		This file
jpgman.jar		The compiled application
javadoc\index.html	Javadoc: information about the source code
jpgman\jpgren.java	The tool collection
jpgman\Main.java	Command line interpreter
jpgman\Resize.java	Image resizing tool

Purpose: To make it quicker for me to make webpages/archives from the images that I rip from webpages. Then on February 13th, 2005 I decided that it was a useful enough tool to share with the world. So I added the command line arguments tested them and commented the code a little more. I stole the Resize code from the net, I have no idea where... but the rest you can do what you want with. You can use it as it is with the commands listed in the sample.txt file, or you can modify the code to do what ever you want it to do. Read the javadoc or look at the source.

So updates and info will be at:
http://www.geocities.com/jpgmantools

Help/info whatever:
poomang@hotmail.com